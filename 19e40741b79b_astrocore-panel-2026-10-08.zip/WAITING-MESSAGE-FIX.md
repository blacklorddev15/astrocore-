# Waiting-for-this-message fix

Astrocore now follows the Elite multi-bot retry configuration:

- Per-socket `msgRetryCounterCache`.
- Per-socket original-message `getMessage` lookup backed by the bounded message store.
- Cached group metadata.
- `fireInitQueries: false`.
- `shouldSyncHistoryMessage: () => false` and `syncFullHistory: false`.
- Existing cached Signal key store retained.

This prevents Astrocore from answering decryption retries with empty placeholder messages, which is the main cause of WhatsApp showing “Waiting for this message.” The fix is offline-validated; a live WhatsApp session is still required to confirm recovery on the affected number.
