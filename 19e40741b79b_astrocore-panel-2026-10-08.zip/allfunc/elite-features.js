'use strict';

const fs = require('fs');
const path = require('path');
const axios = require('axios');

const processedChatbotMessages = new Set();
const handledDeletes = new Set();
const attachedSockets = new WeakSet();

function sessionDir(sessionId) {
  const raw = String(sessionId || 'unknown').split('@')[0];
  const safe = raw.replace(/\D/g, '') || raw.replace(/[^0-9A-Za-z._-]/g, '_');
  const dir = path.join('./richstore/pairing', safe);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function featureFile(sessionId, name) {
  return path.join(sessionDir(sessionId), name);
}

function readJson(file, fallback) {
  try { return { ...fallback, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; }
  catch { return { ...fallback }; }
}

function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}

function readAntiDeleteConfig(sessionId) {
  return readJson(featureFile(sessionId, 'antidelete.json'), { enabled: false });
}

function setAntiDelete(sessionId, enabled) {
  const value = { enabled: Boolean(enabled) };
  writeJson(featureFile(sessionId, 'antidelete.json'), value);
  return value;
}

function readChatbotConfig(sessionId) {
  return readJson(featureFile(sessionId, 'chatbot.json'), {
    global: false,
    dm: false,
    group: false,
    chats: {}
  });
}

function updateChatbotConfig(sessionId, updater) {
  const config = readChatbotConfig(sessionId);
  config.chats = config.chats || {};
  updater(config);
  writeJson(featureFile(sessionId, 'chatbot.json'), config);
  return config;
}

function messageText(message) {
  return message?.conversation ||
    message?.extendedTextMessage?.text ||
    message?.imageMessage?.caption ||
    message?.videoMessage?.caption ||
    message?.documentMessage?.caption || '';
}

function unwrap(message) {
  let current = message;
  for (const wrapper of ['ephemeralMessage', 'viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension']) {
    if (current?.[wrapper]?.message) current = current[wrapper].message;
  }
  return current;
}

function saveMessage(sessionId, message) {
  if (!message?.key?.remoteJid || !message?.key?.id || !message.message) return;
  const file = featureFile(sessionId, `deleted-${encodeURIComponent(message.key.remoteJid)}-${encodeURIComponent(message.key.id)}.json`);
  writeJson(file, { _ts: Date.now(), key: message.key, message: message.message });
}

function loadMessage(sessionId, remoteJid, id) {
  const file = featureFile(sessionId, `deleted-${encodeURIComponent(remoteJid)}-${encodeURIComponent(id)}.json`);
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function deleteSavedMessage(sessionId, remoteJid, id) {
  const file = featureFile(sessionId, `deleted-${encodeURIComponent(remoteJid)}-${encodeURIComponent(id)}.json`);
  try { fs.unlinkSync(file); } catch (_) {}
}

async function restoreDeletedMessage(socket, old, remoteJid, deletedBy) {
  const ownerJid = socket.user?.id || remoteJid;
  const sender = old.key?.participant || old.key?.remoteJid || 'unknown';
  const note = `╭━━[ *× ANTI DELETE MESSAGES ×* ]━┉\n` +
    `┣━ *Deleted by:* @${String(deletedBy).split('@')[0]}\n` +
    `┣━\n┣━ *Original sender:* @${String(sender).split('@')[0]}\n` +
    `┣━ *Chat:* ${remoteJid}\n╰━━━━━━━━━━━━━━━━━━━━┉`;
  const mentions = [deletedBy, sender].filter(Boolean);
  try {
    if (typeof socket.copyNForward === 'function') {
      await socket.sendMessage(ownerJid, { text: note, mentions });
      await socket.copyNForward(ownerJid, { key: old.key, message: old.message }, true);
      return;
    }
  } catch (_) {}
  const msg = unwrap(old.message);
  const text = messageText(msg);
  await socket.sendMessage(ownerJid, {
    text: text ? `${note}\n\n${text}` : `${note}\n\n[Deleted media could not be restored]`,
    mentions
  });
}

function attachAntiDelete(socket, sessionId) {
  socket.ev.on('messages.upsert', async ({ messages }) => {
    const message = messages?.[0];
    if (!readAntiDeleteConfig(sessionId).enabled) return;
    if (!message?.message || message.key?.fromMe) return;
    saveMessage(sessionId, message);
  });

  socket.ev.on('messages.update', async (updates) => {
    if (!readAntiDeleteConfig(sessionId).enabled) return;
    for (const update of updates || []) {
      const remoteJid = update.key?.remoteJid;
      const id = update.key?.id;
      if (!remoteJid || !id) continue;
      const deleted = update.update?.messageStubType === 1 || update.message?.protocolMessage?.type === 0;
      if (!deleted) continue;
      const key = `${sessionId}:${remoteJid}:${id}`;
      if (handledDeletes.has(key)) continue;
      handledDeletes.add(key);
      setTimeout(() => handledDeletes.delete(key), 10 * 60 * 1000);
      const old = loadMessage(sessionId, remoteJid, id);
      if (!old?.message) continue;
      const deletedBy = update.participant || update.key.participant || remoteJid;
      const botId = String(socket.user?.id || '').split(':')[0];
      if (String(deletedBy).includes(botId) || String(old.key?.participant || old.key?.remoteJid || '').includes(botId)) continue;
      try { await restoreDeletedMessage(socket, old, remoteJid, deletedBy); }
      catch (err) { console.error('[ANTI-DELETE] restore failed:', err.message); }
      deleteSavedMessage(sessionId, remoteJid, id);
    }
  });
}

async function handleChatbot(socket, message, sessionId) {
  try {
    if (!message?.message || !message.key || message.key.fromMe) return;
    const from = message.key.remoteJid;
    if (!from || from === 'status@broadcast') return;
    const id = `${sessionId}:${from}:${message.key.id}`;
    if (processedChatbotMessages.has(id)) return;
    processedChatbotMessages.add(id);
    setTimeout(() => processedChatbotMessages.delete(id), 60 * 1000);

    const config = readChatbotConfig(sessionId);
    const isGroup = from.endsWith('@g.us');
    const enabled = config.global || (isGroup ? config.group : config.dm) || config.chats?.[from] === true;
    if (!enabled) return;
    const text = messageText(message.message).trim();
    if (!text || text.startsWith(process.env.PREFIX || '.')) return;

    const sender = message.key.participant || from;
    global.userChats = global.userChats || {};
    global.userChatTimestamps = global.userChatTimestamps || {};
    global.userChats[`${sessionId}:${sender}`] = global.userChats[`${sessionId}:${sender}`] || [];
    const historyKey = `${sessionId}:${sender}`;
    global.userChatTimestamps[historyKey] = Date.now();
    global.userChats[historyKey].push(`User: ${text}`);
    if (global.userChats[historyKey].length > 15) global.userChats[historyKey].shift();

    const prompt = [
      'You are Varnox XD, a helpful WhatsApp assistant. Respond clearly and naturally.',
      'If a user asks for a song, video, or image, suggest the matching bot command when appropriate.',
      'Conversation history:',
      global.userChats[historyKey].join('\n'),
      `User: ${text}`
    ].join('\n');
    const apiUrl = process.env.CHATBOT_API_URL || 'https://eliteprotech-apis.zone.id/deepai';
    await socket.sendPresenceUpdate('composing', from).catch(() => {});
    const response = await axios.get(apiUrl, {
      params: { prompt },
      headers: { Accept: '*/*', 'User-Agent': 'Varnox XD-Chatbot/1.0' },
      timeout: Number(process.env.CHATBOT_TIMEOUT_MS || 30000)
    });
    const reply = response?.data?.response || response?.data?.answer || response?.data?.result;
    if (!reply) return;
    global.userChats[historyKey].push(`Bot: ${reply}`);
    if (global.userChats[historyKey].length > 15) global.userChats[historyKey].shift();
    await socket.sendPresenceUpdate('paused', from).catch(() => {});
    await socket.sendMessage(from, { text: String(reply) }, { quoted: message });
  } catch (err) {
    console.error('[CHATBOT] error:', err.message);
  }
}

function attachEliteFeatures(socket, sessionId) {
  if (attachedSockets.has(socket)) return;
  attachedSockets.add(socket);
  attachAntiDelete(socket, sessionId);
  setInterval(() => {
    const now = Date.now();
    for (const file of fs.readdirSync(sessionDir(sessionId))) {
      if (!file.startsWith('deleted-') || !file.endsWith('.json')) continue;
      try {
        const full = path.join(sessionDir(sessionId), file);
        const data = JSON.parse(fs.readFileSync(full, 'utf8'));
        if (now - Number(data._ts || 0) > 10 * 60 * 1000) fs.unlinkSync(full);
      } catch (_) {}
    }
  }, 60 * 1000).unref?.();
}

module.exports = {
  attachEliteFeatures,
  handleChatbot,
  readAntiDeleteConfig,
  setAntiDelete,
  readChatbotConfig,
  updateChatbotConfig
};
