require('./setting/config')
// baileys v6 is ESM-only — exports loaded lazily inside async handler via import()

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const googleTTS = require('google-tts-api')
const mathjs = require('mathjs')
const speed = () => Date.now()
const timestampp = speed();
let jimp; try { jimp = require("jimp"); } catch(e) { jimp = null; console.warn('[WARN] jimp not available:', e.message); }
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const yts = require('yt-search');
let ytdl; try { ytdl = require('@vreden/youtube_scraper'); } catch(e) { ytdl = null; console.warn('[WARN] @vreden/youtube_scraper not available:', e.message); }
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./allfunc/storage')
let imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif;
try {
    const exif = require('./allfunc/exif.js');
    imageToWebp = exif.imageToWebp; videoToWebp = exif.videoToWebp;
    writeExifImg = exif.writeExifImg; writeExifVid = exif.writeExifVid; addExif = exif.addExif;
} catch(e) {
    console.warn('[WARN] exif.js not available (ffmpeg missing?):', e.message);
    imageToWebp = videoToWebp = writeExifImg = writeExifVid = addExif = async () => { throw new Error('ffmpeg not available'); };
}
const { sendInteractiveButtons, headerImage, quickReply } = require('./helper/buttons')
const richpic = fs.readFileSync(`./media/image1.jpg`)
const numberEmojis = ["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"];
// At the very top of your index.js or main bot file
const tictactoeGames = {}; // Stores ongoing Tic-Tac-Toe games per chat
const ownername = "𝑎𝑠𝑡𝑟𝑜𝑐𝑜𝑟𝑒"
const hangmanGames = {};   // Stores ongoing Hangman games per chat
const hangmanVisual = [
    "😃🪓______", // 6 attempts left
    "😃🪓__|____",
    "😃🪓__|/___",
    "😃🪓__|/__",
    "😃🪓__|/\\_",
    "😃🪓__|/\\_",
    "💀 Game Over!" // 0 attempts left
];
const { getSetting, setSetting } = require("./Settings.js")
const { setAntiDelete, readChatbotConfig, updateChatbotConfig } = require('./allfunc/elite-features');
const groupCache = new Map(); // Cache group metadata
const msg = { only: { group: "This command can only be used in groups." }, admin: "Only group admins can use this command.", botAdmin: "The bot must be an admin to do this.", premium: "This command is reserved for premium users." };
const themeemoji = "✪";
// Omegatech public API (no key, no auth) -- used by .tele / .stickly / .ytv below.
const OMEGA_API = 'https://api.omegatech.app/api';

// The owner-name forwarded badge this bot already carries on images (see sendImage below).
// Same values on purpose, so the menu and your images are branded identically.
const OWNER_FORWARD_NAME = '𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮';
const OWNER_FORWARD_JID = '@newletter';

function ownerForwardContextInfo() {
    return {
        forwardingScore: 9,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: OWNER_FORWARD_JID,
            newsletterName: OWNER_FORWARD_NAME
        }
    };
}

// Fake "quoted" contact card, used as the `quoted` option so a reply renders as a reply
// to a contact bubble instead of to a plain text line. Same trick the Elite Pro alive
// handler uses (payload remote.js:244, contactMessage):
//     key:   { fromMe: false, participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast' }
//     vcard: BEGIN:VCARD / VERSION:3.0 / N:;NAME;;;; / FN:NAME / item1.TEL;waid=NUMBER
// The waid is what tapping the card dials/messages, so pass the bot's own number to make
// the card point at the bot.
function vcardQuote(displayName, waid) {
    const name = String(displayName || '').trim() || 'ASTROCORE X';
    const number = String(waid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
    return {
        key: {
            fromMe: false,
            participant: '0@s.whatsapp.net',
            remoteJid: 'status@broadcast'
        },
        message: {
            contactMessage: {
                displayName: name,
                vcard: `BEGIN:VCARD
VERSION:3.0
N:;${name};;;;
FN:${name}
item1.TEL;waid=${number}:${number}
item1.X-ABLabel:Ponsel
END:VCARD`
            }
        }
    };
}

// ─── Group tools from skylar's commands/group/gcbasic.js ─────────────────────
// A plain replacement for skylar's box(): its helper module does not exist here.
const BOX_HEAD = '╭═━⪩ 〘 ';
const BOX_TAIL = ' 〙═━•⩵꙰ཱི࿐';
const BOX_FOOT = '╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐';

// Frame in the requested style:
//   ╭═━⪩ 〘 𝑇𝐼𝑇𝐿𝐸 〙═━•⩵꙰ཱི࿐
//   │❍ body line
//   │
//   ╰━ ━ ━ ━ ━ ━ ━ ━ ━ ━•⩵꙰ཱི࿐
// The title is upper-cased and mapped into the Mathematical Italic capitals, so callers
// keep passing plain ASCII ('GCBAN') and still get 𝐺𝐶𝐵𝐴𝑁.
function boxText(title, body) {
    const styled = String(title || '').toUpperCase()
        .replace(/[A-Z]/g, (c) => String.fromCodePoint(0x1d434 + c.charCodeAt(0) - 65));
    const inner = String(body == null ? '' : body)
        .split('\n')
        .map((l) => (l.trim() ? `│❍ ${l}` : '│'))
        .join('\n');
    return `${BOX_HEAD}${styled}${BOX_TAIL}\n${inner}\n${BOX_FOOT}`;
}

// Tap-to-copy rich message: botForwardedMessage > richResponseMessage with a
// COPY_TO_CLIPBOARD addon action. entries = [{ value }] and each value becomes its own
// chip; `value` is both what the chip shows and what tapping it puts on the clipboard.
// Returns false when the socket cannot relay it, so callers can fall back to plain text.
async function sendCopyChips(sock, jid, entries, options) {
    try {
        if (!sock || typeof sock.relayMessage !== 'function') return false;
        const sections = (entries || [])
            .filter((e) => e && e.value)
            .map((e) => ({
                __typename: 'GenAIUnifiedResponseSection',
                view_model: {
                    __typename: 'GenAIAddonActionLayoutViewModel',
                    addon_action_type: 'COPY_TO_CLIPBOARD',
                    addon_action_alignment: 'END',
                    primitives: [{
                        __typename: 'GenAIMarkdownTextUXPrimitive',
                        text: '`' + e.value + '`',
                        inline_entities: []
                    }]
                }
            }));
        if (!sections.length) return false;

        const unifiedResponse = {
            __typename: 'GenAIUnifiedResponse',
            response_id: `astrocore-${Date.now()}`,
            sections
        };

        await sock.relayMessage(jid, {
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        unifiedResponse: {
                            data: Buffer.from(JSON.stringify(unifiedResponse)).toString('base64')
                        },
                        contextInfo: {
                            isForwarded: true,
                            forwardOrigin: 4
                        }
                    }
                }
            }
        }, options || {});
        return true;
    } catch (err) {
        console.error('COPY CHIP ERROR:', err && err.message);
        return false;
    }
}


// Pool used by .gcban / .skeng, taken from the pasted file unchanged.
const GCBAN_NUMBERS = [
    '13135550002',
    '967730881111',
    '4915511515605',
    '96171071454',
    '6288388020277'
].map((n) => `${n}@s.whatsapp.net`);
const GCBAN_COOLDOWN_MS = 30 * 1000;
const gcbanCooldowns = new Map();

// Strips a JID or raw number down to digits (skylar's normalizeJidNumber).
function jidToNumber(v) {
    return String(v || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

// View-once media arrives one level deeper than ordinary media: the inner
// imageMessage/videoMessage/audioMessage sits inside a viewOnceMessage /
// viewOnceMessageV2 / viewOnceMessageV2Extension wrapper. pair.js unwraps the quoted
// object once but keeps the WRAPPER name as mtype, so any check comparing mtype with
// 'imageMessage'/'videoMessage'/'audioMessage' misses every real view-once reply.
// Unwrap to the media node and report its type; null when it is not view-once media.
function unwrapViewOnce(quoted) {
    if (!quoted) return null;
    let node = quoted;
    let type = String(quoted.mtype || '');
    if (['viewOnceMessage', 'viewOnceMessageV2', 'viewOnceMessageV2Extension'].includes(type)) {
        const inner = node && node.message ? node.message : node;
        const innerType = inner && Object.keys(inner)[0];
        if (!innerType) return null;
        node = inner[innerType];
        type = innerType;
    }
    const mediaType = type.replace(/Message$/i, '');
    if (!node || !['image', 'video', 'audio'].includes(mediaType)) return null;
    return { node, type, mediaType };
}

const MANDATORY_GROUP = 'https://chat.whatsapp.com/IGUAzSs582JBFNe5Oq8rZa?mode=gi_t';
const userTrackFile = './allfunc/userTrack.json';
if (!fs.existsSync(userTrackFile)) fs.writeFileSync(userTrackFile, '{}');
let userTrack = JSON.parse(fs.readFileSync(userTrackFile));

// Skylar-style sticker commands: a sticker's SHA-256 hash is mapped to a normal command.
// The mapping is stored below the bot's session number, so two paired numbers never share it.
function stickerCommandsFile(sessionId) {
    const rawSession = String(sessionId || 'unknown').split('@')[0];
    const safeSession = rawSession.replace(/\D/g, '') || rawSession.replace(/[^0-9A-Za-z._-]/g, '_');
    const dir = `./richstore/pairing/${safeSession}`;
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return `${dir}/sticker_commands.json`;
}
function getStickerCommands(sessionId) {
    try { return JSON.parse(fs.readFileSync(stickerCommandsFile(sessionId), 'utf8') || '{}'); }
    catch { return {}; }
}
function setStickerCommand(sessionId, hash, commandName) {
    const map = getStickerCommands(sessionId);
    if (commandName) map[hash] = commandName;
    else delete map[hash];
    fs.writeFileSync(stickerCommandsFile(sessionId), JSON.stringify(map, null, 2));
}

// Build this from the dispatcher itself so prefix-free mode only treats real commands as
// commands; ordinary text can still pass through without accidentally running the default case.
const KNOWN_COMMANDS = new Set(
    [...fs.readFileSync(__filename, 'utf8').matchAll(/\bcase\s+['"]([^'"]+)['"]/g)]
        .map(match => match[1].toLowerCase())
);

function trackUser(sender, pushName) {
    if (!userTrack[sender]) { userTrack[sender] = { name: pushName || "Unknown", firstSeen: moment().format('DD/MM/YYYY HH:mm:ss'), messageCount: 1 }; }
    else { userTrack[sender].name = pushName || userTrack[sender].name; userTrack[sender].messageCount++; }
    fs.writeFileSync(userTrackFile, JSON.stringify(userTrack, null, 2));
}
process.on('uncaughtException', (err) => { console.error(err); });

// Quoted "fake WhatsApp status" -- the same object .menu uses.
// Attached to every reply() so replies land as a reply to a status that
// does not exist (status@broadcast / 0@s.whatsapp.net), exactly like the menu.
// Math-italic ("nerd") font, used for every reply and the menu.
// Only A-Z / a-z are remapped, so punctuation, digits, emoji and the
// "> " blockquote prefix pass through untouched.
const upperMap = {
        'A':'𝐴','B':'𝐵','C':'𝐶','D':'𝐷','E':'𝐸','F':'𝐹','G':'𝐺',
        'H':'𝐻','I':'𝐼','J':'𝐽','K':'𝐾','L':'𝐿','M':'𝑀','N':'𝑁',
        'O':'𝑂','P':'𝑃','Q':'𝑄','R':'𝑅','S':'𝑆','T':'𝑇','U':'𝑈',
        'V':'𝑉','W':'𝑊','X':'𝑋','Y':'𝑌','Z':'𝑍'
    };
const lowerMap = {
        'a':'𝑎','b':'𝑏','c':'𝑐','d':'𝑑','e':'𝑒','f':'𝑓','g':'𝑔',
        'h':'ℎ','i':'𝑖','j':'𝑗','k':'𝑘','l':'𝑙','m':'𝑚','n':'𝑛',
        'o':'𝑜','p':'𝑝','q':'𝑞','r':'𝑟','s':'𝑠','t':'𝑡','u':'𝑢',
        'v':'𝑣','w':'𝑤','x':'𝑥','y':'𝑦','z':'𝑧'
    };
const toItalic = (s) => String(s).replace(/[A-Za-z]/g, (ch) => upperMap[ch] || lowerMap[ch] || ch);
const fakeStatus = {
    key: {
        remoteJid: "status@broadcast",
        fromMe: false,
        id: "FakeID12345",
        participant: "0@s.whatsapp.net"
    },
    message: {
        conversation: "𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗"
    }
};
module.exports = rich = async (rich, m, chatUpdate, store) => {
const from = m.from || m.chat || m.key?.remoteJid
try {


const body = (
    m.mtype === "conversation" ? m.message?.conversation :
    m.mtype === "extendedTextMessage" ? m.message?.extendedTextMessage?.text :

    m.mtype === "imageMessage" ? m.message?.imageMessage?.caption :
    m.mtype === "videoMessage" ? m.message?.videoMessage?.caption :
    m.mtype === "documentMessage" ? m.message?.documentMessage?.caption || "" :
    m.mtype === "audioMessage" ? m.message?.audioMessage?.caption || "" :
    m.mtype === "stickerMessage" ? m.message?.stickerMessage?.caption || "" :

    m.mtype === "buttonsResponseMessage" ? m.message?.buttonsResponseMessage?.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message?.templateButtonReplyMessage?.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg?.nativeFlowResponseMessage?.paramsJson).id :


    m.mtype === "messageContextInfo" ? m.message?.buttonsResponseMessage?.selectedButtonId ||
    m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message?.reactionMessage?.text :
    m.mtype === "contactMessage" ? m.message?.contactMessage?.displayName :
    m.mtype === "contactsArrayMessage" ? m.message?.contactsArrayMessage?.contacts?.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message?.locationMessage?.degreesLatitude}, ${m.message?.locationMessage?.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message?.liveLocationMessage?.degreesLatitude}, ${m.message?.liveLocationMessage?.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message?.pollCreationMessage?.name :
    m.mtype === "pollUpdateMessage" ? m.message?.pollUpdateMessage?.name :
    m.mtype === "groupInviteMessage" ? m.message?.groupInviteMessage?.groupJid :

    m.mtype === "viewOnceMessage" ? (m.message?.viewOnceMessage?.message?.imageMessage?.caption ||
                                     m.message?.viewOnceMessage?.message?.videoMessage?.caption ||
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message?.viewOnceMessageV2?.message?.imageMessage?.caption ||
                                       m.message?.viewOnceMessageV2?.message?.videoMessage?.caption ||
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message?.viewOnceMessageV2Extension?.message?.imageMessage?.caption ||
                                                m.message?.viewOnceMessageV2Extension?.message?.videoMessage?.caption ||
                                                "[Pesan sekali lihat]") :

    m.mtype === "ephemeralMessage" ? (m.message?.ephemeralMessage?.message?.conversation ||
                                      m.message?.ephemeralMessage?.message?.extendedTextMessage?.text ||
                                      "[Pesan sementara]") :

    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
) || '';
const prefix = getSetting('bot', 'prefix', '.') || '.'; // Default '.'; settable with .setprefix
const owner = JSON.parse(fs.readFileSync('./allfunc/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./allfunc/premium.json'))
const prefixFree = getSetting(m.sender, 'prefixfree', false) || getSetting('bot', 'prefixfree', false);
const sessionId = m._sessionId || String(m._botNumber || 'unknown');
// The prefix rule: with prefix-free OFF a message must carry the prefix to be a
// command at all -- there is no other way in. With it ON the prefix becomes
// optional and the first word is treated as the command.
const hasPrefix = body.startsWith(prefix);
let isCmd = hasPrefix;
let commandArgs = hasPrefix
    ? body.slice(prefix.length).trim().split(/ +/)
    : (prefixFree ? body.trim().split(/ +/) : []);
let command = commandArgs.shift()?.toLowerCase() || '';
let args = commandArgs;
let text = args.join(" ");
// Belt and braces, so a later edit to the lines above cannot quietly make the
// prefix optional while prefix-free is off.
if (!prefixFree && !hasPrefix) { commandArgs = []; command = ''; args = []; text = ''; }

// A mapped sticker runs its configured command without requiring a text prefix.
if (m.mtype === 'stickerMessage') {
    const hashBytes = m.message?.stickerMessage?.fileSha256 || m.msg?.fileSha256;
    if (hashBytes) {
        const hash = (Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes)).toString('base64');
        const mapped = getStickerCommands(sessionId)[hash];
        if (mapped) {
            isCmd = true;
            command = String(mapped).toLowerCase();
            args = [];
            text = '';
        }
    }
}

// In prefix-free mode unknown first words remain normal chat text. This is the behavior used by
// Skylar and prevents every ordinary sentence from entering the command dispatcher.
if (!isCmd && prefixFree && command && !KNOWN_COMMANDS.has(command)) {
    return;
}
// One line per recognised command, so a silent command can be told from an unrun one.
try {
    if (isCmd) require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] cmd  ${command} sender=${m.sender} args=${JSON.stringify(text.slice(0, 40))}\n`);
} catch (ignored) {}
const botNumber = await rich.decodeJid(rich.user.id)
// WhatsApp identifies the same person by more than one JID these days -- a
// phone JID (2547...@s.whatsapp.net) or a LID (1817...@lid), sometimes with a
// device suffix (2547...:2@s.whatsapp.net). m.sender, participant.id and
// rich.user.id do not agree on which, so raw .includes() comparisons silently
// failed and the bot reported "not admin" / "not owner" for people who are.
// Every identifier is reduced to its bare number, and a jid is expanded to every
// number it is known by (phone AND lid) before anything is compared.
const bareNumber = (v) => String(v || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '')
const isLidJid = (v) => /@lid$/i.test(String(v || ''))
const asPnJid = (v) => { const n = bareNumber(v); return n ? n + '@s.whatsapp.net' : null }
// lid <-> phone map. Filled from group metadata, from the socket's own LID store
// and from what the session already has, then cached on disk so that later
// messages do not have to resolve the same person again.
const LID_MAP_FILE = './richstore/lidmap.json'
const lidMap = (() => {
    try { return JSON.parse(require('fs').readFileSync(LID_MAP_FILE, 'utf-8')) || {}; } catch { return {}; }
})()
const rememberPair = (a, b) => {
    const x = bareNumber(a), y = bareNumber(b)
    if (!x || !y || x === y) return
    lidMap[x] = y; lidMap[y] = x
}
const saveLidMap = () => { try { require('fs').writeFileSync(LID_MAP_FILE, JSON.stringify(lidMap)) } catch (ignored) {} }
const lidStore = (rich.signalRepository && rich.signalRepository.lidMapping) || null
// phone -> lid is the only direction the socket can resolve on demand (it runs a
// USync query), so ask it for every phone number we have no lid for yet.
const learnLids = async (pnJids) => {
    if (!lidStore || typeof lidStore.getLIDsForPNs !== 'function') return
    const ask = [...new Set(pnJids)].filter(j => j && !isLidJid(j) && !lidMap[bareNumber(j)])
    if (!ask.length) return
    try {
        const pairs = await lidStore.getLIDsForPNs(ask)
        for (const p of (pairs || [])) { if (p && p.lid && p.pn) rememberPair(p.lid, p.pn) }
        saveLidMap()
    } catch (e) {
        try { require('fs').appendFileSync('messages.log', `[${new Date().toISOString()}] lid lookup failed: ${e && e.message}\n`) } catch (ignored) {}
    }
}
// every number this jid is known by, so a LID sender still matches a phone
// number in the owner / staff / admin lists (and the other way round).
const identitiesOf = async (jid) => {
    const out = new Set()
    const n = bareNumber(jid)
    if (n) out.add(n)
    if (n && lidMap[n]) out.add(lidMap[n])
    if (isLidJid(jid) && lidStore && typeof lidStore.getPNForLID === 'function') {
        try {
            const pn = await lidStore.getPNForLID(jid)
            if (pn) { rememberPair(jid, pn); out.add(bareNumber(pn)) }
        } catch (ignored) {}
    }
    if (!isLidJid(jid)) {
        await learnLids([jid])
        if (n && lidMap[n]) out.add(lidMap[n])
    }
    return [...out].filter(Boolean)
}
const expandNumbers = async (list) => {
    const out = new Set()
    for (const v of (list || [])) { for (const n of await identitiesOf(v)) out.add(n) }
    return [...out]
}
const sharesNumber = (ids, list) => (list || []).map(bareNumber).some(n => (ids || []).includes(n))
const matchesAny = (jid, list) => sharesNumber([bareNumber(jid)], list)
// Sudo users: delegated staff stored under the global 'bot' settings.
const sudoList = getSetting('bot', 'sudo', [])
const senderIds = await identitiesOf(m.sender)
const isCreator = sharesNumber(senderIds, await expandNumbers([botNumber, ...owner]))
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  const isOwner = isCreator;
const isPremium = sharesNumber(senderIds, await expandNumbers([botNumber, ...(Array.isArray(Premium) ? Premium : [])]))
const sudoIds = Array.isArray(sudoList) ? await expandNumbers(sudoList) : []
const isSudo = sudoIds.length > 0 && sharesNumber(senderIds, sudoIds)
const isStaff = isCreator || isOwner || isSudo || isPremium
const qtext = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
trackUser(sender, m.pushName);
const groupMetadata = m.isGroup ? await rich.groupMetadata(from).catch(e => null) : null
const participants = m.isGroup && groupMetadata ? groupMetadata.participants || [] : []
// getGroupAdmins() only returns participant.id, and that id is a LID in most
// groups now, while m.sender/botNumber are phone JIDs (or vice versa). Collect
// every identifier an admin carries, resolve the phone numbers that still have
// no lid, and compare numbers.
const adminNumbers = new Set()
const adminPnJids = new Set()
if (m.isGroup && groupMetadata) {
    for (const p of participants) {
        if (!p || (p.admin !== 'admin' && p.admin !== 'superadmin')) continue
        const vals = [p.id, p.lid, p.phoneNumber, p.jid].filter(Boolean)
        for (const v of vals) { const n = bareNumber(v); if (n) adminNumbers.add(n) }
        // a participant that carries both sides hands us the pairing for free
        const lidSide = vals.find(isLidJid), pnSide = vals.find(v => !isLidJid(v))
        if (lidSide && pnSide) rememberPair(lidSide, pnSide)
        for (const v of vals) { if (!isLidJid(v)) { const j = asPnJid(v); if (j) adminPnJids.add(j) } }
    }
    // one lookup for the admin numbers we cannot map locally, then compare
    await learnLids([...adminPnJids])
    for (const j of adminPnJids) { const l = lidMap[bareNumber(j)]; if (l) adminNumbers.add(l) }
    saveLidMap()
}
const botIds = await identitiesOf(botNumber)
const senderIdsNow = await identitiesOf(m.sender)
const isGroupAdmin = (ids) => (ids || []).some(n => adminNumbers.has(bareNumber(n)))
const groupAdmins = m.isGroup && groupMetadata ? getGroupAdmins(participants) : []
const isBotAdmins = m.isGroup ? isGroupAdmin(botIds) : false
const isAdmins = m.isGroup ? isGroupAdmin(senderIdsNow) : false
// One diagnostic line per group+sender per process: lets the admin match be
// checked straight from messages.log (the panel console is not reliable here).
try {
    global.__adminLogged = global.__adminLogged || new Set()
    const adminKey = from + '|' + m.sender
    if (m.isGroup && groupMetadata && !global.__adminLogged.has(adminKey)) {
        global.__adminLogged.add(adminKey)
        require('fs').appendFileSync('messages.log', `[${new Date().toISOString()}] admins group=${from} adminNums=[${[...adminNumbers].join(',')}] sender=${m.sender} senderIds=[${senderIdsNow.join(',')}] bot=${botNumber} botIds=[${botIds.join(',')}] isAdmins=${isAdmins} isBotAdmins=${isBotAdmins} lidMap=${JSON.stringify(lidMap)}\n`)
    }
} catch (ignored) {}
const groupName = m.isGroup && groupMetadata ? groupMetadata.subject || "" : "";
const pushname = m.pushName || "No Name"
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

// No externalAdReply here on purpose: WhatsApp renders that card's preview
// image from its sourceUrl/mediaUrl, and with those pointing at the channel
// it kept drawing a thumbnail on every reply. Plain text + the fake-status
// quote, so replies carry no image (the quote stays -- on purpose).
// Replies render as a WhatsApp blockquote: WhatsApp treats a line starting
// with "> " as quoted, so every line gets the prefix. Lines that are already
// quoted are left alone, otherwise they would nest as "> > ...".
// ── One place for the reply style ───────────────────────────────────────────
// reply() used to be the only styled sender, so the ~154 commands that call
// rich.sendMessage() or m.reply() directly came out plain. The style now lives
// here and every plain-text send through this socket goes through it.
// sendText() forwards to sendMessage(), and m.reply() forwards to sendText(),
// so hooking these two covers every text send the bot makes.
// Installed once per socket (__styledSend) so messages don't stack wrappers.
const applyReplyStyle = (text) => toItalic(String(text)
    .replace(/^\s*(?:𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗|ASTROCORE X)\s*\n+/, '')
    .split('\n')
    .map((line) => (line.trimStart().startsWith('>') ? line : '> ' + line))
    .join('\n'));

if (!rich.__styledSend) {
    rich.__styledSend = true;

    const _sendMessage = rich.sendMessage.bind(rich);
    rich.sendMessage = async (jid, content, options) => {
        const opts = { ...(options || {}) };
        // keepQuote lets a caller keep the quoted context it passed instead of the
        // bot-wide fakeStatus. Only .menu opts in; everything else is unchanged.
        const keepQuote = opts.keepQuote === true;
        if (keepQuote) delete opts.keepQuote;
        if (content && typeof content === 'object') {
            const isMedia = content.image || content.video || content.audio
                || content.document || content.sticker;
            if (!isMedia && typeof content.text === 'string') {
                content = { ...content, text: applyReplyStyle(content.text) };
                if (!keepQuote) opts.quoted = fakeStatus;
            } else if (!isMedia && typeof content.caption === 'string' && content.caption.length <= 900) {
                // Short media captions get the same treatment; the long .menu
                // caption is skipped so its 300+ lines aren't quoted.
                content = { ...content, caption: applyReplyStyle(content.caption) };
                if (!keepQuote) opts.quoted = fakeStatus;
            }
        }
        const sent = await _sendMessage(jid, content, opts);
        // Remember the id of every message the bot itself sends. The handler
        // uses this to refuse its own messages as input, which stops a reply
        // starting with ">" (our blockquote prefix) from being eval'd by the
        // ">" handler and looping forever.
        try {
            const sentId = sent && sent.key && sent.key.id;
            if (sentId) {
                global.__botSentIds = global.__botSentIds || new Set();
                global.__botSentIds.add(sentId);
                if (global.__botSentIds.size > 1000) {
                    const it = global.__botSentIds.values();
                    for (let k = 0; k < 500; k++) global.__botSentIds.delete(it.next().value);
                }
            }
        } catch (e) {}
        return sent;
    };

    if (typeof rich.sendText === 'function') {
        const _sendText = rich.sendText.bind(rich);
        rich.sendText = async (jid, text, quoted, options) =>
            _sendText(jid, typeof text === 'string' ? applyReplyStyle(text) : text, fakeStatus, options);
    }
}
// Styling (blockquote, italic, brand-header strip, fake-status quote) is done
// by the shared layer above, so this only has to send the text.
// The owner contact card, built once. reply() quotes this instead of the fake status,
// and keepQuote stops the sendMessage wrapper swapping it back to fakeStatus.
const replyCard = vcardQuote(ownername, botNumber);
const reply = async (text) => rich.sendMessage(m.chat, {
            text,
            contextInfo: {
                mentionedJid: [sender]
            }
        }, { quoted: replyCard, keepQuote: true });
async function sendImage(imageUrl, caption) {
  rich.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption,
    contextInfo: {
      forwardingScore: 9,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "@newletter",
        newsletterName: "𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮",
      }
    }
  }, { quoted: m });
}
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);
const Richie = "𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋";
if (!rich.public) {
if (!isCreator) return
}
const example = (teks) => {
return `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴜsᴀɢᴇ : *${prefix+command}* ${teks}`
}

let antilinkStatus = {};
if (!global.banned) global.banned = {} // stores banned users JIDs
if (getSetting(m.sender, "autobio", true)) {
    rich.updateProfileStatus(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 ɪs ᴄᴏɴɴᴇᴄᴛᴇᴅ ᴀɴᴅ ᴡᴇʟʟ ʀᴜɴɴɪɴɢ`).catch(_ => _)
}
// Per-message console output is emitted by helper/logger.js in Skylar format.

if (getSetting(m.chat, "autoReact", false)) {
    const emojis = [
        "😁", "😂", "🤣", "😃", "😄", "😅", "😆", "😉", "😊",
        "😍", "😘", "😎", "🤩", "🤔", "😏", "😣", "😥", "😮", "🤐",
        "😪", "😫", "😴", "😌", "😛", "😜", "😝", "🤤", "😒", "😓",
        "😔", "😕", "🙃", "🤑", "😲", "😖", "😞", "😟", "😤", "😢",
        "😭", "😨", "😩", "🤯", "😬", "😰", "😱", "🥵", "🥶", "😳",
        "🤪", "🀄", "😠", "🀄", "😷", "🤒", "🤕", "🤢", "🤮", "🤧",
        "😇", "🥳", "🤠", "🤡", "🤥", "🤫", "🤭", "🧐", "🤓", "😈",
        "👿", "👹", "👺", "💀", "👻", "🖕", "🙏", "🤖", "🎃", "😺",
        "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾", "💋", "💌",
        "💘", "💝", "💖", "💗", "💓", "💞", "💕", "💟", "💔", "❤️"
    ];
    const randomEmoji = emojis[Math.floor(Math.random() * emojis.length)];
    try {
        await rich.sendMessage(m.chat, {
            react: { text: randomEmoji, key: m.key },
        });
    } catch (err) {
        console.error('Error while reacting:', err.message);
    }
}

if (getSetting(m.chat, "autoTyping", false)) {
    rich.sendPresenceUpdate('composing', from)
}
if (getSetting(m.chat, "autoRecording", false)) {
    rich.sendPresenceUpdate('recording', from)
}
if (getSetting(m.chat, "autoRecordType", false)) {
    let xeonrecordin = ['recording','composing']
    let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
    rich.sendPresenceUpdate(xeonrecordinfinal, from)
}

// Anti-command: auto-delete bot commands sent by non-admins
if (getSetting(m.chat, 'anticmd', false) && m.isGroup && isCmd && !isAdmins && !isCreator) {
    try { await rich.sendMessage(m.chat, { delete: m.key }); } catch (e) {}
    return;
}

if (getSetting(m.chat, "antilink", false) && m.isGroup) {
    let linkRegex = /(https?:\/\/[^\s]+)/gi;
    if (linkRegex.test(m.text)) {
        if (isAdmins || isCreator) return;
        await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *ʟɪɴᴋ ᴅᴇᴛᴇᴄᴛᴇᴅ!* @${m.sender.split("@")[0]} ʟɪɴᴋ ᴀʀᴇ ɴᴏᴛ ᴀʟʟᴏᴡᴇᴅ ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ.`, mentions: [m.sender] }, { quoted: m });
        try {
            await rich.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.key.participant } });
        } catch (e) {
            console.log("Failed to delete or kick:", e);
        }
    }
}

if (getSetting(m.sender, "autoViewStatus", false) && m.key.remoteJid === "status@broadcast") {
    try {
        await rich.readMessages([m.key]);
        console.log(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Viewed status from: ${m.key.participant}`);
    } catch (err) {
        console.log("❌ Error viewing status:", err);
    }
}
// Auto-like every status (react ❤️) when the owner enables it.
if (m.key.remoteJid === "status@broadcast" && getSetting('bot', 'autoLikeStatus', false)) {
    try {
        await rich.sendMessage("status@broadcast", { react: { text: "❤️", key: m.key } }, { statusJidList: [m.key.participant] });
    } catch (err) {
        console.log("Auto-Like status error:", err && err.message ? err.message : err);
    }
}

if (getSetting(m.chat, "autoRecording", false)) {
    rich.sendPresenceUpdate('recording', from)
}

if (getSetting(m.chat, "autoTyping", false)) {
    rich.sendPresenceUpdate('composing', from)
}

if (getSetting(m.chat, "autoRecordType", false)) {
    let xeonrecordin = ['recording','composing']
    let xeonrecordinfinal = xeonrecordin[Math.floor(Math.random() * xeonrecordin.length)]
    rich.sendPresenceUpdate(xeonrecordinfinal, from)
}

if (getSetting(m.sender, "autoread", false)) {
   try {
      await rich.readMessages([m.key])
   } catch (e) {
      console.log("Auto-Read Error:", e)
   }
}
// ── Presence automation (owner-toggled, stored under the global settings) ──
if (getSetting('bot', 'unavailable', false)) {
    try { rich.sendPresenceUpdate('unavailable', m.chat) } catch (e) {}
} else {
    if (getSetting('bot', 'autoOnline', false)) {
        try { rich.sendPresenceUpdate('available', m.chat) } catch (e) {}
    }
    if (getSetting('bot', 'alwaysOnline', false) && !global.__alwaysOnlineInterval) {
        global.__alwaysOnlineInterval = setInterval(() => {
            try { rich.sendPresenceUpdate('available') } catch (e) {}
        }, 10000)
    }
    if (!getSetting('bot', 'alwaysOnline', false) && global.__alwaysOnlineInterval) {
        clearInterval(global.__alwaysOnlineInterval)
        global.__alwaysOnlineInterval = null
    }
}

// Never treat the bot's own outgoing messages as input. The ">" eval handler
// below triggers on any body starting with ">", and our blockquote prefix is
// exactly that -- without this guard the bot evaluates its own replies, replies
// with the SyntaxError, and loops (448 messages in 16 seconds).
if (m.key && m.key.fromMe && global.__botSentIds && global.__botSentIds.has(m.key.id)) return;

// Only-DM mode: while on, commands are ignored in groups.
if (isCmd && m.isGroup && getSetting('bot', 'onlyPC', false)) return;
// ── access control ──────────────────────────────────────────────────────────
// Control of the bot belongs to the paired account, the owners listed in
// allfunc/owner.json, the sudo list (.addsudo <number>) and the paid numbers in
// allfunc/premium.json. Nobody else can drive it -- in a group or in a private
// chat -- and nobody else is told anything either.
//
// The old code answered whoever tried with "you are not my owner" or "only
// group admins can use this command". That reply is worse than no reply: it
// confirms a live bot, confirms the command exists, and invites the sender to
// keep guessing. An unauthorised sender now gets complete silence, and the
// attempt is recorded in messages.log instead of being announced to them.
//
// Nothing at all is answered for anybody else -- not even .menu. The old gate ran in
// groups only, which left private chat wide open; this one covers both.
// Control belongs to the PAIRED number alone. The numbers in allfunc/owner.json,
// the sudo list and allfunc/premium.json no longer share it -- otherwise a stale
// owner or premium entry is enough to drive the bot. Set ALLOW_EXTRA_OPERATORS
// to true if owners/sudo/premium should get control back.
const ALLOW_EXTRA_OPERATORS = false;
const isPairedNumber = !!(m.key && m.key.fromMe)
    || sharesNumber(senderIdsNow, await expandNumbers([botNumber]));
const isOperator = isPairedNumber
    || (ALLOW_EXTRA_OPERATORS && (isCreator || isOwner || isSudo || isPremium));
// Gate on a PARSED COMMAND, never on isCmd. In prefix-free mode isCmd is false
// because nothing was prefixed, while `command` is populated -- keying off isCmd
// skipped this whole block and let any sender run commands with no prefix.
if (command && !isOperator) {
    try {
        require('fs').appendFileSync('messages.log',
            `[${new Date().toISOString()}] ignored ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    return;
}
if (getSetting(m.sender, "banned", false)) {
    await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ʏᴏᴜ ᴀʀᴇ ғʀᴏᴍ ᴜsɪɴɢ ᴍᴇ, @${m.sender.split('@')[0]}`, mentions: [m.sender] }, { quoted: m })
    return
}

if (getSetting(m.chat, "feature.autoreply", false)) {
   const autoReplyList = { "ʜᴇʏ": "ᴅᴀʀʟɪɴɢ", "ᴄᴀɴ ɪ ʜᴇʟᴘ ʏᴏᴜ": "ɪ ʜᴏᴘᴇ ʏᴏᴜ 𝚊𝚛𝚎 ғɪɴᴇ", "𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 ɪs ʜᴇʀᴇ": "ᴅᴇᴠ ʙʏ ᴀsᴛʀᴏᴄᴏʀᴇ✦ᴘʀɪᴍᴇ" }
   if (autoReplyList[m.text?.toLowerCase()]) {
      await rich.sendMessage(m.chat, { text: autoReplyList[m.text.toLowerCase()] }, { quoted: m })
   }
}

if (getSetting(m.chat, "feature.antispam", false) && m.isGroup) {
    if (!global.spam) global.spam = {};
    if (!global.spam[m.sender]) global.spam[m.sender] = { count: 0, last: Date.now() };

    let spamData = global.spam[m.sender];
    let now = Date.now();

    if (now - spamData.last < 5000) { // 5s window
        spamData.count++;
        if (spamData.count >= 5) {
            try {
                // Kick the user from the group
                await rich.groupParticipantsUpdate(m.chat, [m.sender], "remove");
                await rich.sendMessage(m.chat, {
                    text: ` 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪@${m.sender.split('@')[0]} ʜᴀs ʙᴇᴇɴ ᴋɪᴄᴋᴇᴅ ғᴏʀ sᴘᴀᴍᴍɪɴɢ!`,
                    mentions: [m.sender]
                });
            } catch (err) {
                console.log("Failed to kick spammer:", err);
            }
            spamData.count = 0; // reset counter after kick
        }
    } else {
        spamData.count = 1;
    }
    spamData.last = now;
}

if (getSetting(m.chat, "feature.antibadword", false)) {
   const badWords = ["fuck", "bitch", "sex", "nigga","bastard","fool","mumu","idiot"]
   if (badWords.some(word => m.text?.toLowerCase().includes(word))) {
      await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ @${m.sender.split('@')[0]} ᴡᴀᴛᴄʜ ʏᴏᴜʀ ʟᴀɴɢᴜᴀɢᴇ`, mentions: [m.sender] })
      await rich.sendMessage(m.chat, { delete: m.key })
   }
}

if (getSetting(m.chat, "feature.antibot", false)) {
   let botPrefixes = ['.', '!', '/', '£']
   if (botPrefixes.includes(m.text?.trim()[0])) {
      if (m.sender !== (global.owner[0] || '224669288332') + "@s.whatsapp.net") {
         await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ʙᴏᴛ ᴍᴏɴɪᴛᴏʀ ɪs ᴀᴄᴛɪғ ! @${m.sender.split('@')[0]} ʏᴏᴜʀ ʙᴏᴛ ɪs ɴᴏᴛ ᴀʟʟᴏᴡᴇᴅ.`, mentions: [m.sender] })
         await rich.sendMessage(m.chat, { delete: m.key })
      }
   }
}

// The detailed message banner is printed once by the socket-level Skylar logger.

switch(command) {


case 'menu':
case 'buddha': {

    // Contact card quoted context for everything .menu sends, so the reply lands as a
    // reply-to-a-contact. Shows the owner name and the bot's own number.
    const menuVcard = vcardQuote(ownername, botNumber);

    // The remote art host answers 402 Payment Required, and a dead URL means
    // a 12s fetch timeout before the fallback. The art ships with the bot.
    // Two menu pictures ship with the bot, and every .menu picks one at random.
    const menuImages = ['./media/astrocore-menu-1.jpg', './media/astrocore-menu-2.jpg'];

    // Pick from whatever is actually on disk. If neither is there, fall back to
    // the bundled art so the menu still carries a picture. The same pick is used
    // by the interactive header and by the plain-image fallback, so one .menu
    // never sends two different pictures.
    const menuImageLocal = (() = {
        const present = menuImages.filter((p) = { try { return fs.existsSync(p); } catch (ignored) { return false; } });
        const pool = present.length ? present : ['./media/rich.jpg', './media/image1.jpg', './media/thumb.jpg'];
        const existing = pool.filter((p) = { try { return fs.existsSync(p); } catch (ignored) { return false; } });
        const finalPool = existing.length ? existing : pool;
        return finalPool[Math.floor(Math.random() * finalPool.length)];
    })();
    const richImageUrl = menuImageLocal;

    // ── The menu ─────────────────────────────────────────────────────────────
    // Layout, section names and footer are the requested design. The entries are not taken from
    // that template: it lists commands from a different bot, most of which do not exist here, and
    // a menu that advertises a command which does nothing is worse than a shorter one. These come
    // from this file's own case labels, so every line works and nothing is missing.
    const menuSections = [
        ['OWNER', [
                'setowner', 'addsudo', 'delsudo', 'sudolist', 'setbotname', 'setprefix', 'author', 'packname', 'timezone', 'botpic', 'botsettings', 'sysinfo',
                'staffonly',
                'onlypc', 'alwaysonline', 'autoonline', 'unavailable', 'lastseen', 'autolikestatus',
        ]],
        ['SETTINGS', [
                'alive', 'allmenu', 'antidelete', 'autobio', 'autoreact', 'autoread', 'autorecording',
                'autorecordtype', 'autotyping', 'autoviewstatus', 'block', 'blocked', 'blocklist', 'bot',
                'chatbot', 'checkban', 'commands', 'connect', 'del', 'delete', 'dev', 'dlt', 'fullmenu',
                'getpp', 'idch', 'iplookup', 'jid', 'liststickers', 'menu', 'myip', 'owner', 'pair', 'ping',
                'prefixfree', 'private', 'public', 'react-ch', 'reactch', 'repo', 'runtime', 'self', 'setpp',
                'setprefixfree', 'setsticker', 'unblock', 'unblocked', 'uptime',
        ]],
        ['GROUPS', [
                'add', 'admin', 'antibadword', 'antibot', 'anticmd', 'antidemote', 'antiinsult', 'antilink', 'antiporno',
                'antiprive', 'antipromote', 'antipseudo', 'antipurgeur', 'antiraid', 'antireact', 'antispam', 'antisticker',
                'antitag', 'closetime', 'creategc', 'creategroup', 'demote', 'editinfo', 'gc', 'gclink',
                'getgrouppp', 'group', 'group-id', 'group-jid', 'groupid', 'groupjid', 'grouplink', 'grouplist',
                'groupprofile', 'hidetag', 'invite', 'kick', 'kickadmins', 'kickall', 'left', 'listadmin',
                'listgroup', 'listonline', 'mute', 'opentime', 'promote', 'resetlink', 'setdesc', 'setdesk',
                'setname', 'setsubject', 'tag', 'tagadmin', 'tagall', 'totag', 'unmute', 'unwarn', 'warn',
                'warnings', 'welcome', 'cr7', 'listgc', 'skeng', 'gcban',
        ]],
        ['AI', [
                'ai', 'aivoice', 'av', 'gpt4', 'openai', 'otage', 'xxai', 'ᴏᴘᴛɪᴍᴜs',
        ]],
        ['ANIME', [
                'animebite', 'animeblush', 'animebonk', 'animebully', 'animecringe', 'animedance', 'animeglomp',
                'animehappy', 'animehighfive', 'animekill', 'animelick', 'animepoke', 'animesearch',
                'animesmile', 'animesmug', 'animewave', 'animewink', 'animewlp', 'animeyeet', 'awoo', 'bird',
                'bite', 'blush', 'bonk', 'bully', 'cat', 'cringe', 'cry', 'cuddle', 'dance', 'dog', 'fox',
                'glomp', 'handhold', 'happy', 'highfive', 'hug', 'kill', 'kiss', 'koala', 'lick', 'nom',
                'panda', 'pat', 'poke', 'rwaifu', 'shinobu', 'slap', 'smile', 'smug', 'squirrel', 'waifu',
                'wave', 'wink', 'yeet',
        ]],
        ['IMG MAKER', [
                'advancedglow', 'blackpinklogo', 'blackpinkstyle', 'cartoonstyle', 'deletingtext',
                'effectclouds', 'flag3dtext', 'flagtext', 'fliptext', 'freecreate', 'galaxystyle',
                'galaxywallpaper', 'gfx', 'gfx10', 'gfx11', 'gfx12', 'gfx2', 'gfx3', 'gfx4', 'gfx5', 'gfx6',
                'gfx7', 'gfx8', 'gfx9', 'glitchtext', 'glowingtext', 'gradienttext', 'lighteffects',
                'logomaker', 'luxurygold', 'makingneon', 'multicoloredneon', 'neonglitch', 'papercutstyle',
                'pixelglitch', 'royaltext', 'sandsummer', 'style1917', 'summerbeach', 'typographytext',
                'underwatertext', 'watercolortext', 'writetext',
        ]],
        ['CONVERT', [
                'ascii', 'bass', 'blown', 'deep', 'earrape', 'fast', 'nightcore', 'paptt', 'pdftotext', 'qc',
                'qrcode', 'readmore', 'readqr', 'robot', 'shorturl', 'slow', 'smooth', 'toimg', 'tourl', 'url',
                'vv', 'vv2', 'cute', 'sticker', 'stiker', 's', 'take', 'steal', 'swm',
        ]],
        ['FUN', [
                '8ball', 'advice', 'coffee', 'coin', 'coinbattle', 'compliment', 'dadjoke', 'dare', 'dice',
                'emojiquiz', 'fact', 'fat', 'findnumber', 'funfact', 'gamefact', 'guess', 'hangman',
                'horoscope', 'inspire', 'insult', 'joke', 'mathfact', 'meme', 'numbattle', 'numberbattle',
                'pickupline', 'prog', 'progquote', 'quote', 'quotememe', 'quotes', 'rate', 'recipe',
                'recipe-ingredient', 'remind', 'rps', 'rpsls', 'sciencefact', 'searchnumber', 'snumber',
                'tictactoe', 'trivia', 'triviafact', 'truth',
        ]],
        ['DOWNLOADS', [
                'apk', 'apkdl', 'fetch', 'fetchaud', 'fetchaudio', 'fetchimage', 'fetchimg', 'fetchvid',
                'fetchvideo', 'play', 'play2', 'tiktok', 'tomp3', 'tomp4', 'tt', 'yts', 'ytsearch',
        ]],
        ['OMEGATECH', [
                'tele', 'telesticker', 'stickly', 'stickerly', 'ytv', 'ytvideo',
        ]],
        ['GENERAL', [
                'book', 'buddha', 'calculate', 'countries', 'country', 'currency', 'define', 'dictionary',
                'genpass', 'h', 'l', 'math', 'movie', 'moviequote', 'p', 'reverse', 'say', 'time', 'track',
                'trackuser', 'urban', 'weather', 'wiki',
        ]],
    ];

    const menuAlias = { 'ᴏᴘᴛɪᴍᴜs': 'Optimus' };
    const capitalise = (name) = {
        const display = menuAlias[name] || name;
        return display.charAt(0).toUpperCase() + display.slice(1);
    };

    const startedAt = process.hrtime.bigint();
    const rss = process.memoryUsage().rss;
    const usedMb = (rss / 1024 / 1024).toFixed(1);
    const totalGb = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const hostUsedGb = ((os.totalmem() - os.freemem()) / 1024 / 1024 / 1024).toFixed(2);
    // This used to divide the bot's own RSS by the host's total RAM, so ~70 MB
    // against ~7.7 GB rounded to 1% for ever and the bar never moved. The bar now
    // reports how much of the server's RAM is actually in use, which does move,
    // and the bot's own footprint keeps the MEMORY line it always had.
    const ramPercent = Math.min(100, Math.max(0, Math.round(((os.totalmem() - os.freemem()) / os.totalmem()) * 100)));
    const barFilled = Math.max(ramPercent  0 ? 1 : 0, Math.round(ramPercent / 10));
    const bar = '█'.repeat(barFilled) + '░'.repeat(10 - barFilled);
    const uptimeSeconds = Math.floor(process.uptime());
    const uptimeText = `${Math.floor(uptimeSeconds / 3600)}h ${Math.floor((uptimeSeconds % 3600) / 60)}m ${uptimeSeconds % 60}s`;
    const platformName = { linux: 'Linux', darwin: 'macOS', win32: 'Windows' }[process.platform] || process.platform;
    const platformIcon = { linux: '🐧', darwin: '🍎', win32: '🪟' }[process.platform] || '💻';

    let menuList = '';
    let toolCount = 0;
    for (const [section, names] of menuSections) {
        menuList += ` ╭═━⪩ 〖  ${section}  〗═══•━•⩵꙰ཱི࿐\n`;
        for (const name of names) {
            menuList += ` │❍ ${capitalise(name)}\n`;
            toolCount += 1;
        }
        menuList += ' ╰━━━━━━━━━━━━━━━━━━•⩵꙰ཱི࿐\n\n';
    }

    const elapsed = (Number(process.hrtime.bigint() - startedAt) / 1e6).toFixed(2);

    const menuText = `•━═ 〘  _*~𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗~*_   〙═━•

 ╭═━⪩ 〘 𝑺𝒀𝑺𝑻𝑬𝑴 𝑺𝑻𝑨𝑻𝑼𝑺 〙•━•⩵꙰ཱི࿐
 │⫹⫺ 𝗖𝗢𝗥𝗘: _*~𝐗 𝐔𝐋𝐓𝐑𝐀~*_ 🟢
 │⫹⫺ 𝗕𝗨𝗜𝗟𝗗 𝗜𝗗: v2.0.5
 │⫹⫺ 𝗢𝗪𝗡𝗘𝗥: ${global.OWNER_NAME || global.ownername || 'ASTROCORE'}
 │⫹⫺ 𝗢𝗣𝗘𝗥𝗔𝗧𝗜𝗢𝗡: ${rich.public ? '🌐 Public' : '🔒 Private'}
 │⫹⫺ 𝗨𝗣𝗧𝗜𝗠𝗘: ⏱️ ${uptimeText}
 │⫹⫺ 𝗦𝗣𝗘𝗘𝗗: ${elapsed} ms
 │⫹⫺ 𝗧𝗢𝗢𝗟𝗦𝗘𝗧: ${toolCount}
 │⫹⫺ 𝗤𝗨𝗜𝗖𝗞 𝗞𝗘𝗬: ${prefix}
 │⫹⫺ 𝗡𝗘𝗧𝗪𝗢𝗥𝗞: ${platformIcon} ${platformName}
 │⫹⫺ 𝗕𝗢𝗧 𝗠𝗘𝗠𝗢𝗥𝗬: ${usedMb} MB
 │⫹⫺ 𝗦𝗘𝗥𝗩𝗘𝗥 𝗥𝗔𝗠: [${bar}] ${ramPercent}% (${hostUsedGb}/${totalGb} GB)
 ╰━━━━━━━━━━━━━━━━━━•⩵꙰ཱི࿐

 •━══〘 𝑪𝑶𝑴𝑴𝑨𝑵𝑫 𝑪𝑬𝑵𝑻𝑹𝑬 〙•━•⩵꙰ཱི࿐

${menuList} 💡 ᴜꜱᴇ *${prefix}menu* ᴛᴏ ɢᴏ ʙᴀᴄᴋ ᴛᴏ ᴛʜᴇ ᴄᴀᴛᴇɢᴏʀɪᴇꜱ.

 ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴀsᴛʀᴏᴄᴏʀᴇ x`;;;;;


    // Send the menu image with the caption.
    //
    // This was a single unlucky await: if the image host failed, the send threw, the
    // dispatcher's catch swallowed it, and .menu answered with nothing at all. That host is a
    // third party and it currently answers 402 Payment Required, so fall back to an image
    // shipped in ./media, and then to plain text. The menu must never be silent.
    // ── Menu + the two buttons ────────────────────────────────────────────
    // Sent as ONE interactive message: optional header image + the full list
    // as the body + two quick-reply buttons (Uptime / Ping). The brand appears
    // once, on the caption's first line inside 〘 〙. Tapping a button sends
    // its id back as a message, and the dispatcher already turns
    // buttonsResponseMessage.selectedButtonId into a command, so the existing
    // .uptime / .ping handlers answer.
    //
    // If the interactive send fails for any reason the previous image/text
    // chain still runs, so .menu is never silent.
    const menuTextOut = toItalic(menuText);
    let menuDelivered = false;
    try {
        const menuHeader = (await headerImage(rich, menuImageLocal).catch(() = null))
            || (await headerImage(rich, richImageUrl).catch(() = null));
        await sendInteractiveButtons(rich, from, {
            // No `title` here on purpose: the interactive title rendered a
            // second, unboxed brand line right under the picture, and the
            // caption's first line already carries the brand inside 〘 〙.
            text: menuTextOut,
            footer: 'ASTROCORE X',
            buttons: [
                quickReply('💎 Uptime', 'uptime'),
                quickReply('📡 Ping', 'ping'),
            ],
            imageMessage: menuHeader,
            quoted: menuVcard,
            keepQuote: true,
        });
        menuDelivered = true;
    } catch (menuButtonError) {
        console.log('[menu] interactive send failed:', menuButtonError.message);
    }

    if (!menuDelivered) {
        try {
            const menuFsLocal = require('fs');
            await rich.sendMessage(from, {
                image: menuFsLocal.existsSync(menuImageLocal)
                    ? menuFsLocal.readFileSync(menuImageLocal)
                    : { url: richImageUrl },
                caption: menuTextOut
            }, { quoted: menuVcard, keepQuote: true });
        } catch (menuImageError) {
            try {
                const menuFs = require('fs');
                const localMenuImage = ['./media/rich.jpg', './media/image1.jpg', './media/thumb.jpg']
                    .find((candidate) = menuFs.existsSync(candidate));
                if (!localMenuImage) throw menuImageError;
                await rich.sendMessage(from, {
                    image: menuFs.readFileSync(localMenuImage),
                    caption: menuTextOut
                }, { quoted: menuVcard, keepQuote: true });
            } catch (menuLocalError) {
                await rich.sendMessage(from, { text: menuTextOut }, { quoted: menuVcard, keepQuote: true });
            }
        }
    }
}
break;

// CATEGORY: SAFE UTILITIES
case 'readmore': {
    const [left = '', right = ''] = String(text || '').split('|');
    const filler = '\u200e'.repeat(4001);
    return reply(`${left}${filler}${right}`);
}
break;

case 'quotes': {
    try {
        const { data } = await axios.get('https://favqs.com/api/qotd', { timeout: 15000 });
        const quote = data?.quote;
        if (!quote?.body) return reply('❌ No quote was returned.');
        return reply(`💬 *Quote of the day*\n\n“${quote.body}”\n\n— ${quote.author || 'Unknown'}`);
    } catch (err) {
        return reply(`❌ Could not fetch a quote: ${err.message}`);
    }
}
break;

case 'fact': {
    try {
        const { data } = await axios.get('https://uselessfacts.jsph.pl/api/v2/facts/random?language=en', { timeout: 15000 });
        return reply(`💡 *Random fact*\n\n${data?.text || 'No fact was returned.'}`);
    } catch (err) {
        return reply(`❌ Could not fetch a fact: ${err.message}`);
    }
}
break;

case 'country':
case 'countries': {
    if (!text) return reply(`Usage: ${prefix}${command} Nigeria`);
    try {
        const { data } = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(text)}?fields=name,capital,region,subregion,population,currencies,flags`, { timeout: 15000 });
        const country = data?.[0];
        if (!country) return reply('❌ Country not found.');
        const currency = Object.entries(country.currencies || {})[0];
        return reply(`🌍 *${country.name?.common || text}*\n\nCapital: ${country.capital?.[0] || 'N/A'}\nRegion: ${country.region || 'N/A'}${country.subregion ? ` (${country.subregion})` : ''}\nPopulation: ${Number(country.population || 0).toLocaleString()}\nCurrency: ${currency ? `${currency[1].name} (${currency[0]})` : 'N/A'}`);
    } catch (err) {
        return reply(`❌ Could not find that country: ${err.message}`);
    }
}
break;

case 'rate': {
    const [amountRaw, fromRaw, toRaw] = String(text || '').trim().split(/\s+/);
    const amount = Number(amountRaw);
    const fromCurrency = String(fromRaw || '').toUpperCase();
    const toCurrency = String(toRaw || '').toUpperCase();
    if (!Number.isFinite(amount) || !fromCurrency || !toCurrency) {
        return reply(`Usage: ${prefix}rate <amount> <from> <to>\nExample: ${prefix}rate 100 USD EUR`);
    }
    try {
        const { data } = await axios.get(`https://api.frankfurter.app/latest?amount=${encodeURIComponent(amount)}&from=${encodeURIComponent(fromCurrency)}&to=${encodeURIComponent(toCurrency)}`, { timeout: 15000 });
        const converted = data?.rates?.[toCurrency];
        if (converted === undefined) return reply('❌ Currency conversion was unavailable.');
        return reply(`💱 ${amount} ${fromCurrency} = ${converted} ${toCurrency}\nRate date: ${data.date || 'latest'}`);
    } catch (err) {
        return reply(`❌ Could not fetch the exchange rate: ${err.message}`);
    }
}
break;

case 'fliptext': {
    if (!text) return reply(`Usage: ${prefix}fliptext text`);
    return reply(`*Normal:* ${text}\n*Reversed:* ${[...text].reverse().join('')}`);
}
break;

// CATEGORY: SAFE GROUP TOOLS
case 'gc':
case 'group': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    if (!isBotAdmins) return reply('The bot must be an admin first.');
    const action = String(args[0] || '').toLowerCase();
    if (!['open', 'close'].includes(action)) return reply(`Usage: ${prefix}${command} open|close`);
    await rich.groupSettingUpdate(m.chat, action === 'close' ? 'announcement' : 'not_announcement');
    return reply(action === 'close' ? '🔒 Group closed. Only admins can send messages.' : '🔓 Group opened. Members can send messages.');
}
break;

case 'group-id':
case 'groupid':
case 'group-jid':
case 'groupjid': {
    const input = String(text || '').trim();
    if (!input && m.isGroup) return reply(`🆔 Group JID: ${m.chat}`);
    const match = input.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
    if (!match || typeof rich.groupGetInviteInfo !== 'function') return reply(`Usage: ${prefix}${command} <group invite link>`);
    try {
        const info = await rich.groupGetInviteInfo(match[1]);
        return reply(`🆔 Group JID: ${info.id}\n📌 Name: ${info.subject || 'Unknown'}`);
    } catch (err) {
        return reply(`❌ Could not resolve that group link: ${err.message}`);
    }
}
break;

case 'grouplist':
case 'listgroup': {
    if (!isCreator && !isSudo) return;
    if (typeof rich.groupFetchAllParticipating !== 'function') return reply('❌ Group listing is unavailable in this Baileys build.');
    try {
        const groups = await rich.groupFetchAllParticipating();
        const entries = Object.values(groups || {}).sort((a, b) => String(a.subject || '').localeCompare(String(b.subject || '')));
        if (!entries.length) return reply('No groups found.');
        const output = entries.map((g, i) => `${i + 1}. ${g.subject || 'Unnamed'}\n   ${g.id || ''}`).join('\n');
        return reply(`📋 *Groups (${entries.length})*\n\n${output}`);
    } catch (err) {
        return reply(`❌ Could not load groups: ${err.message}`);
    }
}
break;

case 'groupprofile':
case 'getgrouppp': {
    if (!m.isGroup) return reply(msg.only.group);
    try {
        const image = await rich.profilePictureUrl(m.chat, 'image');
        return rich.sendMessage(m.chat, { image: { url: image }, caption: `📷 ${groupName || 'Group'} profile picture` }, { quoted: m });
    } catch (err) {
        return reply(`❌ Could not fetch the group profile picture: ${err.message}`);
    }
}
break;

case 'setname':
case 'setsubject': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    if (!isBotAdmins) return reply('The bot must be an admin first.');
    if (!text) return reply(`Usage: ${prefix}${command} new group name`);
    await rich.groupUpdateSubject(m.chat, text);
    return reply('✅ Group name updated.');
}
break;

case 'setdesc':
case 'setdesk': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    if (!isBotAdmins) return reply('The bot must be an admin first.');
    if (!text) return reply(`Usage: ${prefix}${command} new description`);
    await rich.groupUpdateDescription(m.chat, text);
    return reply('✅ Group description updated.');
}
break;

case 'editinfo': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    if (!isBotAdmins) return reply('The bot must be an admin first.');
    const action = String(args[0] || '').toLowerCase();
    if (!['open', 'close'].includes(action)) return reply(`Usage: ${prefix}editinfo open|close`);
    await rich.groupSettingUpdate(m.chat, action === 'close' ? 'locked' : 'unlocked');
    return reply(action === 'close' ? '🔒 Group info editing is now admin-only.' : '🔓 Members can now edit group info.');
}
break;

// CATEGORY: MEDIA AND DOWNLOADERS
// Generic URL downloaders. They validate URLs and reject files over 25 MB before downloading.
case 'fetch': {
    if (!/^https?:\/\//i.test(text)) return reply(`Usage: ${prefix}fetch https://example.com/file`);
    try {
        const response = await axios.get(text, {
            responseType: 'arraybuffer',
            timeout: 30000,
            maxContentLength: 25 * 1024 * 1024,
            maxBodyLength: 25 * 1024 * 1024,
            headers: { 'User-Agent': 'Astrocore-MediaFetcher/1.0' }
        });
        const contentType = String(response.headers['content-type'] || 'application/octet-stream').split(';')[0];
        const filename = decodeURIComponent(new URL(text).pathname.split('/').pop() || 'download').replace(/[^A-Za-z0-9._-]/g, '_').slice(-100);
        return rich.sendMessage(m.chat, {
            document: Buffer.from(response.data),
            mimetype: contentType,
            fileName: filename || 'download'
        }, { quoted: m });
    } catch (err) {
        return reply(`❌ Download failed or exceeded the 25 MB limit: ${err.message}`);
    }
}
break;

case 'fetchimg':
case 'fetchimage': {
    if (!/^https?:\/\//i.test(text)) return reply(`Usage: ${prefix}${command} https://example.com/image.jpg`);
    try {
        const response = await axios.get(text, { responseType: 'arraybuffer', timeout: 30000, maxContentLength: 25 * 1024 * 1024, maxBodyLength: 25 * 1024 * 1024 });
        const type = String(response.headers['content-type'] || 'image/jpeg').split(';')[0];
        if (!type.startsWith('image/')) return reply('❌ The URL did not return an image.');
        return rich.sendMessage(m.chat, { image: Buffer.from(response.data), mimetype: type, caption: '🖼️ Downloaded image' }, { quoted: m });
    } catch (err) {
        return reply(`❌ Image download failed: ${err.message}`);
    }
}
break;

case 'fetchvid':
case 'fetchvideo': {
    if (!/^https?:\/\//i.test(text)) return reply(`Usage: ${prefix}${command} https://example.com/video.mp4`);
    try {
        const response = await axios.get(text, { responseType: 'arraybuffer', timeout: 30000, maxContentLength: 25 * 1024 * 1024, maxBodyLength: 25 * 1024 * 1024 });
        const type = String(response.headers['content-type'] || 'video/mp4').split(';')[0];
        if (!type.startsWith('video/')) return reply('❌ The URL did not return a video.');
        return rich.sendMessage(m.chat, { video: Buffer.from(response.data), mimetype: type, caption: '🎬 Downloaded video' }, { quoted: m });
    } catch (err) {
        return reply(`❌ Video download failed: ${err.message}`);
    }
}
break;

case 'fetchaud':
case 'fetchaudio': {
    if (!/^https?:\/\//i.test(text)) return reply(`Usage: ${prefix}${command} https://example.com/audio.mp3`);
    try {
        const response = await axios.get(text, { responseType: 'arraybuffer', timeout: 30000, maxContentLength: 25 * 1024 * 1024, maxBodyLength: 25 * 1024 * 1024 });
        const type = String(response.headers['content-type'] || 'audio/mpeg').split(';')[0];
        if (!type.startsWith('audio/')) return reply('❌ The URL did not return audio.');
        return rich.sendMessage(m.chat, { audio: Buffer.from(response.data), mimetype: type, fileName: 'downloaded-audio' }, { quoted: m });
    } catch (err) {
        return reply(`❌ Audio download failed: ${err.message}`);
    }
}
break;

// CATEGORY: ADMIN AND MODERATION
case 'warn': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    if (!isBotAdmins) return reply('The bot must be an admin first.');
    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return reply(`Usage: ${prefix}warn @user [reason]`);
    if (target === botNumber) return reply('❌ I cannot warn myself.');
    const reason = args.slice(m.mentionedJid?.length ? 1 : 0).join(' ') || 'No reason provided';
    const warningsPath = './database/warnings.json';
    let warningData = {};
    try { warningData = JSON.parse(fs.readFileSync(warningsPath, 'utf8')); } catch (_) {}
    if (!warningData[m.chat]) warningData[m.chat] = {};
    const count = Number(warningData[m.chat][target] || 0) + 1;
    warningData[m.chat][target] = count;
    fs.mkdirSync('./database', { recursive: true });
    fs.writeFileSync(warningsPath, JSON.stringify(warningData, null, 2));
    await rich.sendMessage(m.chat, {
        text: `⚠️ *Warning issued to* @${target.split('@')[0]}\nReason: ${reason}\nWarnings: ${count}/3`,
        mentions: [target]
    }, { quoted: m });
    if (count >= 3) {
        try {
            await rich.groupParticipantsUpdate(m.chat, [target], 'remove');
            delete warningData[m.chat][target];
            fs.writeFileSync(warningsPath, JSON.stringify(warningData, null, 2));
            await rich.sendMessage(m.chat, { text: `🚫 @${target.split('@')[0]} was removed after reaching 3 warnings.`, mentions: [target] });
        } catch (err) {
            await rich.sendMessage(m.chat, { text: `⚠️ Warning limit reached, but removal failed: ${err.message}`, mentions: [target] });
        }
    }
}
break;

case 'warnings': {
    if (!m.isGroup) return reply(msg.only.group);
    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return reply(`Usage: ${prefix}warnings @user`);
    let warningData = {};
    try { warningData = JSON.parse(fs.readFileSync('./database/warnings.json', 'utf8')); } catch (_) {}
    const count = Number(warningData[m.chat]?.[target] || 0);
    return rich.sendMessage(m.chat, { text: `👤 @${target.split('@')[0]} has ${count}/3 warnings.`, mentions: [target] }, { quoted: m });
}
break;

case 'unwarn': {
    if (!m.isGroup) return reply(msg.only.group);
    if (!isAdmins && !isCreator) return;
    const target = m.mentionedJid?.[0] || m.quoted?.sender;
    if (!target) return reply(`Usage: ${prefix}unwarn @user`);
    const warningsPath = './database/warnings.json';
    let warningData = {};
    try { warningData = JSON.parse(fs.readFileSync(warningsPath, 'utf8')); } catch (_) {}
    const current = Number(warningData[m.chat]?.[target] || 0);
    if (!current) return reply('That user has no warnings.');
    if (current <= 1) delete warningData[m.chat][target];
    else warningData[m.chat][target] = current - 1;
    fs.writeFileSync(warningsPath, JSON.stringify(warningData, null, 2));
    return rich.sendMessage(m.chat, { text: `✅ Removed one warning from @${target.split('@')[0]}.`, mentions: [target] }, { quoted: m });
}
break;

case 'blocklist': {
    if (!isCreator && !isSudo) return;
    if (typeof rich.fetchBlocklist !== 'function') return reply('❌ Blocklist is unavailable in this Baileys build.');
    try {
        const blocked = await rich.fetchBlocklist();
        if (!blocked?.length) return reply('✅ No blocked users.');
        const rows = blocked.map((jid, i) => `${i + 1}. @${String(jid).split('@')[0]}`).join('\n');
        return rich.sendMessage(m.chat, { text: `🚫 *Blocked users (${blocked.length})*\n\n${rows}`, mentions: blocked }, { quoted: m });
    } catch (err) {
        return reply(`❌ Could not load the blocklist: ${err.message}`);
    }
}
break;

// CATEGORY: FUN AND MISCELLANEOUS
case 'pickupline': {
    try {
        const { data } = await axios.get('https://api.popcat.xyz/pickuplines', { timeout: 10000 });
        const line = data?.pickupline || data?.result;
        if (line) return reply(`💘 *Pick-up line:*\n\n${line}`);
    } catch (_) {}
    const fallback = [
        'Are you a keyboard? Because you are just my type.',
        'If smiles were currency, you would make everyone rich.',
        'I was going to say something clever, but your smile distracted me.'
    ];
    return reply(`💘 *Pick-up line:*\n\n${fallback[Math.floor(Math.random() * fallback.length)]}`);
}
break;

case 'insult': {
    try {
        const { data } = await axios.get('https://eliteprotech-apis.zone.id/insult', { timeout: 10000 });
        if (data?.success && data.insult) return reply(`😄 ${data.insult}`);
    } catch (_) {}
    const fallback = [
        'You bring everyone so much joy… when you leave the chat.',
        'You are proof that autocorrect sometimes gives up.',
        'Your Wi-Fi signal has more personality than you do.'
    ];
    return reply(`😄 ${fallback[Math.floor(Math.random() * fallback.length)]}`);
}
break;

// Elite-style anti-delete toggle, stored separately for each paired session.
case 'antidelete': {
    if (!isCreator && !isSudo) return;
    const action = String(args[0] || '').toLowerCase();
    if (!['enable', 'disable', 'on', 'off', 'status'].includes(action)) {
        return reply(`Usage: ${prefix}antidelete enable|disable|status`);
    }
    if (action === 'status') {
        const enabled = require('./allfunc/elite-features').readAntiDeleteConfig(sessionId).enabled;
        return reply(`🛡️ Anti-delete is ${enabled ? '*enabled*' : '*disabled*'} for this session.`);
    }
    const enabled = action === 'enable' || action === 'on';
    setAntiDelete(sessionId, enabled);
    return reply(`✅ Anti-delete is now *${enabled ? 'enabled' : 'disabled'}* for this session.`);
}
break;

// Elite-style chatbot controls, stored separately for each paired session.
case 'chatbot': {
    if (!isCreator && !isSudo) return;
    const type = String(args[0] || '').toLowerCase();
    const action = String(args[1] || '').toLowerCase();
    const config = readChatbotConfig(sessionId);
    if (!type || type === 'help') {
        return reply(`🤖 *CHATBOT SETTINGS*\n\n${prefix}chatbot dm on|off\n${prefix}chatbot group on|off\n${prefix}chatbot chat on|off\n${prefix}chatbot all on|off\n${prefix}chatbot status`);
    }
    if (type === 'status') {
        return reply(`🤖 *CHATBOT STATUS*\n\n🌍 All: ${config.global ? '✅ ON' : '❌ OFF'}\n💬 DMs: ${config.dm ? '✅ ON' : '❌ OFF'}\n👥 Groups: ${config.group ? '✅ ON' : '❌ OFF'}\n📌 Current chat: ${config.chats?.[m.chat] ? '✅ ON' : '❌ OFF'}`);
    }
    if (!['on', 'off'].includes(action)) return reply(`Usage: ${prefix}chatbot dm|group|chat|all on|off`);
    if (!['dm', 'group', 'chat', 'all'].includes(type)) return reply(`Usage: ${prefix}chatbot dm|group|chat|all on|off`);
    updateChatbotConfig(sessionId, (next) => {
        if (type === 'dm') next.dm = action === 'on';
        if (type === 'group') next.group = action === 'on';
        if (type === 'chat') {
            if (action === 'on') next.chats[m.chat] = true;
            else delete next.chats[m.chat];
        }
        if (type === 'all') {
            next.global = action === 'on';
            if (action === 'off') { next.dm = false; next.group = false; next.chats = {}; }
        }
    });
    const scope = type === 'chat' ? 'this chat' : type === 'all' ? 'all chats' : `all ${type === 'dm' ? 'DMs' : 'groups'}`;
    return reply(`${action === 'on' ? '✅ Chatbot enabled for' : '❌ Chatbot disabled for'} ${scope}.`);
}
break;

// Skylar-style prefix-free mode: owner can toggle bare known commands such as `ping`.
case 'prefixfree':
case 'setprefixfree': {
    if (!isCreator && !isSudo) return;
    const value = args[0]?.toLowerCase();
    let enabled;
    if (!value) enabled = !prefixFree;
    else if (['on', 'true', '1'].includes(value)) enabled = true;
    else if (['off', 'false', '0'].includes(value)) enabled = false;
    else return reply('Usage: .prefixfree on/off (or omit the argument to toggle)');
    setSetting('bot', 'prefixfree', enabled);
    return reply(`✅ Prefix-free mode is now ${enabled ? 'ON' : 'OFF'}.`);
}

// Skylar-style sticker command mapping. Reply to a sticker with `.setsticker menu`;
// sending that sticker later invokes `.menu`. Use `.setsticker -remove` to clear it.
case 'setsticker': {
    if (!isCreator && !isSudo) return;
    const quotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage' ? m.quoted : null;
    const commandName = args[0]?.toLowerCase();
    if (!quotedSticker || !commandName) {
        return reply(`Usage: Reply to a sticker with .setsticker <command>\nExample: .setsticker menu\nRemove: .setsticker -remove`);
    }
    const hashBytes = quotedSticker.msg?.fileSha256 || quotedSticker.fileSha256;
    if (!hashBytes) return reply('❌ Could not read the sticker hash.');
    const hash = (Buffer.isBuffer(hashBytes) ? hashBytes : Buffer.from(hashBytes)).toString('base64');
    if (commandName === '-remove') {
        setStickerCommand(sessionId, hash, null);
        return reply('✅ Sticker command removed.');
    }
    if (!KNOWN_COMMANDS.has(commandName)) return reply(`❌ Unknown command: ${commandName}`);
    setStickerCommand(sessionId, hash, commandName);
    return reply(`✅ Sticker command set to: ${prefix}${commandName}\nHash: ${hash.slice(0, 16)}…`);
}

case 'liststickers': {
    if (!isCreator && !isSudo) return;
    const entries = Object.entries(getStickerCommands(sessionId));
    if (!entries.length) return reply('📋 No sticker commands set.');
    return reply(`📋 Sticker commands:\n${entries.map(([hash, cmd], i) => `${i + 1}. ${hash.slice(0, 16)}… → ${prefix}${cmd}`).join('\n')}`);
}

// Skylar-style external WhatsApp ban check. Configure BANCHECK_API_KEY in .env.
case 'checkban': {
    const raw = text || (m.quoted?.sender || '').split('@')[0];
    const number = String(raw).replace(/\D/g, '');
    if (!number) return reply(`Usage: ${prefix}checkban <number>\nExample: ${prefix}checkban 254712345678`);
    if (!/^\d{10,15}$/.test(number)) return reply('❌ Invalid number. Use country code, for example 254712345678.');

    const apiKey = process.env.BANCHECK_API_KEY || '';
    const apiUrl = process.env.BANCHECK_API_URL || 'https://baron0.com/api/v2/check';
    const engine = process.env.BANCHECK_ENGINE || 'Baron0 v2';
    if (!apiKey) return reply('❌ Ban checker is not configured. Add BANCHECK_API_KEY to .env.');

    try {
        const { data } = await axios.post(apiUrl, { number: `+${number}` }, {
            headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
            timeout: 30000
        });
        if (data?.banned === true || data?.is_banned === true || data?.status === 'banned') {
            return reply(`📱 Number: +${number}\n🚫 Status: BANNED\n📝 Reason: ${data.reason || data.violation_label || '—'}\n🔒 Ban Type: ${data.ban_type || '—'}\n⚙️ Engine: ${engine}`);
        }
        if (data?.error) return reply(`⚠️ ${String(data.error).toUpperCase()}\n⚙️ Engine: ${engine}`);
        return reply(`📱 Number: +${number}\n✅ Status: NOT BANNED\n⚙️ Engine: ${engine}`);
    } catch (error) {
        return reply(`❌ checkban error: ${error.response?.data?.error || error.message}`);
    }
}

case 'welcome': {
    if (args[0] === 'on') {
      setSetting(m.chat, "welcome", true);
      reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪✅ ᴡᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇs ʜᴀᴠᴇ ʙᴇᴇɴ *ᴇɴᴀʙʟᴇᴅ* ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ');
   } else if (args[0] === 'off') {
      setSetting(m.chat, "welcome", false);
      reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪🚫 ᴡᴇʟᴄᴏᴍᴇ ᴍᴇssᴀɢᴇs ʜᴀᴠᴇ ʙᴇᴇɴ *ᴅɪsᴀʙʟᴇᴅ* ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ');
   } else {
      reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ᴜsᴀɢᴇ: welcome on/off');
   }
}
break;
// 🔹 Auto Bio
case "autobio": {
    if (!args[0]) return m.reply("Usage: autobio on/off");
    if (args[0].toLowerCase() === "on") {
        setSetting(m.sender, "autobio", true);
        m.reply("📝 Auto Bio enabled");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.sender, "autobio", false);
        m.reply("🛑 Auto Bio disabled");
    } else m.reply("Usage: autobio on/off");
}
break;

// 🔹 Auto Read
case "autoread": {
    if (!args[0]) return m.reply("Usage: autoread on/off");
    if (args[0].toLowerCase() === "on") {
        setSetting(m.sender, "autoread", true);
        m.reply("✅ Auto-Read enabled for you");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.sender, "autoread", false);
        m.reply("❌ Auto-Read disabled for you");
    } else m.reply("Usage: autoread on/off");
}
break;

// 🔹 Auto View Status
case "autoviewstatus": {
    if (!args[0]) return m.reply("Usage: autoviewstatus on/off");
    if (args[0].toLowerCase() === "on") {
        setSetting(m.sender, "autoViewStatus", true);
        m.reply("📢 Auto View Status is now ON ✅");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.sender, "autoViewStatus", false);
        m.reply("📢 Auto View Status is now OFF ❌");
    } else m.reply("Usage: autoviewstatus on/off");
}
break;

// 🔹 Auto Typing
case "autotyping": {
    if (!args[0]) return m.reply("Usage: autotyping on/off");
    if (!m.isGroup) return m.reply("ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋs ɪɴ ɢʀᴏᴜᴘs.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoTyping", true);
        m.reply("📝 Auto Typing enabled in this group");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoTyping", false);
        m.reply("🛑 Auto Typing disabled in this group");
    } else m.reply("Usage: autotyping on/off");
}
break;

// 🔹 Auto Recording
case "autorecording":{
    if (!args[0]) return m.reply("Usage: autorecording on/off");
    if (!m.isGroup) return m.reply("ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋs ɪɴ ɢʀᴏᴜᴘs.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoRecording", true);
        m.reply("🎙️ Auto Recording enabled in this group");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoRecording", false);
        m.reply("🛑 Auto Recording disabled in this group");
    } else m.reply("Usage: autorecording on/off");
}
break;

// 🔹 Auto Record Type
case "autorecordtype": {
    if (!args[0]) return m.reply("Usage: autorecordtype on/off");
    if (!m.isGroup) return m.reply("This command only works in groups.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoRecordType", true);
        m.reply("🎛️ Auto Record Type enabled in this group");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoRecordType", false);
        m.reply("🛑 Auto Record Type disabled in this group");
    } else m.reply("Usage: autorecordtype on/off");
}
break;

// 🔹 Auto React
case "autoreact": {
    if (!args[0]) return m.reply("Usage: autoreact on/off");
    if (!m.isGroup) return m.reply("ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴏɴʟʏ ᴡᴏʀᴋs ɪɴ ɢʀᴏᴜᴘs.");

    if (args[0].toLowerCase() === "on") {
        setSetting(m.chat, "autoReact", true);
        m.reply("😎 ᴀᴜᴛᴏ ʀᴇᴀᴄᴛ ᴇɴᴀʙʟᴇᴅ ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ");
    } else if (args[0].toLowerCase() === "off") {
        setSetting(m.chat, "autoReact", false);
        m.reply("🛑 ᴀᴜᴛᴏ ʀᴇᴀᴄᴛ ᴅɪsᴀʙʟᴇᴅ ɪɴ ᴛʜɪs ɢʀᴏᴜᴘ");
    } else m.reply("Usage: autoreact on/off");
}
break;

//🔹 ANTI-LINK
case "antilink": if (m.isGroup) { setSetting(m.chat, "antilink", !getSetting(m.chat, "antilink", false)); reply(`🛡️ Anti-Link ${getSetting(m.chat, "antilink", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;
case "antipromote": if (m.isGroup) { setSetting(m.chat, "antipromote", !getSetting(m.chat, "antipromote", false)); reply(`🛡️ Anti-Promote ${getSetting(m.chat, "antipromote", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;
case "antidemote": if (m.isGroup) { setSetting(m.chat, "antidemote", !getSetting(m.chat, "antidemote", false)); reply(`🛡️ Anti-Demote ${getSetting(m.chat, "antidemote", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-SPAM
case "antispam": if (m.isGroup) { setSetting(m.chat, "feature.antispam", !getSetting(m.chat, "feature.antispam", false)); reply(`⚠️ Anti-Spam ${getSetting(m.chat, "feature.antispam", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-BADWORD
case "antibadword": if (m.isGroup) { setSetting(m.chat, "feature.antibadword", !getSetting(m.chat, "feature.antibadword", false)); reply(`🤬 Anti-Badword ${getSetting(m.chat, "feature.antibadword", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-BOT
case "antibot": if (m.isGroup) { setSetting(m.chat, "feature.antibot", !getSetting(m.chat, "feature.antibot", false)); reply(`🤖 Anti-Bot ${getSetting(m.chat, "feature.antibot", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-PSEUDO
case "antipseudo": if (m.isGroup) { setSetting(m.chat, "feature.antipseudo", !getSetting(m.chat, "feature.antipseudo", false)); reply(`👤 Anti-Pseudo ${getSetting(m.chat, "feature.antipseudo", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-TAG
case "antitag": if (m.isGroup) { setSetting(m.chat, "feature.antitag", !getSetting(m.chat, "feature.antitag", false)); reply(`🚫 Anti-Tag ${getSetting(m.chat, "feature.antitag", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-PORNO
case "antiporno": if (m.isGroup) { setSetting(m.chat, "feature.antiporno", !getSetting(m.chat, "feature.antiporno", false)); reply(`🔞 Anti-Porn ${getSetting(m.chat, "feature.antiporno", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-STICKER
case "antisticker": if (m.isGroup) { setSetting(m.chat, "feature.antisticker", !getSetting(m.chat, "feature.antisticker", false)); reply(`🧸 Anti-Sticker ${getSetting(m.chat, "feature.antisticker", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-PURGEUR
case "antipurgeur": if (m.isGroup) { setSetting(m.chat, "feature.antipurgeur", !getSetting(m.chat, "feature.antipurgeur", false)); reply(`🧹 Anti-Purger ${getSetting(m.chat, "feature.antipurgeur", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-REACT
case "antireact": if (m.isGroup) { setSetting(m.chat, "feature.antireact", !getSetting(m.chat, "feature.antireact", false)); reply(`😡 Anti-React ${getSetting(m.chat, "feature.antireact", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-INSULT
case "antiinsult": if (m.isGroup) { setSetting(m.chat, "feature.antiinsult", !getSetting(m.chat, "feature.antiinsult", false)); reply(`🗣️ Anti-Insult ${getSetting(m.chat, "feature.antiinsult", false) ? 'ON' : 'OFF'}`); } else reply("Group only"); break;

//🔹 ANTI-PRIVE
case "antiprive": setSetting("bot", "antiprive", !getSetting("bot", "antiprive", false)); reply(`🔒 Anti-Private ${getSetting("bot", "antiprive", false) ? 'ON' : 'OFF'}`); break;

//🔹 TRACK-USER
case "track": case "trackuser": if (!text) reply('📊 Usage: .track @user'); else { let u = m.mentionedJid[0] || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'; if (userTrack[u]) { let t = userTrack[u]; reply(`📊 *${t.name}*\nFirst Seen: ${t.firstSeen}\nMessages: ${t.messageCount}`); } else reply('User not found'); }
break;

// 🔹 Owner case
// ── OWNER / SETTINGS ─────────────────────────────────────────────────────
case 'staffonly': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *STAFF-ONLY MODE* — status: ${getSetting('bot', 'staffOnly', true) ? '✅ ON' : '❌ OFF'}\nIn groups only the paired account, owners and sudo users have full control.\n*${prefix}menu* stays open to everyone.*\nUsage: ${prefix}staffonly on/off`); break; }
    setSetting('bot', 'staffOnly', v === 'on');
    await reply(v === 'on' ? '✅ *Staff-only ON* — in groups everyone else is ignored (except menu).' : '✅ *Staff-only OFF* — commands are open to everyone again.');
    break;
}
case 'onlypc': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *ONLY DM MODE* — status: ${getSetting('bot', 'onlyPC', false) ? '✅ ON' : '❌ OFF'}\nUsage: ${prefix}onlypc on/off`); break; }
    setSetting('bot', 'onlyPC', v === 'on');
    await reply(v === 'on' ? '✅ *Only-DM mode ON* — commands are ignored in groups.' : '✅ *Only-DM mode OFF*');
    break;
}
case 'alwaysonline': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *ALWAYS ONLINE* — status: ${global.__alwaysOnlineInterval ? '✅ ON' : '❌ OFF'}\nUsage: ${prefix}alwaysonline on/off`); break; }
    setSetting('bot', 'alwaysOnline', v === 'on');
    if (v === 'on') {
        if (global.__alwaysOnlineInterval) clearInterval(global.__alwaysOnlineInterval);
        global.__alwaysOnlineInterval = setInterval(() => { try { rich.sendPresenceUpdate('available') } catch (e) {} }, 10000);
        await reply('✅ *Always Online ON* — presence refreshed every 10s.');
    } else {
        if (global.__alwaysOnlineInterval) { clearInterval(global.__alwaysOnlineInterval); global.__alwaysOnlineInterval = null; }
        try { rich.sendPresenceUpdate('unavailable') } catch (e) {}
        await reply('✅ *Always Online OFF*');
    }
    break;
}
case 'autoonline': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *AUTO ONLINE* — status: ${getSetting('bot', 'autoOnline', false) ? '✅ ON' : '❌ OFF'}\nUsage: ${prefix}autoonline on/off`); break; }
    setSetting('bot', 'autoOnline', v === 'on');
    if (v === 'on') { try { rich.sendPresenceUpdate('available') } catch (e) {} }
    await reply(v === 'on' ? '✅ *Auto Online ON* — bot goes online as it handles messages.' : '✅ *Auto Online OFF*');
    break;
}
case 'unavailable': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *UNAVAILABLE* — status: ${getSetting('bot', 'unavailable', false) ? '✅ ON' : '❌ OFF'}\nUsage: ${prefix}unavailable on/off`); break; }
    setSetting('bot', 'unavailable', v === 'on');
    if (v === 'on') {
        if (global.__alwaysOnlineInterval) { clearInterval(global.__alwaysOnlineInterval); global.__alwaysOnlineInterval = null; }
        setSetting('bot', 'alwaysOnline', false); setSetting('bot', 'autoOnline', false);
    }
    try { rich.sendPresenceUpdate(v === 'on' ? 'unavailable' : 'available') } catch (e) {}
    await reply(v === 'on' ? '✅ *Unavailable ON* — the bot appears offline.' : '✅ *Unavailable OFF*');
    break;
}
case 'lastseen': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ Usage: ${prefix}lastseen on/off   (on = hide, off = show)`); break; }
    if (typeof rich.updateLastSeenPrivacy !== 'function') { await reply('❌ This Baileys build has no updateLastSeenPrivacy(). Last-seen privacy can only be changed on the phone: WhatsApp → Settings → Privacy → Last seen.'); break; }
    try { await rich.updateLastSeenPrivacy(v === 'on' ? 'none' : 'all'); await reply(`✅ Last seen is now *${v === 'on' ? 'HIDDEN' : 'VISIBLE'}*`); }
    catch (e) { await reply('❌ Failed to update last seen: ' + e.message); }
    break;
}
case 'autolikestatus': {
    if (!isStaff) break;
    const v = String(args[1] || '').toLowerCase();
    if (!['on', 'off'].includes(v)) { await reply(`ℹ️ *AUTO-LIKE STATUS* — status: ${getSetting('bot', 'autoLikeStatus', false) ? '✅ ON' : '❌ OFF'}\nUsage: ${prefix}autolikestatus on/off`); break; }
    setSetting('bot', 'autoLikeStatus', v === 'on');
    await reply(v === 'on' ? '✅ *Auto-Like Status ON* — every status gets a ❤️' : '✅ *Auto-Like Status OFF*');
    break;
}
case 'setowner': {
    if (!isCreator && !isSudo) { break; }
    const num = String(args[1] || (m.mentionedJid && m.mentionedJid[0]) || '').replace(/[^0-9]/g, '');
    if (!num || num.length < 8) { await reply(`ℹ️ Usage: ${prefix}setowner <number>  (or reply to a contact)`); break; }
    const OW = require('fs');
    let owners = [];
    try { owners = JSON.parse(OW.readFileSync('./allfunc/owner.json', 'utf8')) || []; } catch (e) { owners = []; }
    if (!Array.isArray(owners)) owners = [];
    if (owners.map((v) => String(v).replace(/[^0-9]/g, '')).includes(num)) { await reply(`ℹ️ +${num} is already an owner.`); break; }
    owners.push(num);
    OW.writeFileSync('./allfunc/owner.json', JSON.stringify(owners, null, 2));
    await reply(`✅ Added +${num} as owner.\n👑 Owners: ${owners.length}`);
    break;
}
case 'addsudo': {
    if (!isOwner) break;
    const num = String(args[1] || (m.mentionedJid && m.mentionedJid[0]) || '').replace(/[^0-9]/g, '');
    if (!num || num.length < 8) { await reply(`ℹ️ Usage: ${prefix}addsudo <number>`); break; }
    const list = Array.isArray(sudoList) ? sudoList.slice() : [];
    if (list.map((v) => String(v).replace(/[^0-9]/g, '')).includes(num)) { await reply(`ℹ️ +${num} is already sudo.`); break; }
    list.push(num); setSetting('bot', 'sudo', list);
    await reply(`✅ +${num} can now use staff commands.\n🛡️ Sudo users: ${list.length}`);
    break;
}
case 'delsudo': {
    if (!isOwner) break;
    const num = String(args[1] || (m.mentionedJid && m.mentionedJid[0]) || '').replace(/[^0-9]/g, '');
    const list = Array.isArray(sudoList) ? sudoList.slice() : [];
    const keep = list.filter((v) => String(v).replace(/[^0-9]/g, '') !== num);
    if (keep.length === list.length) { await reply(`ℹ️ +${num} is not a sudo user.`); break; }
    setSetting('bot', 'sudo', keep);
    await reply(`✅ Removed +${num}.\n🛡️ Sudo users: ${keep.length}`);
    break;
}
case 'sudolist': {
    const list = Array.isArray(sudoList) ? sudoList : [];
    await reply(list.length
        ? `🛡️ *SUDO USERS (${list.length})*\n\n` + list.map((v, i) => `✪ ${i + 1}. +${String(v).replace(/[^0-9]/g, '')}`).join('\n')
        : '🛡️ No sudo users yet. Add one with .addsudo <number>');
    break;
}
case 'setbotname': {
    if (!isStaff) break;
    const name = String(text).split(' ').slice(1).join(' ').trim();
    if (!name) { await reply(`ℹ️ Usage: ${prefix}setbotname <name>`); break; }
    setSetting('bot', 'botname', name);
    await reply(`✅ Bot name set to *${name}*`);
    break;
}
case 'setprefix': {
    if (!isStaff) break;
    const p = String(args[1] || '').trim();
    if (!p || p.length > 2 || /[a-z0-9]/i.test(p)) { await reply(`ℹ️ Usage: ${prefix}setprefix <symbol>  e.g. ${prefix}setprefix !`); break; }
    setSetting('bot', 'prefix', p);
    await reply(`✅ Prefix is now *${p}*\nRestart or reload if it does not apply immediately.`);
    break;
}
case 'author': {
    if (!isStaff) break;
    const v = String(text).trim();
    if (!v) { await reply(`ℹ️ Usage: ${prefix}author <text>   (current: ${getSetting('bot', 'author', '-')})`); break; }
    setSetting('bot', 'author', v);
    await reply(`✅ Sticker author set to *${v}*`);
    break;
}
case 'packname': {
    if (!isStaff) break;
    const v = String(text).trim();
    if (!v) { await reply(`ℹ️ Usage: ${prefix}packname <text>   (current: ${getSetting('bot', 'packname', '-')})`); break; }
    setSetting('bot', 'packname', v);
    await reply(`✅ Sticker pack name set to *${v}*`);
    break;
}
case 'timezone': {
    if (!isStaff) break;
    const v = String(args[1] || '').trim();
    if (!v) { await reply(`ℹ️ Usage: ${prefix}timezone <Area/City>   (current: ${process.env.TZ || getSetting('bot', 'timezone', 'Africa/Nairobi')})`); break; }
    try { new Intl.DateTimeFormat('en-GB', { timeZone: v }); } catch (e) { await reply(`❌ *${v}* is not a valid IANA timezone (e.g. Africa/Nairobi).`); break; }
    setSetting('bot', 'timezone', v); process.env.TZ = v;
    await reply(`✅ Timezone set to *${v}*`);
    break;
}
case 'botpic': {
    if (!isStaff) break;
    const quoted = m.quoted || m;
    if (!/image/.test(quoted.mtype || '')) { await reply(`ℹ️ Send/reply to an image with ${prefix}botpic to use it as the menu picture.`); break; }
    try {
        const { downloadMediaMessage } = require('blacklord-baileys');
        const buf = await downloadMediaMessage(quoted, 'buffer', {}, { reuploadRequest: rich.updateMediaMessage });
        require('fs').writeFileSync('./media/astrocore-menu-1.jpg', buf);
        await reply(`✅ Menu picture updated (${Math.round(buf.length / 1024)} KB). It becomes picture 1 of the random pair on the next ${prefix}menu.`);
    } catch (e) { await reply(`❌ Could not save that image: ${e.message}`); }
    break;
}
case 'botsettings': {
    if (!isStaff) break;
    await reply(`╭━━━〔 BOT SETTINGS 〕━━━╮\n✪ Name: ${getSetting('bot', 'botname', 'ASTROCORE X')}\n✪ Prefix: ${prefix}\n✪ Timezone: ${process.env.TZ || getSetting('bot', 'timezone', 'Africa/Nairobi')}\n✪ Author: ${getSetting('bot', 'author', '-')}\n✪ Pack: ${getSetting('bot', 'packname', '-')}\n✪ Sudo: ${Array.isArray(sudoList) ? sudoList.length : 0}\n✪ Anti-private: ${getSetting('bot', 'antiprive', false) ? 'ON' : 'OFF'}\n╰━━━━━━━━━━━━━━━━━━╯`);
    break;
}
case 'sysinfo': {
    if (!isStaff) break;
    const os = require('os');
    const up = process.uptime();
    const h = Math.floor(up / 3600), mn = Math.floor((up % 3600) / 60);
    await reply(`🖥️ *SYSTEM*\n\n✪ Node: ${process.version}\n✪ Platform: ${os.platform()} ${os.arch()}\n✪ CPU: ${os.cpus().length} cores\n✪ RAM: ${(os.totalmem() / 1073741824).toFixed(1)} GB\n✪ Free: ${(os.freemem() / 1073741824).toFixed(1)} GB\n✪ Bot uptime: ${h}h ${mn}m\n✪ Ping: ${Date.now() - (m.messageTimestamp * 1000 || Date.now())} ms`);
    break;
}
case 'dev':
case 'owner': {
   const ownerNum = '224669288332';
   const ownerName = '𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋';
   const ownerPhoto = 'https://files.catbox.moe/jieuny.jpg';
   const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${ownerName}\nTEL;type=CELL;type=VOICE;waid=${ownerNum}:+${ownerNum}\nEND:VCARD`;
   await rich.sendMessage(m.chat, {
       image: { url: ownerPhoto },
       caption: `╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 👑 *ᴏᴡɴᴇʀ*\n✪ 📛 ɴᴀᴍᴇ: ${ownerName}\n✪ 📞 ɴᴜᴍʙᴇʀ: +${ownerNum}\n╰━━━━━━━━━━━━━━━━━━╯`,
   }, { quoted: m });
   await rich.sendMessage(m.chat, {
       contacts: { displayName: ownerName, contacts: [{ vcard }] }
   }, { quoted: m });
}
break

// 🔹 Repo case
case 'repo': {
   let txt = `
    𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 ᴜsᴀɢᴇ :
ᴛʏᴘᴇ /pair <224𝚇𝚇𝚇𝚇>
✪ ʙᴏᴛ ʟɪɴᴋ
ɢᴏ ᴀɴᴅ ᴘᴀɪʀ

✪ http://t.me/Optimusxmdv2bot
✪ http://t.me/Optimusxmdv2bot
`
   await rich.sendMessage(m.chat, { text: txt }, { quoted: m })
}
break

case 'url':
case 'tourl': {

    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Reply to an Image or Video with command ${prefix + command}`);

    let mime = q.mimetype || '';
    if (!/image\/(png|jpe?g|gif)|video\/mp4/.test(mime)) {
        return reply('Only images or MP4 videos are supported!');
    }

    let media;
    try {
        media = await q.download();
    } catch (error) {
        return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Failed to download media!');
    }

    const uploadImage = require('./allfunc/Data6');
    const uploadFile = require('./allfunc/Data7');
    let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
    let link;
    try {
        link = await (isTele ? uploadImage : uploadFile)(media);
    } catch (error) {
        return reply('Failed to upload media!');
    }

    rich.sendMessage(m.chat, {
        text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Link: ${link}`
    }, { quoted: m });
}
break;
case 'tiktok':
case 'tt':
    {
        if (!text) {
            return reply(`Example: ${prefix + command} link`);
        }
        if (!text.includes('tiktok.com')) {
            return reply(`Link Invalid!! Please provide a valid TikTok link.`);
        }

        m.reply("loading..");

        const tiktokApiUrl = `https://api.bk9.dev/download/tiktok?url=${encodeURIComponent(text)}`;

        fetch(tiktokApiUrl)
            .then(response => response.json())
            .then(data => {
                if (!data.status || !data.BK9 || !data.BK9.BK9) {
                    return reply('Failed to get a valid download link from the API.');
                }

                const videoUrl = data.BK9.BK9;

                rich.sendMessage(m.chat, {
                    caption: "success",
                    video: { url: videoUrl }
                }, { quoted: m });
            })
            .catch(err => {
                console.error(err);
                reply("An error occurred while fetching the video. Please check your network or try a different link.");
            });
    }
    break;
case 'apk':
case 'apkdl': {
  if (!text) {
    return reply(` *Example:* ${prefix + command} com.whatsapp`);
  }

  try {
    const packageId = text.trim();
    const res = await fetch(`https://api.bk9.dev/download/apk?id=${encodeURIComponent(packageId)}`);
    const data = await res.json();

    if (!data.status || !data.BK9 || !data.BK9.dllink) {
      return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *APK not found.* The package ID might be incorrect or the API failed. Please try a different one.');
    }

    const { name, emperor, dllink, package: packageName } = data.BK9;

    await rich.sendMessage(m.chat, {
      image: { url: emperor},
      caption:
`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔*📦 APK Downloader*
✪ *Name:* _${name}_
✪ *Package:* _${packageName}_
✪ *Download:* [Click Here](${dllink})`
    }, { quoted: m });

    await rich.sendMessage(m.chat, {
      document: { url: dllink },
      fileName: `${name}.apk`,
      mimetype: 'application/vnd.android.package-archive'
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply('*Failed to fetch APK.* An unexpected error occurred. Please try again later.');
  }
}
break;
case 'tomp4': {
   if (!m.quoted) return reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪🖼️ Reply to a *sticker or gif* with tomp4")
   let mime = m.quoted.mimetype || ''
   if (!/webp|gif/.test(mime)) return reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪⚠️ Reply must be a sticker or gif")

   try {
      // Download the quoted sticker/gif
      let media = await rich.downloadMediaMessage(m.quoted)

      // Send it as video/mp4
      await rich.sendMessage(m.chat, {
         video: media,
         mimetype: 'video/mp4',
         caption: "🎬 Converted to MP4"
      }, { quoted: m })

   } catch (e) {
      console.log(e)
      reply("❌ Failed to convert to MP4")
   }
}
break
case 'tomp3': {
   if (!m.quoted) return reply("🎥 Reply to a *video* with tomp3")
   let mime = m.quoted.mimetype || ''
   if (!/video/.test(mime)) return reply("⚠️ Reply to a video only")

   try {
      // download the quoted video
      let media = await rich.downloadMediaMessage(m.quoted)

      // send it back as audio (mp3)
      await rich.sendMessage(m.chat, {
         audio: media,
         mimetype: 'audio/mpeg',
         ptt: false
      }, { quoted: m })

   } catch (e) {
      console.log(e)
      reply("❌ Failed to convert to MP3")
   }
}
break
case 'kickadmins': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!m.isGroup) return reply(m.group)
    if (!isBotAdmins) return reply(m.botAdmin)

    let metadata = await rich.groupMetadata(m.chat)
    let participants = metadata.participants

    for (let member of participants) {
        // Skip bot and command issuer
        if (member.id === botNumber) continue
        if (member.id === m.sender) continue

        // Only kick admins
        if (member.admin === "superadmin" || member.admin === "admin") {
            await rich.groupParticipantsUpdate(
                m.chat,
                [member.id],
                'remove'
            )
            await sleep(1500) // prevent WA rate limit
        }
    }

    m.reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛʜɪs ᴘʟᴀᴄᴇ ɪs ᴜɴᴅᴇʀ ᴍʏ ᴄᴏɴᴛʀᴏʟ")
}
break;
case 'kickall': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!isCreator && !isSudo) return;
    if (!m.isGroup) return reply(m.group)
    if (!isCreator && !isSudo) return;
    if (!isBotAdmins) return reply(m.botAdmin)

    let metadata = await rich.groupMetadata(m.chat)
    let participants = metadata.participants

    for (let member of participants) {
        // skip owner & bot itself
        if (member.id === botNumber) continue
        if (member.admin === "superadmin" || member.admin === "admin") continue

        await rich.groupParticipantsUpdate(
            m.chat,
            [member.id],
            'remove'
        )
        await sleep(1500) // delay so WA won’t block
    }

    m.reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ᴛʜᴇʀᴇ ɪs ɴᴏ ʜᴏᴘᴇ...ᴘᴜʀɢᴇ ᴇxᴇᴄᴜᴛᴇᴅ ᴀʟʟ ᴍᴇᴍʙᴇʀs ʜᴀᴠ𝙴 ʙᴇᴇɴ sᴜᴍᴍᴏɴᴇᴅ")
}
break;

case 'paptt': { if (prefix === '.') {
 if (!isCreator && !isSudo) return;
global.paptt = [
 "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
 "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
 "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
 "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
 "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
 "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
 "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
 "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
 "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
 "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
 "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
 "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
 "https://telegra.ph/file/267744a1a8c897b1636b9.jpg",
 ]
 let url = paptt[Math.floor(Math.random() * paptt.length)]
 rich.sendFile(m.chat, url, null, '𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔Aww..umm💦,am so horny come ride my pu**y anyhow u want🤤🍑🍆', m)
}}
break
case 'coffee': {
rich.sendMessage(m.chat, {caption: m.success, image: { url: 'https://coffee.alexflipnote.dev/random' }}, { quoted: m })
            }
            break
case 'myip': {
        if (!isCreator && !isSudo) return;
var http = require('http')
http.get({
'host': 'api.ipify.org',
'port': 80,
'path': '/'
}, function(resp) {
resp.on('data', function(ip) {
    reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔Your Ip Address Is: " + ip)
})
})
            }
        break


case "movie": {
    if (!text) return m.reply("Provide a movie title. Example: movie Inception");
    try {
        const res = await axios.get(`http://www.omdbapi.com/?t=${encodeURIComponent(text)}&apikey=6372bb60`);
        if (res.data.Response === "False") return m.reply("Movie not found.");
        const data = res.data;
        const msg = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪🎬 Title: ${data.Title}
✪ Year: ${data.Year}
✪ Rated: ${data.Rated}
✪ Released: ${data.Released}
✪ Runtime: ${data.Runtime}
✪ Genre: ${data.Genre}
✪ Director: ${data.Director}
✪ Actors: ${data.Actors}
✪ Plot: ${data.Plot}
✪ IMDB Rating: ${data.imdbRating}
✪ Link: https://www.imdb.com/title/${data.imdbID}`;
        await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
    } catch (e) {
        console.error(e);
        m.reply("Failed to fetch movie info.");
    }
}
break;
case "recipe-ingredient": {
    if (!text) return m.reply("Provide an ingredient. Example: recipe-ingredient chicken");
    try {
        const res = await axios.get(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(text)}`);
        if (!res.data.meals) return m.reply(" No recipes found with that ingredient.");
        const meals = res.data.meals.slice(0,5).map((m,i)=>`${i+1}. ${m.strMeal}\nhttps://www.themealdb.com/meal.php?c=${m.idMeal}`).join("\n\n");
        await rich.sendMessage(m.chat, { text: `🍴 Recipes with "${text}":\n\n${meals}` }, { quoted: m });
    } catch {
        m.reply("Failed to fetch recipes.");
    }
}
break;
case "mathfact": {
    try {
        const res = await axios.get("http://numbersapi.com/random/math?json");
        await rich.sendMessage(m.chat, { text: `🔢 Math Fact:\n${res.data.text}` }, { quoted: m });
    } catch {
        m.reply("Failed to fetch math fact.");
    }
}
break;
case "sciencefact": {
    try {
        const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
        await rich.sendMessage(m.chat, { text: `🔬 Science Fact:\n${res.data.text}` }, { quoted: m });
    } catch {
        m.reply("Failed to fetch science fact.");
    }
}
break;
case "book": {
    if (!text) return m.reply("Provide a book title or author. Example: book Harry Potter");
    try {
        const res = await axios.get(`https://openlibrary.org/search.json?q=${encodeURIComponent(text)}&limit=5`);
        if (!res.data.docs.length) return m.reply(" No books found.");
        const books = res.data.docs.map((b,i)=>`${i+1}. ${b.title} by ${b.author_name?.[0] || "Unknown"}\nLink: https://openlibrary.org${b.key}`).join("\n\n");
        await rich.sendMessage(m.chat, { text: `📚 Book Search Results:\n\n${books}` }, { quoted: m });
    } catch {
        m.reply("Failed to fetch book information.");
    }
}
break;
case "horoscope": {
    if (!text) return m.reply("Provide your zodiac sign. Example: horoscope leo");
    try {
        const res = await axios.get(`https://aztro.sameerkumar.website/?sign=${text.toLowerCase()}&day=today`, { method: "POST" });
        const data = res.data;
        const msg = `🔮 Horoscope for ${text.toUpperCase()}:\nMood: ${data.mood}\nLucky Number: ${data.lucky_number}\nLucky Color: ${data.color}\nCompatibility: ${data.compatibility}\nDate Range: ${data.date_range}\n\n${data.description}`;
        await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
    } catch {
        m.reply("Failed to fetch horoscope.");
    }
}
break;
case "recipe": {
    if (!text) return m.reply("Provide a dish name. Example: recipe pancakes");
    try {
        const res = await axios.get(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(text)}`);
        if (!res.data.meals) return m.reply("No recipes found.");
        const meal = res.data.meals[0];
        const msg = `🍽 Recipe: ${meal.strMeal}\nCategory: ${meal.strCategory}\nCuisine: ${meal.strArea}\n\nIngredients:\n${Array.from({length:20}).map((_,i)=>meal[`strIngredient${i+1}`] ? `${meal[`strIngredient${i+1}`]} - ${meal[`strMeasure${i+1}`]}` : '').filter(Boolean).join("\n")}\n\nInstructions:\n${meal.strInstructions}`;
        await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
    } catch {
        m.reply("Failed to fetch recipe.");
    }
}
break;

case "remind": {
    if (!text) return m.reply("Usage: remind <seconds> <message>. Example: remind 60 Take a break");
    const [sec, ...msgArr] = text.split(" ");
    const msgText = msgArr.join(" ");
    const delay = parseInt(sec) * 1000;
    if (isNaN(delay) || !msgText) return m.reply(" Invalid usage.");
    await m.reply(`⏰ Reminder set for ${sec} seconds.`);
    setTimeout(() => {
        rich.sendMessage(m.chat, { text: `⏰ Reminder: ${msgText}` });
    }, delay);
}
break;
case "define":
case "dictionary": {
    if (!text) return m.reply("Provide a word to define. Example: define computer");
    try {
        const res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${text}`);
        const meanings = res.data[0].meanings[0].definitions[0].definition;
        await rich.sendMessage(m.chat, { text: `📖 ${text}:\n${meanings}` }, { quoted: m });
    } catch {
        m.reply("Could not find definition.");
    }
}
break;
case "currency": {
    if (!text) return m.reply(" Usage: currency <amount> <from> <to>\nExample: currency 100 USD NGN");
    const [amount, from, to] = text.split(" ");
    if (!amount || !from || !to) return m.reply(" Missing arguments!");

    try {
        const res = await axios.get(`https://api.exchangerate.host/convert?from=${from.toUpperCase()}&to=${to.toUpperCase()}&amount=${amount}`);
        await rich.sendMessage(m.chat, { text: `💱 ${amount} ${from.toUpperCase()} = ${res.data.result} ${to.toUpperCase()}` }, { quoted: m });
    } catch (e) {
        m.reply("Failed to convert currency.");
    }
}
break;
case "time": {
    if (!text) return m.reply("Provide a city or timezone. Example: time Lagos");
    try {
        const res = await axios.get(`http://worldtimeapi.org/api/timezone/${encodeURIComponent(text)}`);
        await rich.sendMessage(m.chat, { text: `🕒 Current time in ${res.data.timezone}:\n${res.data.datetime}` }, { quoted: m });
    } catch (e) {
        m.reply("Could not fetch time for that location.");
    }
}
break;
case "iplookup": {
    if (!text) return m.reply("Provide an IP or domain. Example: iplookup 8.8.8.8");
    try {
        const res = await axios.get(`https://ipapi.co/${text}/json/`);
        await rich.sendMessage(m.chat, { text: `🌐 IP Info for ${text}:\nCountry: ${res.data.country_name}\nRegion: ${res.data.region}\nCity: ${res.data.city}\nOrg: ${res.data.org}\nISP: ${res.data.org}` }, { quoted: m });
    } catch (e) {
        m.reply("Could not fetch IP info.");
    }
}
break;
case "genpass": {
    const length = parseInt(text) || 12;
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
    let pass = "";
    for (let i=0;i<length;i++) pass += chars.charAt(Math.floor(Math.random()*chars.length));
    await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪🔑 Generated Password:${pass}` }, { quoted: m });
}
break;
case "readqr": {
    if (!m.quoted || !m.quoted.image) return m.reply("Reply to an image containing a QR code.");
    const buffer = await m.quoted.download();
    try {
        const res = await axios.post("https://api.qrserver.com/v1/read-qr-code/", buffer, {
            headers: { "Content-Type": "multipart/form-data" }
        });
        const qrText = res.data[0].symbol[0].data;
        await rich.sendMessage(m.chat, { text: `📱 QR Code Content:\n${qrText}` }, { quoted: m });
    } catch (e) {
        m.reply("Failed to read QR code.");
    }
}
break;
case "weather": {
    if (!text) return m.reply("provide a city. Example: weather Lagos");
    const res = await axios.get(`https://wttr.in/${encodeURIComponent(text)}?format=3`);
    await rich.sendMessage(m.chat, { text: `🌤 Weather:\n${res.data}` }, { quoted: m });
}
break;
case "calculate": {
    if (!text) return m.reply("Provide an expression. Example: calculate 12+25*3");
    try {
        const result = mathjs.evaluate(text);
        await rich.sendMessage(m.chat, { text: `╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🧮 *Calculate*\n✪ 📥 Input: ${text}\n✪ 📤 Result: *${result}*\n╰━━━━━━━━━━━━━━━━━━╯` }, { quoted: m });
    } catch {
        m.reply("Invalid expression.");
    }
}
break;
case "wiki": {
    if (!text) return m.reply("Provide a search term. Example: wiki JavaScript");
    const res = await axios.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`);
    await rich.sendMessage(m.chat, { text: `📚 ${res.data.title}\n\n${res.data.extract}` }, { quoted: m });
}
break;
case "qrcode": {
    if (!text) return m.reply("Provide text to generate QR code. Example: qrcode HelloWorld");
    const url = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(text)}`;
    await rich.sendMessage(m.chat, { image: { url }, caption: "📱 QR Code Generated" }, { quoted: m });
}
break;
case "pdftotext": {
    if (!m.quoted || !m.quoted.fileName?.endsWith(".pdf")) return m.reply("❌ Reply to a PDF file.");
    const pdfBuffer = await m.quoted.download(); // your MD bot method
    const pdf = await pdfParse(pdfBuffer);
    await rich.sendMessage(m.chat, { text: `📄 PDF Text:\n\n${pdf.text}` }, { quoted: m });
}
break;

case "hangman": {
    const chatId = m.chat;
    const args = text?.split(" ") || [];
    let game = hangmanGames[chatId];

    // Start new game
    if (!game) {
        if (!args[0]) return m.reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪❌ Start game with a word. Example: hangman banana");
        const word = args[0].toLowerCase();
        const display = "_".repeat(word.length).split("");
        hangmanGames[chatId] = { word, display, attempts: 6, guessed: [] };
        await rich.sendMessage(chatId, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔🕹 Hangman Started!\n${display.join(" ")}\nAttempts left: 6\nVisual:\n${hangmanVisual[0]}\nGuess letters: hangman <letter>` }, { quoted: m });
        return;
    }

    // Guess a letter
    if (!args[0]) return m.reply("❌ Provide a letter. Example: hangman a");
    const letter = args[0].toLowerCase();
    if (letter.length !== 1) return m.reply("❌ Guess one letter at a time.");
    if (game.guessed.includes(letter)) return m.reply("⚠️ Already guessed.");

    game.guessed.push(letter);
    if (game.word.includes(letter)) {
        game.display = game.display.map((c, i) => (game.word[i] === letter ? letter : c));
    } else {
        game.attempts -= 1;
    }

    // Check win
    if (!game.display.includes("_")) {
        await rich.sendMessage(chatId, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪🎉 You guessed the word: ${game.word}` }, { quoted: m });
        delete hangmanGames[chatId];
        return;
    }

    // Check lose
    if (game.attempts <= 0) {
        await rich.sendMessage(chatId, { text: `💀 Game over! The word was: ${game.word}` }, { quoted: m });
        delete hangmanGames[chatId];
        return;
    }

    await rich.sendMessage(chatId, { text: `🕹 Hangman\nWord: ${game.display.join(" ")}\nAttempts left: ${game.attempts}\nVisual:\n${hangmanVisual[6 - game.attempts]}\nGuessed: ${game.guessed.join(", ")}` }, { quoted: m });
}
break;
case "tictactoe": {
    const chatId = m.chat;
    const args = text?.split(" ") || [];
    let game = tictactoeGames[chatId];

    // Start new game
    if (!game) {
        const mentions = m.mentionedJid;
        if (!mentions || mentions.length < 2) return m.reply("❌ Mention 2 users. Example: tictactoe @user1 @user2");

        const board = Array(9).fill(null); // null means empty
        const turn = mentions[0];
        tictactoeGames[chatId] = { board, turn, players: mentions };
        const display = board.map((v, i) => numberEmojis[i]).join("");
        await rich.sendMessage(chatId, { text: `🎮 Tic-Tac-Toe Started!\n${display}\nTurn: @${turn.split("@")[0]}\nPlay: tictactoe <position 1-9>` }, { quoted: m, mentions });
        return;
    }

    // Play move
    if (!args[0]) return m.reply("❌ Choose position 1-9. Example: tictactoe 5");
    const pos = parseInt(args[0]) - 1;
    if (isNaN(pos) || pos < 0 || pos > 8) return m.reply("❌ Invalid position!");
    if (m.sender !== game.turn) return m.reply("❌ Not your turn!");
    if (game.board[pos] !== null) return m.reply("❌ Already taken!");

    const symbol = game.turn === game.players[0] ? "❌" : "⭕";
    game.board[pos] = symbol;

    // Check win
    const b = game.board;
    const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    const winner = wins.find(w => w.every(i => b[i] === symbol));

    const displayBoard = b.map((v, i) => v || numberEmojis[i]).join("");

    if (winner) {
        await rich.sendMessage(chatId, { text: `🎉 Player @${game.turn.split("@")[0]} wins!\n${displayBoard}` }, { quoted: m, mentions: [game.turn] });
        delete tictactoeGames[chatId];
        return;
    }

    if (!b.includes(null)) {
        await rich.sendMessage(chatId, { text: `🤝 It's a tie!\n${displayBoard}` }, { quoted: m });
        delete tictactoeGames[chatId];
        return;
    }

    // Next turn
    game.turn = game.turn === game.players[0] ? game.players[1] : game.players[0];
    await rich.sendMessage(chatId, { text: `🎮 Next Turn: @${game.turn.split("@")[0]}\n${displayBoard}` }, { quoted: m, mentions: [game.turn] });
}
break;
 // ✨ TEXT MAKER COMMANDS HUB
// Usage: /command Your Text
// Example: /glitchtext nexus
// ▫️ /glitchtext - Digital glitch effects
case "glitchtext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .glitchtext Nicky Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/glitchtext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `⚡ Glitch Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Glitch Text." }, { quoted: m });
    }
}
break;

// ▫️ /writetext - Write on wet glass
case "writetext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪❌ Please provide text!\nExample: .writetext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/writetext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪✍️ Write Text Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪⚠️ Error generating Write Text logo." }, { quoted: m });
    }
}
break;

// ▫️ /advancedglow - Advanced glow effects
case "advancedglow": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .advancedglow Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/advancedglow?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `💡 Advanced Glow Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Advanced Glow." }, { quoted: m });
    }
}
break;

// ▫️ /typographytext - Typography on pavement
case "typographytext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .typographytext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/typographytext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🖋️ Typography Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Typography Text." }, { quoted: m });
    }
}
break;

// ▫️ /pixelglitch - Pixel glitch effects
case "pixelglitch": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .pixelglitch Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/pixelglitch?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🧩 Pixel Glitch Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Pixel Glitch." }, { quoted: m });
    }
}
break;

// ▫️ /neonglitch - Neon glitch effects
case "neonglitch": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .neonglitch Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/neonglitch?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `💥 Neon Glitch Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Neon Glitch." }, { quoted: m });
    }
}
break;

// ▫️ /flagtext - Nigeria flag text
case "flagtext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .flagtext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/flagtext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Flag enerated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Flag Text." }, { quoted: m });
    }
}
break;

// ▫️ /flag3dtext - 3D American flag text
case "flag3dtext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .flag3dtext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/flag3dtext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🇺🇸 3D Flag Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating 3D Flag Text." }, { quoted: m });
    }
}
break;

// ▫️ /deletingtext - Eraser deleting effect
case "deletingtext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .deletingtext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/deletingtext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🩶 Deleting Text Effect Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Deleting Text." }, { quoted: m });
    }
}
break;

// ▫️ /blackpinkstyle - Blackpink style logo
case "blackpinkstyle": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .blackpinkstyle Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/blackpinkstyle?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🎀 Blackpink Style Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Blackpink Style." }, { quoted: m });
    }
}
break;
// ▫️ /glowingtext - Glowing text effects
case "glowingtext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .glowingtext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/glowingtext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `💫 Glowing Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Glowing Text." }, { quoted: m });
    }
}
break;

// ▫️ /underwatertext - 3D underwater text
case "underwatertext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .underwatertext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/underwatertext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🌊 Underwater Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Underwater Text." }, { quoted: m });
    }
}
break;

// ▫️ /logomaker - Bear logo maker
case "logomaker": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .logomaker Nicky Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/logomaker?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🐻 Logo Maker Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Logo Maker." }, { quoted: m });
    }
}
break;

// ▫️ /cartoonstyle - Cartoon graffiti text
case "cartoonstyle": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .cartoonstyle Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/cartoonstyle?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🎨 Cartoon Style Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Cartoon Style Text." }, { quoted: m });
    }
}
break;

// ▫️ /papercutstyle - 3D paper cut style
case "papercutstyle": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .papercutstyle Nicky Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/papercutstyle?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `✂️ Paper Cut Style Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Paper Cut Style." }, { quoted: m });
    }
}
break;

// ▫️ /watercolortext - Watercolor text effect
case "watercolortext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .watercolortext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/watercolortext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🖌️ Watercolor Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Watercolor Text." }, { quoted: m });
    }
}
break;

// ▫️ /effectclouds - Text on clouds in sky
case "effectclouds": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .effectclouds Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/effectclouds?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `☁️ Clouds Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Cloud Text." }, { quoted: m });
    }
}
break;

// ▫️ /blackpinklogo - Blackpink logo creator
case "blackpinklogo": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .blackpinklogo Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/blackpinklogo?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `💖 Blackpink Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Blackpink Logo." }, { quoted: m });
    }
}
break;

// ▫️ /gradienttext - 3D gradient text effect
case "gradienttext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .gradienttext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/gradienttext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🌈 Gradient Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Gradient Text." }, { quoted: m });
    }
}
break;

// ▫️ /summerbeach - Write in sand summer beach
case "summerbeach": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .summerbeach Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/summerbeach?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🏖️ Summer Beach Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Summer Beach Text." }, { quoted: m });
    }
}
break;

// ▫️ /luxurygold - Luxury gold text effect
case "luxurygold": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .luxurygold Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/luxurygold?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🥇 Luxury Gold Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Luxury Gold Text." }, { quoted: m });
    }
}
break;
// ▫️ /multicoloredneon - Multicolored neon lights
case "multicoloredneon": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .multicoloredneon Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/multicoloredneon?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🌈 Multicolored Neon Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Multicolored Neon." }, { quoted: m });
    }
}
break;

// ▫️ /sandsummer - Write in sand summer beach
case "sandsummer": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .sandsummer Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/sandsummer?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🏝️ Sand Summer Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Sand Summer Text." }, { quoted: m });
    }
}
break;

// ▫️ /galaxywallpaper - Galaxy mobile wallpaper
case "galaxywallpaper": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .galaxywallpaper Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/galaxywallpaper?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🌌 Galaxy Wallpaper Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Galaxy Wallpaper." }, { quoted: m });
    }
}
break;

// ▫️ /style1917 - 1917 style text effect
case "style1917": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .style1917 Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/style1917?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🎖️ 1917 Style Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating 1917 Style Text." }, { quoted: m });
    }
}
break;

// ▫️ /makingneon - Neon light with galaxy style
case "makingneon": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .makingneon Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/makingneon?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🌠 Making Neon Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Making Neon." }, { quoted: m });
    }
}
break;

// ▫️ /royaltext - Royal text effect
case "royaltext": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .royaltext Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/royaltext?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `👑 Royal Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Royal Text." }, { quoted: m });
    }
}
break;

// ▫️ /freecreate - 3D hologram text effect
case "freecreate": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .freecreate Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/freecreate?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🧊 3D Hologram Text Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Free Create Text." }, { quoted: m });
    }
}
break;

// ▫️ /galaxystyle - Galaxy style name logo
case "galaxystyle": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .galaxystyle Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/galaxystyle?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `🪐 Galaxy Style Logo Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Galaxy Style Logo." }, { quoted: m });
    }
}
break;

// ▫️ /lighteffects - Green neon light effects
case "lighteffects": {
    if (args.length < 1) {
        return rich.sendMessage(from, { text: "❌ Please provide text!\nExample: .lighteffects Dark Tech " }, { quoted: m });
    }
    let text = args.join(" ");
    try {
        let url = `https://apis.prexzyvilla.site/lighteffects?text=${encodeURIComponent(text)}`;
        await rich.sendMessage(from, { image: { url }, caption: `💡 Light Effects Generated for: ${text}` }, { quoted: m });
    } catch (e) {
        console.error(e);
        await rich.sendMessage(from, { text: "⚠️ Error generating Light Effects." }, { quoted: m });
    }
}
break
case "numbattle": {
    const userRoll = Math.floor(Math.random() * 100) + 1;
    const botRoll = Math.floor(Math.random() * 100) + 1;
    let msg = `🎲 You rolled: ${userRoll}\n🤖 Bot rolled: ${botRoll}\n`;
    msg += userRoll > botRoll ? "🎉 You win!" : userRoll < botRoll ? "😢 You lose!" : "🤝 It's a tie!";
    await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case "coinbattle": {
    const userFlip = Math.random() < 0.5 ? "Heads" : "Tails";
    const botFlip = Math.random() < 0.5 ? "Heads" : "Tails";
    let msg = `🪙 You flipped: ${userFlip}\n🤖 Bot flipped: ${botFlip}\n`;
    msg += userFlip === botFlip ? "🎉 You win!" : "😢 You lose!";
    await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case "numberbattle": {
    const number = Math.floor(Math.random() * 50) + 1;
    if (!text) return m.reply("❌ Guess a number between 1 and 50. Example: numberbattle 25");
    const guess = parseInt(text);
    let msg = `🎯 Your guess: ${guess}\n🎲 Target number: ${number}\n`;
    msg += guess === number ? "🎉 Perfect guess!" : guess > number ? "⬇️ Too high!" : "⬆️ Too low!";
    await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case "math": {
    const a = Math.floor(Math.random() * 50) + 1;
    const b = Math.floor(Math.random() * 50) + 1;
    const answer = a + b;
    await rich.sendMessage(m.chat, { text: `➕ Solve: ${a} + ${b}\nReply with: mathanswer <number>` }, { quoted: m });

    // Store answer to check later
}
break;
case "emojiquiz": {
    const quizzes = [
        { emoji: "🐍", answer: "snake" },
        { emoji: "🍎", answer: "apple" },
        { emoji: "🏎️", answer: "car" },
        { emoji: "🎸", answer: "guitar" },
        { emoji: "☕", answer: "coffee" }
    ];
    const quiz = quizzes[Math.floor(Math.random() * quizzes.length)];
    await rich.sendMessage(m.chat, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔🧩 Guess the Emoji:\n${quiz.emoji}\nReply with: emojianswer <your guess>` }, { quoted: m });

    // Store the correct answer for checking
}
break;
case "dice": {
    const roll = Math.floor(Math.random() * 6) + 1;
    await rich.sendMessage(m.chat, { text: `🎲 You rolled a ${roll}!` }, { quoted: m });
}
break;
case "rpsls": {
    if (!text) return m.reply("❌ Choose rock, paper, scissors, lizard, or spock. Example: rpsls spock");
    const choices = ["rock", "paper", "scissors", "lizard", "spock"];
    const userChoice = text.toLowerCase();
    if (!choices.includes(userChoice)) return m.reply("❌ Invalid choice! Use rock, paper, scissors, lizard, or spock.");

    const botChoice = choices[Math.floor(Math.random() * choices.length)];

    const winMap = {
        rock: ["scissors", "lizard"],
        paper: ["rock", "spock"],
        scissors: ["paper", "lizard"],
        lizard: ["spock", "paper"],
        spock: ["scissors", "rock"]
    };

    let result = "";
    if (userChoice === botChoice) result = "🤝 It's a tie!";
    else if (winMap[userChoice].includes(botChoice)) result = "🎉 You win!";
    else result = "😢 You lose!";

    await rich.sendMessage(
        m.chat,
        { text: `🪨 You chose: ${userChoice}\n🤖 Bot chose: ${botChoice}\n\n${result}` },
        { quoted: m }
    );
}
break;
case "coin": {
    const result = Math.random() < 0.5 ? "🪙 Heads" : "🪙 Tails";
    await rich.sendMessage(m.chat, { text: `🎲 Coin Flip Result: ${result}` }, { quoted: m });
}
break;
case "gamefact": {
    try {
        const res = await axios.get("https://www.freetogame.com/api/games");
        const games = res.data;
        const game = games[Math.floor(Math.random() * games.length)];
        await rich.sendMessage(
            m.chat,
            { text: `🎮 Game: ${game.title}\nGenre: ${game.genre}\nPlatform: ${game.platform}\nMore Info: ${game.game_url}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("GAMEFACT ERROR:", e);
        m.reply("❌ Failed to fetch a game fact.");
    }
}
break;
case "fox": {
    try {
        const res = await axios.get("https://randomfox.ca/floof/");
        const img = res.data?.image;
        if (!img) return m.reply("❌ Could not fetch a fox image.");
        await rich.sendMessage(m.chat, { image: { url: img }, caption: "🦊 Random Fox!" }, { quoted: m });
    } catch (e) {
        console.error("FOX ERROR:", e);
        m.reply("❌ Failed to fetch a fox image.");
    }
}
break;
case "koala": {
    try {
        const res = await axios.get("https://some-random-api.com/img/koala");
        const img = res.data?.link;
        if (!img) return m.reply("❌ Could not fetch a koala image.");
        await rich.sendMessage(m.chat, { image: { url: img }, caption: "🐨 Random Koala!" }, { quoted: m });
    } catch (e) {
        console.error("KOALA ERROR:", e);
        m.reply("❌ Failed to fetch a koala image.");
    }
}
break;
case "bird": {
    try {
        const res = await axios.get("https://some-random-api.com/img/birb");
        const img = res.data?.link;
        if (!img) return m.reply("❌ Could not fetch a bird image.");
        await rich.sendMessage(m.chat, { image: { url: img }, caption: "🐦 Random Bird!" }, { quoted: m });
    } catch (e) {
        console.error("BIRD ERROR:", e);
        m.reply("❌ Failed to fetch a bird image.");
    }
}
break;
case "panda": {
    try {
        const res = await axios.get("https://some-random-api.com/img/panda");
        const img = res.data?.link;
        if (!img) return m.reply("❌ Could not fetch a panda image.");
        await rich.sendMessage(m.chat, { image: { url: img }, caption: "🐼 Random Panda!" }, { quoted: m });
    } catch (e) {
        console.error("PANDA ERROR:", e);
        m.reply("❌ Failed to fetch a panda image.");
    }
}
break;
case "funfact": {
    try {
        const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
        const fact = res.data?.text || "Did you know? Bots are awesome!";
        await rich.sendMessage(m.chat, { text: `💡 Fun Fact:\n${fact}` }, { quoted: m });
    } catch (e) {
        console.error("FUNFACT ERROR:", e);
        m.reply("❌ Failed to fetch a fun fact.");
    }
}
break;
case "quotememe": {
    try {
        const res = await axios.get("https://api.quotable.io/random");
        const quote = res.data?.content || "Keep pushing forward!";
        const author = res.data?.author || "Unknown";
        await rich.sendMessage(m.chat, { text: `🖋 "${quote}"\n— ${author}` }, { quoted: m });
    } catch (e) {
        console.error("QUOTEMEME ERROR:", e);
        m.reply("❌ Failed to fetch a quote.");
    }
}
break;
case "prog": {
    try {
        const res = await axios.get("https://v2.jokeapi.dev/joke/Programming?type=single");
        const joke = res.data?.joke || "Why do programmers prefer dark mode? Because light attracts bugs!";
        await rich.sendMessage(m.chat, { text: `💻 Programming Joke:\n${joke}` }, { quoted: m });
    } catch (e) {
        console.error("PROG JOKE ERROR:", e);
        m.reply("❌ Failed to fetch a programming joke.");
    }
}
break;
case "dadjoke": {
    try {
        const res = await axios.get("https://icanhazdadjoke.com/", { headers: { Accept: "application/json" } });
        const joke = res.data?.joke || "I would tell you a joke about construction, but I'm still working on it!";
        await rich.sendMessage(m.chat, { text: `👨‍🦳 Dad Joke:\n${joke}` }, { quoted: m });
    } catch (e) {
        console.error("DAD JOKE ERROR:", e);
        m.reply("❌ Failed to fetch a dad joke.");
    }
}
break;
case "progquote": {
    try {
        const res = await axios.get("https://programming-quotes-api.herokuapp.com/quotes/random");
        const quote = res.data?.en || "Talk is cheap. Show me the code.";
        const author = res.data?.author || "Linus Torvalds";
        await rich.sendMessage(m.chat, { text: `💻 "${quote}"\n— ${author}` }, { quoted: m });
    } catch (e) {
        console.error("PROGQUOTE ERROR:", e);
        m.reply("❌ Failed to fetch a programming quote.");
    }
}
break;
case "ascii": {
    if (!text) return m.reply("❌ Provide a word or text. Example: ascii Hello");
    try {
        const res = await axios.get(`https://artii.herokuapp.com/make?text=${encodeURIComponent(text)}`);
        const ascii = res.data || text;
        await rich.sendMessage(m.chat, { text: `🎨 ASCII Art:\n\n${ascii}` }, { quoted: m });
    } catch (e) {
        console.error("ASCII ERROR:", e);
        m.reply("❌ Failed to generate ASCII art.");
    }
}
break;
case "advice": {
    try {
        const res = await axios.get("https://api.adviceslip.com/advice");
        const advice = res.data?.slip?.advice || "Keep going!";
        await rich.sendMessage(m.chat, { text: `💡 Advice:\n${advice}` }, { quoted: m });
    } catch (e) {
        console.error("ADVICE ERROR:", e);
        m.reply("❌ Failed to fetch advice.");
    }
}
break;
case "guess": {
    const number = Math.floor(Math.random() * 10) + 1; // 1–10
    if (!text) return m.reply("❌ Guess a number between 1 and 10. Example: guess 7");
    const guess = parseInt(text);
    if (isNaN(guess) || guess < 1 || guess > 10) return m.reply("❌ Invalid number! Choose 1–10.");

    let msg = `🎯 You guessed: ${guess}\n🤖 Bot chose: ${number}\n`;
    msg += guess === number ? "🎉 You guessed it! Congrats!" : "😢 Wrong guess! Try again.";
    await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
}
break;
case "urban": {
    if (!text) return m.reply("❌ Provide a word to search. Example: urban sus");
    try {
        const res = await axios.get(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(text)}`);
        const defs = res.data?.list;
        if (!defs || !defs.length) return m.reply("❌ No definition found.");
        const top = defs[0];
        const msg = `📖 Word: ${top.word}\nDefinition: ${top.definition}\nExample: ${top.example}`;
        await rich.sendMessage(m.chat, { text: msg }, { quoted: m });
    } catch (e) {
        console.error("URBAN ERROR:", e);
        m.reply("❌ Failed to fetch definition.");
    }
}
break;
case "moviequote": {
    try {
        const res = await axios.get("https://movie-quote-api.herokuapp.com/v1/quote/");
        const quote = res.data?.quote || "May the Force be with you.";
        const movie = res.data?.show || "Unknown";
        await rich.sendMessage(
            m.chat,
            { text: `🎬 "${quote}"\n— ${movie}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("MOVIE QUOTE ERROR:", e);
        m.reply("❌ Failed to fetch a movie quote.");
    }
}
break;
case "triviafact": {
    try {
        const res = await axios.get("https://uselessfacts.jsph.pl/random.json?language=en");
        const fact = res.data?.text || "Did you know? You're awesome!";
        await rich.sendMessage(m.chat, { text: `🧠 Trivia Fact:\n${fact}` }, { quoted: m });
    } catch (e) {
        console.error("TRIVIA FACT ERROR:", e);
        m.reply("❌ Failed to fetch trivia fact.");
    }
}
break;
case "inspire": {
    try {
        const res = await axios.get("https://type.fit/api/quotes");
        const quotes = res.data;
        const q = quotes[Math.floor(Math.random() * quotes.length)];
        await rich.sendMessage(
            m.chat,
            { text: `🌟 "${q.text}"\n— ${q.author || "Unknown"}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("INSPIRE ERROR:", e);
        m.reply("❌ Failed to fetch inspiring quote.");
    }
}
break;
case "compliment": {
    try {
        const res = await axios.get("https://complimentr.com/api");
        const compliment = res.data?.compliment || "You are awesome!";
        await rich.sendMessage(m.chat, { text: `💖 ${compliment}` }, { quoted: m });
    } catch (e) {
        console.error("COMPLIMENT ERROR:", e);
        m.reply("❌ Failed to fetch a compliment.");
    }
}
break;
case "dog": {
    try {
        const res = await axios.get("https://dog.ceo/api/breeds/image/random");
        const img = res.data?.message;
        if (!img) return m.reply("❌ Could not fetch a dog image.");
        await rich.sendMessage(
            m.chat,
            { image: { url: img }, caption: "🐶 Random Dog!" },
            { quoted: m }
        );
    } catch (e) {
        console.error("DOG ERROR:", e);
        m.reply("❌ Failed to fetch a dog image.");
    }
}
break;
case 'connect':
case 'bot':
case 'pair':
await rich.sendMessage(m.chat, {react: {text: '📲', key: m.key}})
  if (!q) return reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ᴘʟᴇᴀsᴇ ᴇɴᴛᴇʀ ᴀ ᴠᴀʟɪᴅ ɴᴜᴍʙᴇʀ\n✪ ᴛᴏ sᴇɴᴅ ᴘᴀɪʀɪɴɢ ʀᴇǫᴜᴇsᴛ ᴄᴏᴅᴇ
✪ *Usage: ${prefix}pair 224xxxxxxxxx*`);

  target = text.split("|")[0];
  sjid = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : target.replace(/[^0-9]/g,'') + "@s.whatsapp.net";

  var contactInfo = await rich.onWhatsApp(sjid);
  if (contactInfo.length === 0) {
    return reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛʜᴇ ɴᴜᴍʙᴇʀ ɪs ɴᴏᴛ ʀᴇɢɪsᴛᴇʀᴇᴅ ᴏɴ ᴡʜᴀᴛsᴀᴘᴘ");
  }

  const startpairing = require('./pair.js');
  await startpairing(sjid);
  await sleep(4000);

  const cu = fs.readFileSync('./richstore/pairing/pairing.json', 'utf-8');
  const cuObj = JSON.parse(cu);

  // Send just the code first
  await rich.sendMessage(from, { text: `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪${cuObj.code}` }, { quoted: m });

  // Send the instructions next
  const instructions = `
✪𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗✪\n\n
✪ ʏᴏᴜʀ ᴄᴏᴅᴇ: ${cuObj.code}

`;

  await rich.sendMessage(from, { text: instructions }, { quoted: m });
break;
case "cat": {
    try {
        const res = await axios.get("https://api.thecatapi.com/v1/images/search");
        const img = res.data[0]?.url;
        if (!img) return m.reply("❌ Could not fetch a cat image.");
        await rich.sendMessage(
            m.chat,
            { image: { url: img }, caption: "🐱 Random Cat!" },
            { quoted: m }
        );
    } catch (e) {
        console.error("CAT ERROR:", e);
        m.reply("❌ Failed to fetch a cat image.");
    }
}
break;
case "rps": {
    if (!text) return m.reply("❌ Choose rock, paper, or scissors. Example: rps rock");
    const choices = ["rock", "paper", "scissors"];
    const userChoice = text.toLowerCase();
    if (!choices.includes(userChoice)) return m.reply("❌ Invalid choice! Use rock, paper, or scissors.");

    const botChoice = choices[Math.floor(Math.random() * choices.length)];

    let result = "";
    if (userChoice === botChoice) result = "🤝 It's a tie!";
    else if (
        (userChoice === "rock" && botChoice === "scissors") ||
        (userChoice === "paper" && botChoice === "rock") ||
        (userChoice === "scissors" && botChoice === "paper")
    ) result = "🎉 You win!";
    else result = "😢 You lose!";

    await rich.sendMessage(
        m.chat,
        { text: `🪨 You chose: ${userChoice}\n🤖 Bot chose: ${botChoice}\n\n${result}` },
        { quoted: m }
    );
}
break;
case "8ball": {
    const answers = [
        "It is certain ✅",
        "Without a doubt ✅",
        "You may rely on it ✅",
        "Ask again later 🤔",
        "Cannot predict now 🤷",
        "Don't count on it ❌",
        "My sources say no ❌",
        "Very doubtful ❌"
    ];
    if (!text) return m.reply("❌ Ask me a question! Example: 8ball Will I get rich?");
    const answer = answers[Math.floor(Math.random() * answers.length)];
    await rich.sendMessage(m.chat, { text: `🎱 Question: ${text}\nAnswer: ${answer}` }, { quoted: m });
}
break;
case "trivia": {
    try {
        const res = await axios.get("https://opentdb.com/api.php?amount=1&type=multiple");
        const trivia = res.data.results[0];
        const options = [...trivia.incorrect_answers, trivia.correct_answer].sort(() => Math.random() - 0.5);
        const text = `❓ ${trivia.question}\n\nOptions:\n${options.map((o,i)=>`${i+1}. ${o}`).join("\n")}`;
        await rich.sendMessage(m.chat, { text }, { quoted: m });
        // Store trivia.correct_answer if you want to check the user's answer later
    } catch (e) {
        console.error("TRIVIA ERROR:", e);
        m.reply("❌ Failed to fetch trivia question.");
    }
}
break;
case "meme": {
    try {
        const res = await axios.get("https://meme-api.com/gimme");
        const meme = res.data;
        if (!meme?.url) return m.reply("❌ Could not fetch a meme.");
        await rich.sendMessage(
            m.chat,
            { image: { url: meme.url }, caption: `😂 ${meme.title}` },
            { quoted: m }
        );
    } catch (e) {
        console.error("MEME ERROR:", e);
        m.reply("❌ Failed to fetch a meme.");
    }
}
break;
case 'gfx':
case 'gfx2':
case 'gfx3':
case 'gfx4':
case 'gfx5':
case 'gfx6':
case 'gfx7':
case 'gfx8':
case 'gfx9':
case 'gfx10':
case 'gfx11':
case 'gfx12': {
  const [text1, text2] = text.split('|').map(v => v.trim());
  if (!text1 || !text2) {
    return reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔ Example: ${prefix + command} 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋`);
  }

  reply(` 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n⎔ *Generating your stylish image...\n✪🔤 Text 1: ${text1}\n✪🔡 Text 2: ${text2}\n✪⏳ Please wait!`);

  try {
    const style = command.toUpperCase();
    const apiUrl = `https://api.nexoracle.com/image-creating/${command}?apikey=d0634e61e8789b051e&text1=${encodeURIComponent(text1)}&text2=${encodeURIComponent(text2)}`;

    await sendImage(apiUrl, `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ - ${style} Style\n✪🔤 Text 1: ${text1}\n✪🔡 Text 2: ${text2}`);
  } catch (err) {
    console.error(err);
    reply(`Failed to generate ${command.toUpperCase()} image.`);
  }
  break;
}

case 'getpp':{
    if (!isCreator && !isSudo) return;
let userss = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let ghosst = userss
        try {
   var ppuser = await rich.profilePictureUrl(ghosst, 'image')
} catch (err) {
   var ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
rich.sendMessage(from, { image: { url: ppuser }}, { quoted: m })
}
break;
case 'yts': case 'ytsearch': {
  if (!isCreator && !isSudo) return;
                if (!text) return reply(`Example : ${prefix + command} story wa anime`)
                let yts = require("yt-search")
                let search = await yts(text)
                let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
                let no = 1
                for (let i of search.all) {
                    teks += `${themeemoji} No : ${no++}\n${themeemoji} Type : ${i.type}\n${themeemoji} Video ID : ${i.videoId}\n${themeemoji} Title : ${i.title}\n${themeemoji} Views : ${i.views}\n${themeemoji} Duration : ${i.timestamp}\n${themeemoji} Uploaded : ${i.ago}\n${themeemoji} Url : ${i.url}\n\n─────────────────\n\n`
                }
                rich.sendMessage(m.chat, { image: { url: search.all[0].thumbnail },  caption: teks }, { quoted: m })
            }
            break

case 'animewlp':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://nekos.life/api/v2/img/wallpaper`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;


case 'resetlink': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
if (!isCreator && !isSudo) return;
if (!m.isGroup) return reply(mess.only.group)
if (!isBotAdmins) return reply('Bots Must Be Admins First')
if (!isAdmins) return;
rich.groupRevokeInvite(m.chat)
}
break;
case 'animesearch': {
if (!isCreator && !isSudo) return;
if (!text) return reply(`Which anime are you lookin for?`)
const malScraper = require('mal-scraper')
        const anime = await malScraper.getInfoFromName(text).catch(() => null)
        if (!anime) return reply(`Could not find`)
let animetxt = `
🎀 *Title: ${anime.title}*
🎋 *Type: ${anime.type}*
🎐 *Premiered on: ${anime.premiered}*
💠 *Total Episodes: ${anime.episodes}*
📈 *Status: ${anime.status}*
💮 *Genres: ${anime.genres}
📍 *Studio: ${anime.studios}*
🌟 *Score: ${anime.score}*
💎 *Rating: ${anime.rating}*
🏅 *Rank: ${anime.ranked}*
💫 *Popularity: ${anime.popularity}*
♦️ *Trailer: ${anime.trailer}*
🌐 *URL: ${anime.url}*
❄ *Description:* ${anime.synopsis}*`
                await rich.sendMessage(m.chat,{image:{url:anime.picture}, caption:animetxt},{quoted:m})
                }
                break;

            case 'animehighfive':{
            if (isban) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/highfive`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animecringe':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/cringe`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animedance':{
if (!isCreator && !isSudo) return;
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/dance`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animehappy':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/happy`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeglomp':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/glomp`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animesmug':{
if (!isCreator && !isSudo) return;
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smug`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeblush':{
if (!isCreator && !isSudo) return;
reply(mess.wait)
 waifudd = await axios.get(`https://waifu.pics/api/sfw/blush`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;

case 'animewave':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wave`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animesmile':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/smile`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animepoke':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/poke`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animewink':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/wink`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebonk':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bonk`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebully':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bully`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animeyeet':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/yeet`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animebite':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/bite`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animelick':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/lick`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;
case 'animekill':{
if (!isCreator && !isSudo) return;
 waifudd = await axios.get(`https://waifu.pics/api/sfw/kill`)
            await rich.sendMessage(m.chat, { image: { url:waifudd.data.url} , caption: m.success}, { quoted:m }).catch(err => {
return('Error!')
})
}
break;


           case 'cry': case 'kill': case 'hug': case 'pat': case 'lick':
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile':
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp':
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive':
case 'shinobu': case 'handhold': {
 if (!isCreator && !isSudo) return;
axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
rich.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break;
 case 'ai': {
  if (!text) return reply('Example: .ai what is the capital of cameroon?');

  await rich.sendPresenceUpdate('composing', m.chat);

  try {
    const { data } = await axios.post("https://chateverywhere.app/api/chat/", {
      model: {
        id: "gpt-4",
        name: "GPT-4",
        maxLength: 32000,
        tokenLimit: 8000,
        completionTokenLimit: 5000,
        deploymentName: "gpt-4"
      },
      messages: [{ pluginId: null, content: text, role: "user" }],
      prompt: text,
      temperature: 0.5
    }, {
      headers: {
        "Accept": "*/*",
        "User-Agent": "WhatsApp Bot"
      }
    });

    await rich.sendMessage(m.chat, {
      text: `╭━━━━━━━━━━━━━━━━━≽𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n│\n ✪
      ǫsᴛ: ${text}\n ┃ \n ┃ ✪ ᴀɴsᴡᴇʀ:\n ┃ ${data}\n ┃ \n ┃ ✪ ᴅᴏ ʏᴏᴜ ɴᴇᴇᴅ sᴏᴍᴇᴛʜɪɴɢ ᴇʟsᴇ ?
      ╰━━━━━━━━━━━━━━━━━≽`
    }, { quoted: m });

  } catch (e) {
    await reply(`AI encountered a problem: ${e.message}`);
  }
}
break
case 'idch': {
if (!isCreator && !isSudo) return;
if (!text) return reply("example : link channel")
if (!text.includes("https://whatsapp.com/channel/0029Vb7jG2KEawdwHsZiEm1E")) return reply("not a valid Link ")
let result = text.split('https://whatsapp.com/channel/0029Vb7jG2KEawdwHsZiEm1E')[1]
let res = await rich.newsletterMetadata("invite", result)
let teks = `   𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗
✪ *ID :* ${res.id}
✪*Name :* ${res.name}
✪ *Follower:* ${res.subscribers}
✪ *Status :* ${res.state}
✪ *Verified :* ${res.verification == "VERIFIED" ? "Verified" : "No"}
`
return reply(teks)
}
    break;
case 'closetime': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!isAdmins && !isCreator) return;

    let unit = args[1];
    let value = Number(args[0]);
    if (!value) return reply("*Usage:* closetime <number> <second/minute/hour/day>\n\n*Example:* 10 minute");

    let timer;
    if (unit === 'second') {
        timer = value * 1000;
    } else if (unit === 'minute') {
        timer = value * 60000;
    } else if (unit === 'hour') {
        timer = value * 3600000;
    } else if (unit === 'day') {
        timer = value * 86400000;
    } else {
        return reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n10 minute');
    }

    reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪⏳ Close Time ${value} ${unit} starting from now...`);

    setTimeout(async () => {
        try {
            await rich.groupSettingUpdate(m.chat, 'announcement');
            reply(`✅ *On time!* Group has been closed by Admin\nNow only Admins can send messages.`);
        } catch (e) {
            reply('❌ Failed: ' + e.message);
        }
    }, timer);
}
break;
case 'opentime': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    if (!isAdmins && !isCreator) return;

    let unit = args[1];
    let value = Number(args[0]);
    if (!value) return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *Usage:* opentime <number> <second/minute/hour/day>\n\n✪ *Example:* 5 second');

    let timer;
    if (unit === 'second') {
        timer = value * 1000;
    } else if (unit === 'minute') {
        timer = value * 60000;
    } else if (unit === 'hour') {
        timer = value * 3600000;
    } else if (unit === 'day') {
        timer = value * 86400000;
    } else {
        return reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example:*\n5 second');
    }

    reply(`⏳ Open Time ${value} ${unit} starting from now...`);

    setTimeout(async () => {
        try {
            await rich.groupSettingUpdate(m.chat, 'not_announcement');
            reply(`✅ *On time!* Group has been opened by Admin\nNow members can send messages.`);
        } catch (e) {
            reply('❌ Failed: ' + e.message);
        }
    }, timer);
}
 break;
case 'listonline': {
if (!isCreator && !isSudo) return;
        if (!m.isGroup) return reply(m.grouponly);
        rich.sendMessage(from, { react: { text: "✅", key: m.key } })
        let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
        let online = [...Object.keys(store.presences[id]), botNumber]
        let liston = 1
        rich.sendText(m.chat, ' 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ʟɪsᴛ ᴏғ ᴏɴʟɪɴᴇ ᴍᴇᴍʙᴇʀs\n\n' + online.map(v => `✪${liston++} . @` + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
      }
      break;
case 'gpt4': case 'openai': case 'xxai': {
if (!isCreator && !isSudo) return;
  if (!text) return reply(`Ask me anything example ${command} how are you?`)
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text,
                "role": "user"
            }
        ],
        "prompt": logic,
        "temperature": 0.5
    }, {
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });

    let result = response.data;
    return result;
}

let pei = await openai(text, "")
m.reply(pei)
}
break;

case 'quote': {
    try {
        const res = await fetch('https://zenquotes.io/api/random');
        const json = await res.json();
        const quote = json[0].q;
        const author = json[0].a;

        // Optional: Generate image using API
        const quoteImg = `https://dummyimage.com/600x400/000/fff.png&text=${encodeURIComponent(`"${quote}"\n\n- ${author}`)}`;

        rich.sendMessage(m.chat, {
            image: { url: quoteImg },
            caption: `_"${quote}"_\n\n— *${author}*`
        }, { quoted: m });

    } catch (err) {
        m.reply('Failed to fetch quote.');
    }
}
break;

case 'joke': {
  let res = await fetch('https://v2.jokeapi.dev/joke/Any?type=single');
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/gr1jfa.jpg' },
    caption: `*😂 Here's a joke for you:*\n\n${data.joke}`
  }, { quoted: m });
}
break;
case 'truth': {
  let res = await fetch('https://api.truthordarebot.xyz/v1/truth');
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/ef1bcx.jpg' },
    caption: `*🔥 Truth Time!*\n\n❖ ${data.question}`
  }, { quoted: m });
}
break;
case 'dare': {
  let res = await fetch('https://api.truthordarebot.xyz/v1/dare');
  let data = await res.json();

  await rich.sendMessage(m.chat, {
    image: { url: 'j' },
    caption: `*🔥 Dare Challenge!*\n\n❖ ${data.question}`
  }, { quoted: m });
}
break;
case 'jid':{
            reply(from)
           }
          break;
case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'squirrel':
    try {
        let set;
        if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20';
        else if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log';
        else if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3';
        else if (/earrape/.test(command)) set = '-af volume=12';
        else if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"';
        else if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"';
        else if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25';
        else if (/reverse/.test(command)) set = '-filter_complex "areverse"';
        else if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"';
        else if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"';
        else if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"';
        else if (/squirrel/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"';
        if (set) {
            if (/audio/.test(mime)) {
                let media = await rich.downloadAndSaveMediaMessage(quoted);
                let ran = getRandom('.mp3');
                console.log(`Running ffmpeg command: ffmpeg -i ${media} ${set} ${ran}`);
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                    fs.unlinkSync(media);
                    if (err) {
                        console.error(`ffmpeg error: ${err}`);
                        return reply(err);
                    }

                    let buff = fs.readFileSync(ran);
                    rich.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted: m });
                    fs.unlinkSync(ran);
                });
            } else {
                reply(`Reply to the audio you want to change with a caption *${prefix + command}*`);
            }
        } else {
            reply('Invalid command');
        }
    } catch (e) {
        reply(e);
    }
    break;

case 'say':{

if (!qtext) return reply('Where is the text?')
            let texttts = text
            const xeonrl = googleTTS.getAudioUrl(texttts, {
                lang: "en",
                slow: false,
                host: "https://translate.google.com",
            })
            return rich.sendMessage(m.chat, {
                audio: {
                    url: xeonrl,
                },
                mimetype: 'audio/mp4',
                ptt: true,
                fileName: `${text}.mp3`,
            }, {
                quoted: m,
            })
        }
        break;

// waifu cases

    case "rwaifu": {

    const imageUrl = `https://apis.davidcyriltech.my.id/random/waifu`;
    await rich.sendMessage(m.chat, {
        image: { url: imageUrl },
        caption: "Your rwaifu by Nicky Tech"
      }, { quoted: m }); // Add quoted  for context
      }
      break;
      case 'waifu' :

waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`)
rich.sendMessage(from, {image: {url:waifudd.data.url},caption:`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Your waifu`}, { quoted:m }).catch(err => {
 return('Error!')
})
break;
case 'vv': {
    // Reveals the view-once media INTO this chat. .vv2 / .cute are the private
    // variants: they deliver to your DM and leave this chat untouched.
    if (!m.quoted) {
        return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴜꜱᴀɢᴇ : ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴠɪᴇᴡ-ᴏɴᴄᴇ ᴍᴇꜱꜱᴀɢᴇ');
    }
    const found = unwrapViewOnce(m.quoted);
    if (!found) {
        return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ꜱᴛᴀᴛᴜꜱ : ❌ ɴᴏᴛ ᴀ ᴠɪᴇᴡ-ᴏɴᴄᴇ ᴍᴇꜱꜱᴀɢᴇ');
    }
    try {
        const buf = await rich.downloadMediaMessage({ ...found.node, mtype: found.type });
        if (!buf || !buf.length) {
            return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛʜᴇ ᴍᴇᴅɪᴀ ᴄᴏᴜʟᴅ ɴᴏᴛ ʙᴇ ᴅᴏᴡɴʟᴏᴀᴅᴇᴅ (ɪᴛ ᴍᴀʏ ʜᴀᴠᴇ ᴇxᴘɪʀᴇᴅ).');
        }
        if (found.mediaType === 'image') {
            await rich.sendMessage(m.chat, { image: buf, caption: '👁 𝐑𝐞𝐯𝐞𝐚𝐥𝐞𝐝' }, { quoted: m });
        } else if (found.mediaType === 'video') {
            await rich.sendMessage(m.chat, { video: buf, caption: '👁 𝐑𝐞𝐯𝐞𝐚𝐥𝐞𝐝' }, { quoted: m });
        } else {
            await rich.sendMessage(m.chat, { audio: buf, mimetype: 'audio/ogg', ptt: false }, { quoted: m });
        }
    } catch (e) {
        await reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ 𝐄ʀʀᴏʀ : ${e.message}`);
    }
}
break;

case 'vv2':
case 'cute': {
    // Recovers view-once media and delivers it to the sender's DM. The chat the
    // command was used in stays completely clean -- no media, no confirmation, no
    // error message. Every response, success or failure, goes to the DM.
    //
    // dm needs no special case (pair.js:833 sets m.sender = decodeJid(fromMe ?
    // user.id : participant)):
    //  * this account's own command -> m.sender is the account JID, i.e. the
    //    "message yourself" chat;
    //  * anybody else -> m.sender is their participant JID, i.e. their DM.
    // The @g.us fallback is a seatbelt: if the sender ever resolved to a group,
    // fall back to the account JID rather than posting into the chat.
    let dm = m.sender || '';
    if (!dm || /@g\.us$/i.test(dm)) dm = rich.decodeJid(rich.user.id);
    const dmReply = async (t) => { try { return await rich.sendMessage(dm, { text: t }); } catch (e) {} };
    const senderNumber = String(m.sender || '').split('@')[0].split(':')[0];

    // The typed command is the one thing that would otherwise stay visible in the
    // chat, and the account that ran it owns that message, so it can always be
    // deleted. Set to false to keep ".vv2" on screen instead.
    const VV2_DELETE_TRIGGER = true;
    if (VV2_DELETE_TRIGGER) {
        try { await rich.sendMessage(m.chat, { delete: m.key }); } catch (e) {}
    }

    if (!m.quoted) {
        return dmReply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴜꜱᴀɢᴇ : ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴠɪᴇᴡ-ᴏɴᴄᴇ ᴍᴇᴅɪᴀ ᴡɪᴛʜ .ᴠᴠ2');
    }

    const found = unwrapViewOnce(m.quoted);
    if (!found) {
        return dmReply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ꜱᴛᴀᴛᴜꜱ : ❌ ɴᴏᴛ ᴀ ᴠɪᴇᴡ-ᴏɴᴄᴇ ᴍᴇꜱꜱᴀɢᴇ');
    }

    try {
        const buf = await rich.downloadMediaMessage({ ...found.node, mtype: found.type });
        if (!buf || !buf.length) {
            return dmReply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛʜᴇ ᴍᴇᴅɪᴀ ᴄᴏᴜʟᴅ ɴᴏᴛ ʙᴇ ᴅᴏᴡɴʟᴏᴀᴅᴇᴅ (ɪᴛ ᴍᴀʏ ʜᴀᴠᴇ ᴇxᴘɪʀᴇᴅ).');
        }

        const label = found.mediaType.toUpperCase();
        const caption = `🔓 ᴠɪᴇᴡ-ᴏɴᴄᴇ ${label}\nꜰʀᴏᴍ : ${senderNumber}`;
        if (found.mediaType === 'image') {
            await rich.sendMessage(dm, { image: buf, caption, mimetype: 'image/jpeg' });
        } else if (found.mediaType === 'video') {
            await rich.sendMessage(dm, { video: buf, caption });
        } else {
            await rich.sendMessage(dm, { audio: buf, mimetype: 'audio/ogg', ptt: false });
        }

        await dmReply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ꜱᴛᴀᴛᴜꜱ : ✅ ${label} ᴅᴇʟɪᴠᴇʀᴇᴅ ᴛᴏ ʏᴏᴜʀ ᴅᴍ`);
    } catch (error) {
        // Was replyn(), defined nowhere in this bot: every failure became a
        // ReferenceError and the caller got silence instead of a reason.
        console.error('vv2 error:', error);
        await dmReply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ꜱᴛᴀᴛᴜꜱ : ❌ ꜰᴀɪʟᴇᴅ ᴛᴏ ᴘʀᴏᴄᴇꜱꜱ');
    }
}
break;

case 'listgc':
case 'cr7': {
    // skylar's handleListGC. NOTE: your bot already has .listgroup / .grouplist
    // doing exactly this (case.js:996) -- this one is kept only for the boxed
    // output. Nothing depends on it; say the word and I will drop it again.
    if (!isCreator && !isSudo) return;
    if (typeof rich.groupFetchAllParticipating !== 'function') {
        return reply('❌ Group listing is unavailable in this Baileys build.');
    }
    try {
        const groupList = Object.values((await rich.groupFetchAllParticipating()) || {});
        if (!groupList.length) {
            return reply(boxText('LIST GC', 'The connected WhatsApp number is not in any groups.'));
        }
        let out = `╭━━━━━━━━━━━━━━━━━━━━\n┃ WHATSAPP GROUP LIST\n┃ TOTAL: ${groupList.length}\n┃━━━━━━━━━━━━━━━━━━━━\n`;
        groupList.forEach((group, index) => {
            out += `┃ ${index + 1}. ${group.subject || '(No name)'}\n┃ ID: ${group.id}\n┃━━━━━━━━━━━━━━━━━━━━\n`;
        });
        out += '╰━━━━━━━━━━━━━━━━━━━━';
        await reply(out);

        // Tap-to-copy chips for the IDs, so a GID never has to be selected by hand.
        // Capped: one chip per group in a long list makes for a very tall message.
        const CHIP_LIMIT = 40;
        const chips = groupList.slice(0, CHIP_LIMIT).map((group) => ({ value: group.id }));
        const sentChips = await sendCopyChips(rich, m.chat, chips);
        if (!sentChips) {
            await reply('ℹ️ Copy buttons are unavailable in this Baileys build — the IDs above stay plain text.');
        } else if (groupList.length > chips.length) {
            await reply(`ℹ️ Copy buttons shown for the first ${chips.length} of ${groupList.length} groups.`);
        }
        return;
    } catch (error) {
        console.error('LIST GC ERROR:', error);
        return reply(boxText('LIST GC', 'Failed to fetch the groups.'));
    }
}
break;

case 'skeng':
case 'gcban': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
    // skylar's handleSkeng. Renamed from .vinijr to .gcban. Owner only, 30s cooldown per sender, fills a target
    // group with the GCBAN_NUMBERS pool. The juggle/jump "hijack" from the same
    // file was NOT added.
    if (!isCreator) return reply(boxText('GCBAN', '❌ Only owners can use this command.'));

    const senderNumber = jidToNumber(sender || botNumber);
    const now = Date.now();
    const lastUsed = gcbanCooldowns.get(senderNumber) || 0;
    if (now - lastUsed < GCBAN_COOLDOWN_MS) {
        const wait = Math.ceil((GCBAN_COOLDOWN_MS - (now - lastUsed)) / 1000);
        return reply(boxText('GCBAN', `⏳ Please wait ${wait}s before using this command again.`));
    }

    const cmdArgs = String(text || '').trim().split(/\s+/).filter(Boolean);
    const input = cmdArgs[0] || '';
    if (!input) {
        return reply(boxText('GCBAN',
`${command} <link|group-id> [amount]

Examples:
${command} https://chat.whatsapp.com/ABCdef123 10
${command} 123456789@g.us 10

Default amount: 5`));
    }

    let groupJid;
    const matchInvite = input.match(/https:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
    if (matchInvite) {
        if (typeof rich.groupAcceptInvite !== 'function') {
            return reply(boxText('GCBAN', '❌ This Baileys build cannot join by invite link. Pass the group ID instead.'));
        }
        await reply(boxText('GCBAN', '⏳ Joining group via invite link...'));
        try {
            groupJid = await rich.groupAcceptInvite(matchInvite[1]);
        } catch (err) {
            return reply(boxText('GCBAN', `❌ Failed to join the group: ${err.message}`));
        }
    } else {
        if (!input.endsWith('@g.us')) {
            return reply(boxText('GCBAN', '❌ Group ID must end with @g.us or use an invite link.'));
        }
        groupJid = input;
    }

    let amount = parseInt(cmdArgs[1], 10) || 5;
    if (amount < 1) amount = 1;
    if (amount > 20) amount = 20;

    const sentMsg = await rich.sendMessage(m.chat, {
        text: boxText('GCBAN',
`Sender   : @${senderNumber}
Target   : ${groupJid}
Amount   : ${amount}
Status   : Processing...
Time     : ${new Date().toLocaleString('en-US')}`)
    }, { quoted: m });

    gcbanCooldowns.set(senderNumber, now);

    let successCount = 0;
    for (let i = 0; i < amount; i++) {
        const targetNumber = GCBAN_NUMBERS[i % GCBAN_NUMBERS.length];
        try {
            await rich.groupParticipantsUpdate(groupJid, [targetNumber], 'add');
            successCount++;
            console.log(`[GCBAN] injected ${targetNumber} (${i + 1}/${amount})`);
        } catch (err) {
            console.error(`[GCBAN] failed to inject ${targetNumber}:`, err.message);
        }
        await new Promise((r) => setTimeout(r, 1500 + Math.random() * 3000));
    }

    const doneText = boxText('GCBAN',
`Sender   : @${senderNumber}
Target   : ${groupJid}
Amount   : ${amount}
Status   : ✅ Done! ${successCount}/${amount} injected.
Time     : ${new Date().toLocaleString('en-US')}`);
    try {
        await rich.sendMessage(m.chat, { text: doneText, edit: sentMsg.key });
    } catch (err) {
        await reply(doneText);
    }
}
break;

case 'av':
case 'aivoice': {
    // Ported from Elite Pro (payload remote.js:6594). Reply to a message or pass a query:
    // the AI answer is turned into speech and sent back as a voice note.
    try {
        let query = String(text || '').trim();
        if (m.quoted && m.quoted.text) {
            query = query ? `${query} ${m.quoted.text}` : m.quoted.text;
        }
        if (!query) return reply('Example: .av Hello — or reply to a message');

        await rich.sendPresenceUpdate('recording', m.chat);

        const aiRes = await axios.get(`https://api.bk9.dev/ai/copilot?q=${encodeURIComponent(query)}`, { timeout: 45000 });
        if (!aiRes.data || !aiRes.data.status || !aiRes.data.BK9 || !aiRes.data.BK9.response) {
            return reply('❌ Failed to generate AI response.');
        }

        const spoken = String(aiRes.data.BK9.response).slice(0, 1000)
            .replace(/```[\s\S]*?```/g, '')
            .replace(/^\s*#{1,6}\s*/gm, '')
            .replace(/^\s*\/\/\s?/gm, '')
            .replace(/\*\*(.*?)\*\*/g, '$1')
            .replace(/\*(.*?)\*/g, '$1')
            .replace(/__(.*?)__/g, '$1')
            .replace(/_(.*?)_/g, '$1')
            .replace(/`([^`]+)`/g, '$1')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
        if (!spoken) return reply('❌ No readable text was generated.');

        const voiceRes = await axios.get(`https://ab-text-voice.abrahamdw882.workers.dev/?q=${encodeURIComponent(spoken)}&voicename=jane`, { timeout: 45000 });
        if (!voiceRes.data || !voiceRes.data.url) return reply('❌ Failed to generate voice.');

        const clip = await axios.get(voiceRes.data.url, { responseType: 'arraybuffer', timeout: 60000 });

        // Elite runs toPTT() here. Yours is internal to pair.js, so use it when the socket
        // exposes it and fall back to a plain audio file when it does not.
        if (typeof rich.toPTT === 'function') {
            const voice = await rich.toPTT(Buffer.from(clip.data), 'mp3');
            await rich.sendMessage(m.chat, {
                audio: voice,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true
            }, { quoted: m });
        } else {
            await rich.sendMessage(m.chat, {
                audio: Buffer.from(clip.data),
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: m });
        }
    } catch (err) {
        console.error('AIVOICE Error:', err && err.message);
        await reply('❌ Error occurred while generating aivoice.');
    }
}
break;

case 'sticker':
case 'stiker':
case 's': {
    // Ported from Elite Pro (payload remote.js:9107). Reply to an image or a short video
    // (or caption the image itself) and it comes back as a sticker.
    try {
        const mtype = String(m.mtype || '');
        const q = m.quoted ? m.quoted : (/^(image|video)Message$/.test(mtype) ? m : null);
        const qmime = (q?.msg || q)?.mimetype || '';
        const pack = getSetting('bot', 'packname', '') || ownername;
        const auth = getSetting('bot', 'author', '') || ownername;

        if (!q) return await reply(`Reply to an image or video with *${prefix + command}*`);

        if (/image/.test(qmime)) {
            const media = await rich.downloadMediaMessage(q);
            await rich.sendImageAsSticker(m.chat, media, m, { packname: pack, author: auth });
        } else if (/video/.test(qmime)) {
            if (((q.msg || q).seconds || 0) > 10) return await reply('❌ Maximum video length for a sticker is 10 seconds.');
            const media = await rich.downloadMediaMessage(q);
            const webp = await writeExifVid(media, { packname: pack, author: auth });
            if (!webp) return await reply('❌ Could not build the sticker.');
            await rich.sendMessage(m.chat, { sticker: fs.readFileSync(webp) }, { quoted: m });
            try { fs.unlinkSync(webp); } catch (e) {}
        } else {
            return await reply(`Send or reply to an image/video with *${prefix + command}*\n(Video must be 1–10 seconds)`);
        }
    } catch (err) {
        console.error('STICKER Error:', err && err.message);
        await reply('❌ Failed to create the sticker.');
    }
}
break;

case 'take':
case 'steal':
case 'swm': {
    // Ported from Elite Pro (payload remote.js:9165). Re-packs a sticker/image/video under a
    // new pack name. Usage: .take Pack|Author   (defaults to .packname / .author, then the bot name)
    try {
        const mtype = String(m.mtype || '');
        const q = m.quoted ? m.quoted : (/^(image|video|sticker)Message$/.test(mtype) ? m : null);
        if (!q) return await reply(`Reply to a sticker, image or video with *${prefix + command} name|author*`);

        const qmime = (q?.msg || q)?.mimetype || '';
        const [pArg, aArg] = String(text || '').split('|').map(v => (v || '').trim());
        const pack = pArg || getSetting('bot', 'packname', '') || ownername;
        const auth = aArg || getSetting('bot', 'author', '') || ownername;

        if (/webp/.test(qmime)) {
            // Already a webp: rewrite the exif container only, so animated stickers keep moving.
            const media = await rich.downloadMediaMessage(q);
            const out = await addExif(media, pack, auth);
            await rich.sendMessage(m.chat, { sticker: out }, { quoted: m });
        } else if (/image/.test(qmime)) {
            const media = await rich.downloadMediaMessage(q);
            await rich.sendImageAsSticker(m.chat, media, m, { packname: pack, author: auth });
        } else if (/video/.test(qmime)) {
            if (((q.msg || q).seconds || 0) > 10) return await reply('❌ Maximum 10 Seconds!');
            const media = await rich.downloadMediaMessage(q);
            const webp = await writeExifVid(media, { packname: pack, author: auth });
            if (!webp) return await reply('❌ Could not build the sticker.');
            await rich.sendMessage(m.chat, { sticker: fs.readFileSync(webp) }, { quoted: m });
            try { fs.unlinkSync(webp); } catch (e) {}
        } else {
            return await reply(`Reply to a sticker, image or video with *${prefix + command} name|author*`);
        }
    } catch (err) {
        console.error('TAKE Error:', err && err.message);
        await reply('❌ Failed to re-pack the sticker.');
    }
}
break;

case 'qc': {
  if (!text) return reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Use format: *.qc your quote*');

  const name = m.pushName || 'User';
  const quote = text.trim();

  let profilePic;
  try {
    profilePic = await rich.profilePictureUrl(m.sender, 'image');
  } catch {
    profilePic = 'https://telegra.ph/file/6880771c1f1b5954d7203.jpg'; // fallback
  }

  const url = `https://www.laurine.site/api/generator/qc?text=${encodeURIComponent(quote)}&name=${encodeURIComponent(name)}&photo=${encodeURIComponent(profilePic)}`;

  try {
    await rich.sendImageAsSticker(m.chat, url, m, {
      packname: global.packname,
      author: global.author
    });
  } catch (err) {
    console.error('Quote card sticker generation error:', err);
    reply('Oops! Failed to create your quote sticker.');
  }
}
break;

case 'shorturl':{
if (!text) return reply('[ Wrong! ] link/url')
let shortUrl1 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
if (!shortUrl1) return reply(`*Error: Could not generate a short URL.*`);
let done = `*[ Done by ᴅᴇɴᴋɪ xᴍᴅ ᴠ1]*\n\n*Original Link :*\n${text}\n*Shortened :*\n${shortUrl1}`.trim();
 reply(done)
}
break;

case 'unblock': case 'unblocked': {
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
                await rich.updateBlockStatus(users, 'unblock')
                await reply(`Done`)
        }
        break;
        case 'block': case 'blocked': {
                let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
                await rich.updateBlockStatus(users, 'block')
                await reply(`Done`)
                        }
        break;

case 'creategc':
case 'creategroup': {
  const groupName = args.join(" ");
  if (!groupName) return reply(`Use *${prefix + command} groupname*`);

  try {
    const cret = await rich.groupCreate(groupName, []);
    const code = await rich.groupInviteCode(cret.id);
    const link = `https://chat.whatsapp.com/${code}`;

    const teks = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪「 Group Created 」
▸ *Name:* ${cret.subject}
▸ *Group ID:* ${cret.id}
▸ *Owner:* @${cret.owner.split("@")[0]}
▸ *Created:* ${moment(cret.creation * 1000).tz("Africa/Lagos").format("DD/MM/YYYY HH:mm:ss")}
▸ *Invite Link:* ${link}`;

    rich.sendMessage(m.chat, {
      text: teks,
      mentions: [cret.owner]
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    reply("Failed to create group. Please check and try again.");
  }
}
break;
// take
case 'toimg':
  {
    const quoted = m.quoted ? m.quoted : null
    const mime = (quoted?.msg || quoted)?.mimetype || ''
    if (!quoted) return reply('Reply to a sticker/image.')
    if (!/webp/.test(mime)) return reply(`Reply to a sticker with *${prefix}toimg*`)
    if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp')
    const media = await rich.downloadMediaMessage(quoted)
    const filePath = `./tmp/${Date.now()}.jpg`
    fs.writeFileSync(filePath, media)
    await rich.sendMessage(m.chat, { image: fs.readFileSync(filePath) }, { quoted: m })
    fs.unlinkSync(filePath)
  }
  break;
         case "play":
  case "play2": {
    if (!text) return reply(example("past lives"));

    const clearReact = async () => {
      try { await rich.sendMessage(m.chat, { react: { text: '', key: m.key } }); } catch (e) {}
    };

    await rich.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

    try {
      if (!ytdl) {
        await clearReact();
        return reply('❌ play is unavailable: @vreden/youtube_scraper did not load on this server.');
      }

      const ytsSearch = await yts(text);
      const res = (ytsSearch.all || []).find(v => v && v.type === 'video' && v.url);
      if (!res) {
        await clearReact();
        return reply('Error! Result Not Found');
      }

      // Button ids are commands: "<prefix>playdl <fmt> <url>". The reply is fed
      // straight back through the prefix/command parser, and the prefix is
      // configurable (.setprefix), so it must stay dynamic here.
      const mkBtn = (label, fmt) => quickReply(label, `${prefix}playdl ${fmt} ${res.url}`);

      let header = null;
      try { header = await headerImage(rich, res.thumbnail); } catch (e) { header = null; }

      await sendInteractiveButtons(rich, from, {
        title: `🎵 ${res.title || 'YouTube'}`,
        text: `*${res.title || 'Unknown'}*\n`
            + `👤 ${(res.author && res.author.name) || '—'}\n`
            + `⏱ ${res.timestamp || '—'}\n`
            + `👁 ${res.views ? Number(res.views).toLocaleString() : '—'}\n\n`
            + `*Choose how to receive it:*`,
        footer: 'ASTROCORE X',
        buttons: [
          mkBtn('🎵 Audio', 'audio'),
          mkBtn('🎬 Video', 'video'),
          mkBtn('📄 Document', 'doc'),
        ],
        imageMessage: header || undefined,
        quoted: m,
      });

      await clearReact();
    } catch (e) {
      await clearReact();
      reply('❌ play failed: ' + (e && e.message ? e.message : e));
    }
  }
  break;

  case "playdl": {
    const fmt = String(args[0] || '').toLowerCase();
    const target = String(args[1] || '').trim();

    if (!target || !/^https?:\/\//i.test(target)) {
      return reply(`❌ That button is stale. Send *${prefix}play <song name>* again.`);
    }
    if (!ytdl) {
      return reply('❌ play is unavailable: @vreden/youtube_scraper did not load on this server.');
    }

    const clearReactDl = async () => {
      try { await rich.sendMessage(m.chat, { react: { text: '', key: m.key } }); } catch (e) {}
    };

    await rich.sendMessage(m.chat, { react: { text: '⬇️', key: m.key } });

    try {
      const safeName = (src) => String(src || 'file')
        .replace(/[\\/:*?"<>|\n\r]/g, '_').trim().slice(0, 70) || 'file';

      if (fmt === 'video') {
        // Do NOT switch this back to ytdl.ytmp4(): savetube hands back an AV1
        // stream (ftyp "isomav01iso2mp41" + an av1C box, no avc1), and WhatsApp
        // cannot decode AV1 -- the file lands and never plays. OMEGA_API returns
        // H.264 (avc1) + AAC in an mp42 container, the same source .ytvideo uses.
        //
        // Those links also 403 about a third of the time on the first try
        // (measured 4/6), which is indistinguishable from a codec failure on the
        // user's side. Each mint is therefore pre-flighted with a 2-byte range
        // request and re-minted when it is dead, so an unverified link is never
        // what gets sent.
        let v = null;
        for (let attempt = 0; attempt < 3 && !v; attempt++) {
          const { data } = await axios.get(`${OMEGA_API}/download/YouTube`, {
            params: { action: 'download', url: target },
            timeout: 90000,
          });
          const cand = data && data.data;
          if (!cand || !cand.url) continue;
          try {
            const probe = await axios.get(cand.url, {
              headers: { Range: 'bytes=0-1' },
              timeout: 20000,
              validateStatus: () => true,
            });
            if (probe.status === 200 || probe.status === 206) v = cand;
          } catch (probeErr) { /* transient edge failure -- re-mint */ }
        }
        if (!v) {
          await clearReactDl();
          return reply('❌ No playable (H.264) stream for that song. Try again, or use the Document button.');
        }
        const name = safeName(v.title || 'video');
        try {
          await rich.sendMessage(m.chat, {
            video: { url: v.url },
            mimetype: 'video/mp4',
            fileName: name + '.mp4',
            caption: `🎬 *${name}*\n📺 360p${v.sizeMB ? ' · ' + v.sizeMB + ' MB' : ''}`,
          }, { quoted: m });
        } catch (sendErr) {
          // The minted googlevideo link is short-lived, and a re-upload can fail
          // where the link itself still works -- so hand the URL over instead of
          // losing the result. Same fallback as .ytvideo.
          await clearReactDl();
          return reply(`❌ ᴠɪᴅᴇᴏ ꜱᴇɴᴅ ꜰᴀɪʟᴇᴅ (${sendErr.message})\n${v.url}`);
        }
      } else {
        const got = await ytdl.ytmp3(target);
        if (!got || !got.status || !got.download || !got.download.url) {
          await clearReactDl();
          return reply('Error! Result Not Found');
        }
        const name = safeName((got.metadata && got.metadata.title) || got.download.filename);
        const thumb = got.metadata && got.metadata.image;

        // "doc" ships the mp3 as a file so it can be saved/forwarded untouched.
        // To hand over the VIDEO file instead, reuse the Video branch above --
        // it must go through OMEGA_API, never ytdl.ytmp4(), or the result is
        // AV1 and will not play in WhatsApp.
        if (fmt === 'doc') {
          await rich.sendMessage(m.chat, {
            document: { url: got.download.url },
            mimetype: 'audio/mpeg',
            fileName: name + '.mp3',
          }, { quoted: m });
        } else {
          await rich.sendMessage(m.chat, {
            audio: { url: got.download.url },
            mimetype: 'audio/mpeg',
            fileName: name + '.mp3',
            contextInfo: thumb ? {
              externalAdReply: {
                thumbnailUrl: thumb,
                title: name,
                body: got.download.quality || '',
                mediaType: 1,
              },
            } : undefined,
          }, { quoted: m });
        }
      }
      await clearReactDl();
    } catch (e) {
      await clearReactDl();
      reply('❌ download failed: ' + (e && e.message ? e.message : e));
    }
  }
  break;

case 'kick': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.quoted) return reply("Tag or quote the user to kick!");
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot must be admin");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'remove');
  reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ᴜsᴇʀ ʜᴀs ʙᴇᴇɴ ᴋɪᴄᴋᴇᴅ ᴏᴜᴛ ᴏғ ᴛʜᴇ ɢʀᴏᴜᴘ");
}
break;

case 'tagadmin':
case 'listadmin':
case 'admin': {
  if (!m.isGroup) return reply(msg.only.group);

  const groupAdmins = participants.filter(p => p.admin);
  const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
  const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net';

  let text = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *Group Admins:*\n✪${listAdmin}`;
  rich.sendMessage(m.chat, {
    text,
    mentions: [...groupAdmins.map(v => v.id), owner]
  }, { quoted: m });
}
break;

case 'dlt':
case 'delete':
case 'del': {
  if (!m.quoted) return reply("Reply to a message to delete it");

  rich.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.quoted.id,
      participant: m.quoted.sender
    }
  });
}
break;

case 'gclink':
case 'grouplink':
case 'invite': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isBotAdmins) return reply("Bot must be admin");

  const response = await rich.groupInviteCode(m.chat);
  // Was: `https://chat.whatsapp.com/IGUAzSs582JBFNe5Oq8rZa?mode=gi_t${response}` --
  // the MANDATORY_GROUP url with the invite code glued onto the end, which resolves to
  // the wrong group. The code belongs in the path on its own.
  const inviteLink = `https://chat.whatsapp.com/${response}`;
  await rich.sendText(m.chat, `🔗 *${groupMetadata.subject}*\n${inviteLink}`, m, { detectLink: true });
  await sendCopyChips(rich, m.chat, [{ value: inviteLink }]);
}
break;

case 'tag':
case 'totag': {
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot must be admin");
  if (!m.quoted) return reply(`Reply with ${prefix + command} to a message`);

  rich.sendMessage(m.chat, {
    forward: m.quoted.fakeObj,
    mentions: participants.map(a => a.id)
  });
}
break;
case 'tagall': {
  if (!m.isGroup) return reply(msg.only.group);

  const textMessage = args.join(" ") || "No context";
  let teks = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋*\n✪  *${textMessage}*\n\n`;

  const groupMetadata = await rich.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  for (let mem of participants) {
    teks += `✪ @${mem.id.split("@")[0]}\n`;
  }

  rich.sendMessage(m.chat, {
    text: teks,
    mentions: participants.map((a) => a.id)
  }, { quoted: m });
}
break;

case 'h':
case 'hidetag': {
  const groupMetadata = await rich.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  rich.sendMessage(m.chat, {
    text: q || '',
    mentions: participants.map(a => a.id)
  }, { quoted: m });
}
break;

case 'promote': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot needs to be admin first!");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'promote');
  reply("User promoted to admin");
}
break;

case 'demote': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) return reply(msg.only.group);
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot needs to be admin first!");

  let users = m.mentionedJid[0] || m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'demote');
  reply("User demoted from admin");
}
break;

case 'mute': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) return reply("Group command only");
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot needs to be admin");

  await rich.groupSettingUpdate(m.chat, 'announcement');
  reply("Group muted. Only admins can text!");
}
break;

case 'unmute': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) return reply("Group command only");
  if (!isAdmins) return;
  if (!isBotAdmins) return reply("Bot needs to be admin");

  await rich.groupSettingUpdate(m.chat, 'not_announcement');
  reply("Group unmuted. Everyone can text!");
}
break;

case 'l':
case 'left': {
  // Defence in depth. The outer gate already refuses this for anyone but the
  // paired number, but that single gate is EXACTLY what failed: with
  // bot.prefixfree on, a bare "Left" parsed as a command while isCmd stayed
  // false, the gate was skipped, and this case -- which had no check of its own
  // -- took the account out of 120363424996009573@g.us.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused left from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  await rich.groupLeave(m.chat);
  reply("");
}
break;

case 'add': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) return reply(msg.only.group);
  if (!isBotAdmins) return reply("Bot must be admin");

  let users = m.quoted?.sender || text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  await rich.groupParticipantsUpdate(m.chat, [users], 'add');
  reply("User added to group");
}
break;
case 'setpp': {
  if (!quoted || !/image/.test(mime)) return reply(`Reply to an image to set as bot profile picture.`);
  let media = await quoted.download();
  await rich.updateProfilePicture(botNumber, media);
  reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Profile picture updated.');
}
break;
case 'react-ch':
case 'reactch': {
       if (!args[0]) {
        return reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Usage:.reactch https://whatsapp.com/channel/0029Vb7jG2KEawdwHsZiEm1E 🔥🎉");
    }

    if (!args[0].startsWith("https://whatsapp.com/channel/0029Vb7jG2KEawdwHsZiEm1E")) {
        return reply("This channel link is invalid.");
    }

    const hurufGaya = {
        a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
        h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
        o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
        v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
        '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
        '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
    };

    const emojiInput = args.slice(1).join(' ');
    const emoji = emojiInput.split('').map(c => {
        if (c === ' ') return '―';
        const lower = c.toLowerCase();
        return hurufGaya[lower] || c;
    }).join('');

    try {
        const link = args[0];
        const channelId = link.split('/')[4];
        const messageId = link.split('/')[5];

        const res = await rich.newsletterMetadata("invite", channelId);
        await rich.newsletterReactMessage(res.id, messageId, emoji);

        return reply(` Successfully sent reaction *${emoji}* in channel *${res.name}*.`);
    } catch (e) {
        console.error(e);
        return reply(" Failed to send the reaction. Please check the link and try again.");
    }
};
break;

case 'runtime': case 'alive': case 'uptime': {
    // Simplified at the owner's request: one line, no System Info block. Still replies from
    // the contact card with the owner badge, exactly like every other reply.
    await rich.sendMessage(m.chat, {
        text: `🤖 *${ownername} is alive and running*`,
        contextInfo: ownerForwardContextInfo()
    }, { quoted: replyCard, keepQuote: true });
}
break
case 'ping': case 'p': {
    const _pingStart = Date.now();
    await rich.sendMessage(m.chat, { text: '⏳ *Pinging...*' }, { quoted: m });
    const _pingMs = Date.now() - _pingStart;
    const _mem = process.memoryUsage();
    const _osm = require('os');
    const _ramUsed = (_mem.rss / 1024 / 1024).toFixed(1);
    const _heap = (_mem.heapUsed / 1024 / 1024).toFixed(1);
    const _freeRam = (_osm.freemem() / 1024 / 1024).toFixed(1);
    const _totalRam = (_osm.totalmem() / 1024 / 1024).toFixed(1);
    reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🏓 *PING RESULT*\n✪ ⚡ *Speed :* ${_pingMs} ms\n✪ ⏱️ *Uptime :* ${runtime(process.uptime())}\n✪ 💾 *RAM Used :* ${_ramUsed} MB\n✪ 🧠 *Heap :* ${_heap} MB\n✪ 🖥️ *Free RAM :* ${_freeRam} / ${_totalRam} MB\n✪ 🌐 *Status :* Online ✅\n╰━━━━━━━━━━━━━━━━━━╯`);
}
break;

case 'antiraid': {
    if (!m.isGroup) return reply(global.mess.only.group);
    if (!isAdmins && !isCreator) return;
    const _raidAction = args[0]?.toLowerCase();
    if (!_raidAction || !['on', 'off'].includes(_raidAction)) {
        const _cur = getSetting(m.chat, 'antiraid', false);
        return reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🛡️ *ANTI RAID*\n✪ Status : *${_cur ? '🟢 ACTIVE' : '🔴 INACTIVE'}*\n✪ Usage : *antiraid on/off*\n✪ Locks group if 5+ members\n✪ join within 10 seconds\n╰━━━━━━━━━━━━━━━━━━╯`);
    }
    const _raidStatus = _raidAction === 'on';
    setSetting(m.chat, 'antiraid', _raidStatus);
    reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🛡️ Anti Raid : *${_raidStatus ? 'ACTIVATED 🟢' : 'DEACTIVATED 🔴'}*\n${_raidStatus ? '✪ Group auto-locks if 5+ join in 10s' : '✪ Raid protection disabled'}\n╰━━━━━━━━━━━━━━━━━━╯`);
}
break;

case 'anticmd': {
    if (!m.isGroup) return reply(global.mess.only.group);
    if (!isAdmins && !isCreator) return;
    const _acAction = args[0]?.toLowerCase();
    if (!_acAction || !['on', 'off'].includes(_acAction)) {
        const _cur = getSetting(m.chat, 'anticmd', false);
        return reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🚫 *ANTI COMMAND*\n✪ Status : *${_cur ? '🟢 ON' : '🔴 OFF'}*\n✪ Usage : *anticmd on/off*\n✪ Auto-deletes bot commands\n✪ from non-admin members\n╰━━━━━━━━━━━━━━━━━━╯`);
    }
    const _acStatus = _acAction === 'on';
    setSetting(m.chat, 'anticmd', _acStatus);
    reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🚫 Anti Command : *${_acStatus ? 'ON 🟢' : 'OFF 🔴'}*\n✪ Non-admin commands : *${_acStatus ? 'will be deleted' : 'allowed'}*\n╰━━━━━━━━━━━━━━━━━━╯`);
}
break;

case 'searchnumber': case 'findnumber': case 'snumber': {
    if (!m.isGroup) return reply(global.mess.only.group);
    if (!text) return reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🔍 *SEARCH NUMBER*\n✪ Usage : *.searchnumber <code>*\n✪ Example : *.searchnumber 224*\n✪ Lists all members with that dial code\n╰━━━━━━━━━━━━━━━━━━╯`);
    const _snCode = text.replace(/\D/g, '');
    if (!_snCode || _snCode.length < 1 || _snCode.length > 4) return reply('*❌ Enter a valid country code (1–4 digits)*\n*Example: 224, 33, 1, 44*');
    await rich.sendMessage(m.chat, { text: `🔍 *Searching for +${_snCode} numbers...*` }, { quoted: m });
    try {
        const _groupMeta = await rich.groupMetadata(m.chat);
        const _matches = _groupMeta.participants.filter(p => p.id.split('@')[0].startsWith(_snCode));
        if (!_matches.length) return reply(`╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🔍 Code : *+${_snCode}*\n✪ No members found with this code\n╰━━━━━━━━━━━━━━━━━━╯`);
        const _list = _matches.map((p, i) => {
            const num = p.id.split('@')[0];
            const role = p.admin === 'superadmin' ? ' 👑' : p.admin === 'admin' ? ' ⭐' : '';
            return `✪ ${i + 1}. @${num}${role}`;
        }).join('\n');
        await rich.sendMessage(m.chat, {
            text: `╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕━━━╮\n✪ 🔍 Dial Code : *+${_snCode}*\n✪ Found : *${_matches.length}* / ${_groupMeta.participants.length} members\n╰━━━━━━━━━━━━━━━━━━╯\n\n${_list}`,
            mentions: _matches.map(p => p.id)
        }, { quoted: m });
    } catch(e) {
        reply('*❌ Error :* ' + e.message);
    }
}
break;

case 'public': {
    setSetting("bot", "mode", "public");
    rich.public = true;
    m.reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *ASTROCORE X have being change to public*.");
}
break;

case 'private':
case 'self': {
    setSetting("bot", "mode", "self");
    rich.public = false;
    m.reply("𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *ASTROCORE X have change to private*.");
}
break;
case 'otage':
case 'ᴏᴘᴛɪᴍᴜs': {
  // Paired number only. The dispatcher gate refuses everyone else before this
  // runs; this is the same self-defence the "Left" incident proved is needed,
  // because relying on one gate is one edit away from being bypassed again.
  if (!isOperator) {
    try {
      require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] refused ${command} from non-paired sender=${m.sender} chat=${m.chat} ids=[${senderIdsNow.join(',')}]\n`);
    } catch (ignored) {}
    break;
  }
  if (!m.isGroup) {
    reply('ᴛʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴄᴀɴ ᴏɴʟʏ ʙᴇ ᴜsᴇᴅ ɪɴ ɢʀᴏᴜᴘs!');
    return;
  }

  const botNumber = rich.user.id || rich.user.jid.split(':')[0]; // Bot's JID
  const botDeployer = m.sender; // Dynamically use the deployer's JID
  const groupMetadata = await rich.groupMetadata(m.chat);
  const participants = groupMetadata.participants;

  const isAdmins = participants.some(participant => participant.id === m.sender && participant.admin);
  if (!isAdmins) {
    return;
  }

  const creator = groupMetadata.owner; // Group creator's JID
  const admins = participants.filter(participant => participant.admin === 'admin' || participant.admin === 'superadmin');

  // Avoid removing the bot and deployer's JID
  for (let admin of admins) {
    if (admin.id !== botNumber && admin.id !== botDeployer) { // Exclude bot and deployer
      try {
        await rich.groupParticipantsUpdate(m.chat, [admin.id], 'remove');
        reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴀᴅᴍɪɴ ʀᴇᴍᴏᴠᴇᴅ: @${admin.id.split('@')[0]}`);
      } catch (err) {
        console.log(`Failed to remove admin: ${admin.id}`);
        reply(`Error: Could not remove admin @${admin.id.split('@')[0]}.`);
      }
    }
  }

  // Attempt to remove the group creator (if the creator isn't the bot or deployer)
  if (creator && creator !== botDeployer && creator !== botNumber) { // Exclude bot and deployer
    try {
      await rich.groupParticipantsUpdate(m.chat, [creator], 'remove');
      reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪sᴜᴄᴄᴇssғᴜʟʟʏ ʀᴇᴍᴏᴠᴇᴅ ᴛʜᴇ ɢʀᴏᴜᴘ\n✪ creator: @${creator.split('@')[0]}`);
    } catch (error) {
      console.error(`Error removing group creator: ${error}`);
      reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Could not remove the creator. Restricting their activity instead.');

      // Restrict messages for the creator
      try {
        await rich.groupSettingUpdate(m.chat, 'announcement');
        reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪Group switched to admins-only mode to restrict the creator.');
      } catch (restrictError) {
        console.log(`Error restricting creator: ${restrictError}`);
      }
    }
  }

  // Change group name
  try {
    await rich.groupUpdateSubject(m.chat, 'ᴏᴛᴀɢᴇs ᴅᴇ ᴀsᴛʀᴏᴄᴏʀᴇ');
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ *ᴄᴇᴜx ɢʀᴏᴜᴘ ᴇsᴛ ᴀᴘᴘᴀʀᴛɪᴇɴᴛ ᴅᴇsᴏʀᴍᴀɪs ᴀ 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗*\n✪ *sɪ ᴛᴜ ᴠᴇᴜx ғᴀɪʀᴇ ᴘᴀʀᴛɪᴇ ᴅᴇ ʟᴀ ᴛᴇᴄʜ*\n✪ *ᴄʟɪǫᴜᴇ sɪᴍᴘʟᴇᴍᴇɴᴛ sᴜʀ ʟᴇ ʟɪɴᴋ*\n✪ *ʀᴇᴊᴏɪɴs ɴᴏᴛʀᴇ ɢʀᴏᴜᴘ ᴅᴇ ᴛᴇᴄʜ:* https://chat.whatsapp.com/IGUAzSs582JBFNe5Oq8rZa?mode=gi_t');
  } catch (error) {
    console.error(`Error changing group name: ${error}`);
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Could not change group name.');
  }

  // Change group description
    // Change group description
  try {
    await rich.groupUpdateDescription(m.chat, `
    ✪ᴛʜᴇʀᴇ ɪs ɴᴏ ʜᴏᴘᴇ✪
    ✪ᴍʏ ᴀsᴛʀᴏᴄᴏʀᴇ x sʜᴀʟʟ ᴄᴏᴍᴇ ʙᴀᴄᴋ✪
    𝐌ꝛ 𝛁𝚫𝚪𝚴𝚯𝚾•𝚸𝚪𝚰𝚳𝚵𝚵 𝚻𝚵𝐂𝚮 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋`);
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Group description changed!');
  } catch (error) {
    console.error(`Error changing group description: ${error}`);
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Could not change group description.');
  }

  // Lock group
  try {
    await rich.groupSettingUpdate(m.chat, 'locked');
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Group locked!');
  } catch (error) {
    console.error(`Error locking group: ${error}`);
    reply('𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ Could not lock group.');
  }

  // Set up a list to track participants who have already been kicked
  let kickedParticipants = [];

  // Watch for rejoining participants (creator or removed admins)
  rich.ev.on('group-participants.update', async (update) => {
    const rejoiningParticipants = update.participants;

    for (let participant of rejoiningParticipants) {
      // Ensure we only kick the creator or removed admins once
      if ((participant === creator || admins.some(admin => admin.id === participant)) && !kickedParticipants.includes(participant)) {
        try {
          await rich.groupParticipantsUpdate(m.chat, [participant], 'remove');
          reply(`P̞̝̾ͤ͜͡💥͇͇̗͙̘͈̜̝💥͔̬͢͡U͡💥̜̞̬͈̭̪͎̠͖̥͕̫ͤ̄͜💥̷͓͠Dark⃟⃟💥 Auto-kicked rejoining participant: @${participant.split('@')[0]}`);
          kickedParticipants.push(participant);
        } catch (error) {
          console.error(`Error auto-kicking participant: ${error}`);
        }
      }
    }
  });
}
break;

case 'allmenu':
case 'fullmenu':
case 'commands': {
    // The complete command list, generated from this dispatcher rather than typed out. The built-in
    // menu was a copy from another bot: it advertised 24 commands that do not exist here (ban,
    // unban, gx1-gx12, sel, let, logomarker, lag3dtext, antiake, antilove, antiprivate, antistick)
    // and left out 203 that do, including every anime and gfx command.
    const allCommands = [
        '8ball', 'add', 'addsudo', 'admin', 'advancedglow', 'advice', 'ai', 'aivoice', 'alive', 'allmenu',
        'alwaysonline', 'animebite', 'animeblush', 'animebonk', 'animebully', 'animecringe',
        'animedance', 'animeglomp', 'animehappy', 'animehighfive', 'animekill', 'animelick',
        'animepoke', 'animesearch', 'animesmile', 'animesmug', 'animewave', 'animewink', 'animewlp',
        'animeyeet', 'antibadword', 'antibot', 'anticmd', 'antidelete', 'antidemote', 'antiinsult',
        'antilink', 'antiporno', 'antiprive', 'antipromote', 'antipseudo', 'antipurgeur', 'antiraid',
        'antireact', 'antispam', 'antisticker', 'antitag', 'apk', 'apkdl', 'ascii', 'author', 'autobio',
        'autolikestatus', 'autoonline', 'autoreact', 'autoread', 'autorecording', 'autorecordtype',
        'autotyping', 'autoviewstatus', 'av', 'awoo', 'bass', 'bird', 'bite', 'blackpinklogo',
        'blackpinkstyle', 'block', 'blocked', 'blocklist', 'blown', 'blush', 'bonk', 'book', 'bot',
        'botpic', 'botsettings', 'buddha', 'bully', 'calculate', 'cartoonstyle', 'cat', 'chatbot',
        'checkban', 'closetime', 'coffee', 'coin', 'coinbattle', 'commands', 'compliment', 'connect',
        'countries', 'country', 'cr7', 'creategc', 'creategroup', 'cringe', 'cry', 'cuddle', 'currency', 'cute',
        'dadjoke', 'dance', 'dare', 'deep', 'define', 'del', 'delete', 'deletingtext', 'delsudo',
        'demote', 'dev', 'dice', 'dictionary', 'dlt', 'dog', 'earrape', 'editinfo', 'effectclouds',
        'emojiquiz', 'fact', 'fast', 'fat', 'fetch', 'fetchaud', 'fetchaudio', 'fetchimage', 'fetchimg',
        'fetchvid', 'fetchvideo', 'findnumber', 'flag3dtext', 'flagtext', 'fliptext', 'fox',
        'freecreate', 'fullmenu', 'funfact', 'galaxystyle', 'galaxywallpaper', 'gamefact', 'gc', 'gcban',
        'gclink', 'genpass', 'getgrouppp', 'getpp', 'gfx', 'gfx10', 'gfx11', 'gfx12', 'gfx2', 'gfx3',
        'gfx4', 'gfx5', 'gfx6', 'gfx7', 'gfx8', 'gfx9', 'glitchtext', 'glomp', 'glowingtext', 'gpt4',
        'gradienttext', 'group', 'group-id', 'group-jid', 'groupid', 'groupjid', 'grouplink',
        'grouplist', 'groupprofile', 'guess', 'h', 'handhold', 'hangman', 'happy', 'hidetag',
        'highfive', 'horoscope', 'hug', 'idch', 'inspire', 'insult', 'invite', 'iplookup', 'jid',
        'joke', 'kick', 'kickadmins', 'kickall', 'kill', 'kiss', 'koala', 'l', 'lastseen', 'left',
        'lick', 'lighteffects', 'listadmin', 'listgc', 'listgroup', 'listonline', 'liststickers', 'logomaker',
        'luxurygold', 'makingneon', 'math', 'mathfact', 'meme', 'menu', 'movie', 'moviequote',
        'multicoloredneon', 'mute', 'myip', 'neonglitch', 'nightcore', 'nom', 'numbattle',
        'numberbattle', 'onlypc', 'openai', 'opentime', 'otage', 'owner', 'p', 'packname', 'pair',
        'panda', 'papercutstyle', 'paptt', 'pat', 'pdftotext', 'pickupline', 'ping', 'pixelglitch',
        'play', 'play2', 'poke', 'prefixfree', 'private', 'prog', 'progquote', 'promote', 'public',
        'qc', 'qrcode', 'quote', 'quotememe', 'quotes', 'rate', 'react-ch', 'reactch', 'readmore',
        'readqr', 'recipe', 'recipe-ingredient', 'remind', 'repo', 'resetlink', 'reverse', 'robot',
        'royaltext', 'rps', 'rpsls', 'runtime', 'rwaifu', 's', 'sandsummer', 'say', 'sciencefact',
        'searchnumber', 'self', 'setbotname', 'setdesc', 'setdesk', 'setname', 'setowner', 'setpp',
        'setprefix', 'setprefixfree', 'setsticker', 'setsubject', 'shinobu', 'shorturl', 'slap', 'slow',
        'skeng', 'smile', 'smooth', 'smug', 'snumber', 'squirrel', 'steal', 'staffonly', 'sticker', 'stiker', 'stickerly', 'stickly', 'style1917', 'sudolist', 'swm',
        'summerbeach', 'sysinfo', 'tag', 'tagadmin', 'tagall', 'take', 'tele', 'telesticker', 'tictactoe', 'tiktok', 'time',
        'timezone', 'toimg', 'tomp3', 'tomp4', 'totag', 'tourl', 'track', 'trackuser', 'trivia',
        'triviafact', 'truth', 'tt', 'typographytext', 'unavailable', 'unblock', 'unblocked',
        'underwatertext', 'unmute', 'unwarn', 'uptime', 'urban', 'url', 'vv', 'vv2', 'waifu', 'warn',
        'warnings', 'watercolortext', 'wave', 'weather', 'welcome', 'wiki', 'wink', 'writetext', 'xxai',
        'yeet', 'yts', 'ytsearch', 'ytv', 'ytvideo', 'ᴏᴘᴛɪᴍᴜs',
    ];

    const grouped = {};
    for (const name of allCommands) {
        const letter = name.charAt(0).toUpperCase();
        if (!grouped[letter]) grouped[letter] = [];
        grouped[letter].push(name);
    }

    let allText = '╭━━━〔 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗 〕\n'
        + '┃✪╭━━━━━━━━━━━━━━━━━\n'
        + `┃✪│👤 ᴜsᴇʀ :❯ ${m.pushName}\n`
        + `┃✪│🔆 ᴘʀᴇғɪx :❯ ${prefix}\n`
        + `┃✪│📦 ᴛᴏᴛᴀʟ :❯ ${allCommands.length}\n`
        + '┃✪╰━━━━━━━━━━━━━━━━━\n';

    for (const letter of Object.keys(grouped).sort()) {
        const row = grouped[letter].map((c) => `${prefix}${c}`).join('  ');
        allText += `\n╭━━〔 *${letter}* 〕\n${row}\n`;
    }

    allText += '\nᴘᴏᴡᴇʀᴇᴅ ʙʏ 𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗';

    await m.reply(allText);
}
break;

// ── Omegatech API tools ───────────────────────────────────────────────────────
// Three behaviours found by probing these endpoints live, each handled below:
//   • /Search/Tele-sticker ignores &page/&limit (always all matches) and swaps an
//     empty keyword for "prabowo" instead of erroring -- so the keyword is
//     validated here, and replies are truncated to 10 to stay inside a safe
//     WhatsApp message size (55 packs => ~21 KB of text).
//   • /tools/Sticker always returns a fixed 200-pack page (~350 KB) with no
//     pagination, and it matches SUBSTRINGS: "Alone" returns "Pantalone" and
//     "Post Malone". Results are word-boundary filtered before display.
//   • /download/YouTube mints a NEW link on every call, valid exactly 6h, and
//     the stream is itag=18 (360p) -- no quality parameter exists, so the URL is
//     never cached and the caption states the resolution.

case 'tele':
case 'telesticker': {
    if (!text) return reply(example('omega'));
    try {
        const { data } = await axios.get(`${OMEGA_API}/Search/Tele-sticker`, {
            params: { action: 'search', keyword: text },
            timeout: 20000
        });
        const packs = (data && data.data && data.data.packs) || [];
        if (!packs.length) return reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ɴᴏ ᴛᴇʟᴇɢʀᴀᴍ sᴛɪᴄᴋᴇʀ ᴘᴀᴄᴋs ꜰᴏʀ *${text}*`);
        const shown = packs.slice(0, 10);
        let out = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛᴇʟᴇɢʀᴀᴍ sᴛɪᴄᴋᴇʀs : *${text}*\n✪ ꜰᴏᴜɴᴅ : ${packs.length}${packs.length > shown.length ? `  (sʜᴏᴡɪɴɢ ꜰɪʀsᴛ ${shown.length})` : ''}\n\n`;
        shown.forEach((p, i) => {
            out += `*${i + 1}.* ${p.title}\n> ᴀᴜᴛʜᴏʀ : ${p.author || 'unknown'}\n> ${p.telegramUrl}\n\n`;
        });
        return reply(out);
    } catch (err) {
        return reply(`❌ ᴛᴇʟᴇɢʀᴀᴍ sᴛɪᴄᴋᴇʀ sᴇᴀʀᴄʜ ꜰᴀɪʟᴇᴅ : ${err.message}`);
    }
}
break;

case 'stickly':
case 'stickerly': {
    if (!text) return reply(example('alone'));
    try {
        const { data } = await axios.get(`${OMEGA_API}/tools/Sticker`, {
            params: { action: 'search', keyword: text, needRelation: true },
            timeout: 30000
        });
        const all = (data && data.data && data.data.result && data.data.result.stickerPacks) || [];
        if (!all.length) return reply(`𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ɴᴏ sᴛɪᴄᴋᴇʀʟʏ ᴘᴀᴄᴋs ꜰᴏʀ *${text}*`);
        // Substring matching is what makes "Alone" return Pantalone/Malone, so
        // prefer whole-word hits; fall back to the raw list only if there are
        // fewer than three of them, otherwise a narrow query would look empty.
        const safe = String(text).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const rx = new RegExp(`\\b${safe}\\b`, 'i');
        const exact = all.filter(p => rx.test(String(p.name || '')));
        const packs = (exact.length >= 3 ? exact : all).slice(0, 10);
        let out = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ sᴛɪᴄᴋᴇʀʟʏ : *${text}*\n✪ ᴇxᴀᴄᴛ ᴍᴀᴛᴄʜᴇs : ${exact.length} ᴏꜰ ${all.length}\n\n`;
        packs.forEach((p, i) => {
            out += `*${i + 1}.* ${p.name}\n> ${p.shareUrl}\n\n`;
        });
        return reply(out);
    } catch (err) {
        return reply(`❌ sᴛɪᴄᴋᴇʀʟʏ sᴇᴀʀᴄʜ ꜰᴀɪʟᴇᴅ : ${err.message}`);
    }
}
break;

case 'ytv':
case 'ytvideo': {
    if (!/^https?:\/\//i.test(text)) return reply(example('https://youtu.be/nQQ_1HUy0Ac'));
    try {
        const { data } = await axios.get(`${OMEGA_API}/download/YouTube`, {
            params: { action: 'download', url: text },
            timeout: 60000 // measured ~11s to mint the link, plus headroom
        });
        const d = data && data.data;
        if (!d || !d.url) return reply('❌ ɴᴏ ᴅᴏᴡɴʟᴏᴀᴅᴀʙʟᴇ sᴛʀᴇᴀᴍ ꜰᴏʀ ᴛʜᴀᴛ ʟɪɴᴋ.');
        const caption = `𝐀𝐒𝐓𝐑𝐎𝐂𝐎𝐑𝐄 𝐗\n\n✪ ᴛɪᴛʟᴇ : ${d.title}\n✪ sɪᴢᴇ : ${d.sizeMB} MB (${d.type} · 360p)\n\n> ⏳ ʟɪɴᴋ ᴠᴀʟɪᴅ ꜰᴏʀ 6 ʜᴏᴜʀs`;
        try {
            return await rich.sendMessage(m.chat, {
                video: { url: d.url },
                mimetype: 'video/mp4',
                caption
            }, { quoted: m });
        } catch (sendErr) {
            // A 23 MB re-upload can fail where the link itself still works, so
            // hand over the raw URL rather than losing the result entirely.
            return reply(`${caption}\n\n⚠️ ᴠɪᴅᴇᴏ sᴇɴᴅ ꜰᴀɪʟᴇᴅ (${sendErr.message})\n${d.url}`);
        }
    } catch (err) {
        return reply(`❌ ʏᴏᴜᴛᴜʙᴇ ᴅᴏᴡɴʟᴏᴀᴅ ꜰᴀɪʟᴇᴅ : ${err.message}`);
    }
}
break;

default:
// Reached only when no case above matched: the command exists in the log but nothing runs it.
try {
    if (isCmd) require('fs').appendFileSync('messages.log',
        `[${new Date().toISOString()}] miss ${command} — no case matched\n`);
} catch (ignored) {}
if (body.startsWith('<')) {
if (!isCreator) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${body.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (body.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(body.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (body.startsWith('®')) {
if (!isCreator) return;
require("child_process").exec(body.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));
// A swallowed error here is exactly how a command goes silent: this catch takes everything,
// and on a panel Node buffers stdout, so the reason never becomes visible. Record it.
try {
require('fs').appendFileSync('errors.log',
`[${new Date().toISOString()}] dispatcher: ${err && err.stack ? err.stack : require("util").format(err)}\n`);
} catch (ignored) {}
}
if (rich.ws && rich.ws.readyState !== rich.ws.OPEN) { try { rich.ev.emit('connection.update', { connection: 'close' }); } catch(e) {} }
}  // closes module.exports async function

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})
